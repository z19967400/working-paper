import { Component, Vue } from "vue-property-decorator";
import {
  comselect,
  comOperation,
  comPaging,
  comtable
} from "@/components/index";
import { UserData, UserOptions } from "@/types/index";
import * as Api from "@/api/user";
@Component({
  components: {
    comtable,
    comselect,
    comOperation,
    comPaging
  }
})
export default class About extends Vue {
  // Getter

  // Action

  // data
  data: UserData = {
    loading: false,
    list: [],
    select: {},
    totalize: 0,
    options: [
      {
        value: "member_name",
        label: "会员名称"
      },
      {
        value: "lawyer_name",
        label: "律师名称"
      },
      {
        value: "lawyer_phone_number",
        label: "律师手机号"
      }
    ],
    dataType: [
      {
        label: "会员ID",
        prop: "id"
      },
      {
        label: "律师ID",
        prop: "headeImg"
      },
      {
        label: "会员名称",
        prop: "member_name"
      },
      {
        label: "律师名称",
        prop: "lawyer_name"
      },
      {
        label: "律所全称",
        prop: "law_firm_name"
      },
      {
        label: "手机号码",
        prop: "lawyer_phone_number"
      },
      {
        label: "邮箱",
        prop: "lawyer_email"
      },
      {
        label: "身份证号码",
        prop: "lawyer_IDCard"
      },
      {
        label: "所在地址",
        prop: "lawyer_detailed"
      },
      {
        label: "律所地址",
        prop: "law_firm_address_detailed"
      },
      {
        label: "执业证号",
        prop: "license_number"
      },
      {
        label: "有效期",
        prop: "term_validity"
      },
      {
        label: "审核状态",
        prop: "audit_status"
      },
      {
        label: "认证时间",
        prop: "create_time_str"
      }
    ]
  };
  getData: any = {
    page: 1,
    limit: this.$store.getters.limit,
    member_name: "",
    lawyer_name: "",
    lawyer_phone_number: ""
  };
  list: any = [];
  created() {
    //
  }

  activated() {
    this.init();
  }

  mounted() {
    //
  }
  // 初始化函数
  init() {
    let self: any = this;
    let params: any =
      JSON.stringify(self.data.select) == "{}"
        ? self.getData
        : self.data.select;
    this.getList(params);
  }
  //获取数据
  getList(params: UserOptions["getOrdinary"]) {
    let data: any = this.data;
    data.loading = true;
    data.list = this.list;
    Api.getLayerList(params).then((res: any) => {
      data.loading = false;
      data.list = res.data;
      data.totalize = res.count;
    });
  }
  //编辑
  handleEdit(data: any) {
    this.$router.push({
      path: `/lawyer/admin/${data.row.id}`
    });
  }
  //删除
  handleDelete(data: any) {
    Api.lawyerDelete(data.row.id).then((res: any) => {
      if (res.data != 0) {
        this.$message.success(res.msg);
        this.init();
      } else {
        this.$message.warning(res.msg);
      }
    });
  }
  //搜索
  search(data: any) {
    let self: any = this;
    self.data.loading = true;
    self.getData.page = 1;
    let params: any = Object.assign({}, self.getData);
    data.forEach((item: any) => {
      let name: string = item.label;
      params[name] = item.value;
    });
    self.data.select = params;
    this.getList(params);
  }
  //清除搜索项
  clearSelection(data: any) {
    let self: any = this;
    self.data.select = {};
    this.init();
  }
  //添加
  add() {
    this.$router.push({
      path: "/ordinary/ordinaryInfo",
      query: {
        id: "0"
      }
    });
  }
  //分页
  watchChange(index: number, limit: number | null) {
    let self: any = this;
    let params: any =
      JSON.stringify(self.data.select) == "{}"
        ? self.getData
        : self.data.select;
    params.page = index;
    params.limit = limit == null ? params.limit : limit;
    self.init();
  }
}
