import { Component, Vue } from "vue-property-decorator";
import {
  comtable,
  comselect,
  comOperation,
  comPaging
} from "@/components/index";
import { AdminOptions, finance } from "@/types/index.ts";
import * as Api from "@/api/finance.ts";
@Component({
  components: {
    comtable,
    comselect,
    comOperation,
    comPaging
  }
})
export default class About extends Vue {
  // Getter

  // Action

  // data
  data: any = {
    loading: false,
    list: [],
    select: {},
    totalize: 0,
    options: [
      {
        value: "暂无",
        label: "###"
      }
    ],
    dataType: [
      {
        label: "账单ID",
        prop: "id"
      },
      {
        label: "账单编号",
        prop: "bill_number"
      },
      {
        label: "会员名称",
        prop: "name"
      },
      {
        label: "会员id",
        prop: "member_id"
      },
      {
        label: "vip账户名称",
        prop: "account_name"
      },
      {
        label: "vip账户id",
        prop: "member_vip_account_id"
      },
      {
        label: "账单类别",
        prop: "invoice_title_name"
      },
      {
        label: "原单金额",
        prop: "paid_amount"
      },
      {
        label: "结算对象",
        prop: "settlement_object_name"
      },
      {
        label: "结算状态",
        prop: "settlement_status_name"
      },
      {
        label: "发票状态",
        prop: "invoice_status_name"
      },
      {
        label: "创建时间",
        prop: "time"
      }
    ]
  };
  options: finance["getinandout"] = {
    page: 1,
    limit: this.$store.getters.limit
  };

  created() {
    //
  }

  activated() {
    this.init();
  }

  mounted() {
    //
  }

  // 初始化函数
  init() {
    let self: any = this;
    let params: any =
      JSON.stringify(self.data.select) == "{}"
        ? self.options
        : self.data.select;
    this.getList(params);
  }
  //生成AI律师函
  addailist() {
    window.console.log(11);
    this.$router.push({
      path: "/business/listbill/ailist"
    });
  }
  //获取数据
  getList(params: AdminOptions["AdminList"]) {
    let data: any = this.data;
    data.loading = true;
    Api.getpagingbill(params)
      .then((res: any) => {
        data.loading = false;
        data.list = res.data;
        data.totalize = res.count;
      })
      .catch(() => {
        data.loading = false;
        this.$message.error("网络异常");
      });
  }
  //账单详情
  handleInfo(data: any) {
    let self: any = this;
    self.$router.push({
      path: `/business/listbill/getadmindata/${data.row.id}`
    });
  }
  //编辑
  handleEdit(data: any) {
    //
  }
  //删除
  handleDelete(data: any) {
    Api.deletBill(data.row.id, data.row.bill_number).then((res: any) => {
      if (res.data == 0) {
        this.$message.warning(res.msg);
      } else {
        this.$message.success(res.msg);
        this.init();
      }
    });
  }
  //搜索
  search(data: any) {
    let self: any = this;
    self.data.loading = true;
    self.options.page = 1;
    let params: any = Object.assign({}, self.options);
    data.forEach((item: any) => {
      let name: string = item.label;
      params[name] = item.value;
    });
    self.data.select = params;
    this.getList(params);
  }
  //清除搜索项
  clearSelection(data: any) {
    let self: any = this;
    self.data.select = {};
    this.init();
  }
  //添加编辑
  add() {
    //
  }
  //分页
  watchChange(index: number, limit: number | null) {
    let self: any = this;
    let params: any =
      JSON.stringify(self.data.select) == "{}"
        ? self.options
        : self.data.select;
    params.page = index;
    params.limit = limit == null ? params.limit : limit;
    self.init();
  }
}
