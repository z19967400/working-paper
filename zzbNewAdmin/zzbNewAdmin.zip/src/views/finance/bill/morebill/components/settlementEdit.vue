<template>
  <div class="settlementEdit-wrap">
    <div class="settlementEdit-box">
      <el-form :model="data.edit" label-width="120px">
        <el-row v-for="(item, index) in data.edit.info" :key="index">
          <el-form-item
            v-for="(item2, index2) in item"
            :key="index2"
            :label="item2.name"
          >
            <el-col :span="18">
              <el-input
                v-if="
                  item2.name == '应结算(发票)金额' || item2.name == '已结算金额'
                "
                size="small"
                v-model="item2.value"
                :placeholder="item2.name"
              ></el-input>
              <el-select
                v-else-if="
                  item2.name == '结算对象' ||
                    item2.name == '开票状态' ||
                    item2.name == '结算状态'
                "
                size="small"
                v-model="item2.value"
                :placeholder="item2.name"
              >
                <el-option
                  v-for="(item3, index3) in item2.name == '开票状态'
                    ? data.invoiceTypes
                    : item2.name == '结算对象'
                    ? data.settingObject
                    : settingStatus"
                  :key="index3"
                  :label="item3.dic_content"
                  :value="item3.dic_code"
                ></el-option>
              </el-select>
              <span style="color: #606266;" v-else>{{ item2.value }}</span>
            </el-col>
          </el-form-item>
        </el-row>
      </el-form>
      <el-button @click="settingSave" plain size="small" type="primary"
        >立即保存</el-button
      >
      <div class="record">
        <el-row
          v-for="(item, index) in data.edit.list"
          :key="index"
          class="add"
        >
          <el-col :span="5">
            <el-select
              size="small"
              v-model="item.settlement_type"
              placeholder="请选择结算方式"
            >
              <el-option
                v-for="(item2, index2) in data.settingMethod"
                :key="index2"
                :label="item2.dic_content"
                :value="item2.dic_code"
              ></el-option>
            </el-select>
          </el-col>
          <el-col :span="5">
            <el-input
              size="small"
              placeholder="请输入订单号"
              v-model="item.pay_platform_number"
            ></el-input>
          </el-col>
          <el-col :span="5">
            <el-input
              size="small"
              placeholder="请输入结算金额"
              v-model="item.paid_amount"
            ></el-input>
          </el-col>
          <el-col :span="5">
            <el-date-picker
              size="small"
              :editable="false"
              v-model="item.settlement_time"
              value-format="yyyy-MM-dd HH:mm:ss"
              type="datetime"
              placeholder="选择结算时间"
            >
            </el-date-picker>
          </el-col>
          <el-col :span="2">
            <el-button
              @click="editRecord(item)"
              plain
              size="small"
              type="primary"
              >修改</el-button
            >
          </el-col>
          <el-col :span="2">
            <el-button
              @click="deleteRecord(item.id)"
              plain
              size="small"
              type="primary"
              >删除</el-button
            >
          </el-col>
        </el-row>
      </div>
      <el-row class="add">
        <el-col :span="5">
          <el-select
            size="small"
            v-model="data.add.settlement_type"
            placeholder="请选择结算方式"
          >
            <el-option
              v-for="(item, index) in data.settingMethod"
              :key="index"
              :label="item.dic_content"
              :value="item.dic_code"
            ></el-option>
          </el-select>
        </el-col>
        <el-col :span="5">
          <el-input
            size="small"
            placeholder="请输入订单号"
            v-model="data.add.pay_platform_number"
          ></el-input>
        </el-col>
        <el-col :span="5">
          <el-input
            size="small"
            placeholder="请输入结算金额"
            v-model="data.add.paid_amount"
          ></el-input>
        </el-col>
        <el-col :span="5">
          <el-date-picker
            size="small"
            :editable="false"
            v-model="data.add.settlement_time"
            value-format="yyyy-MM-dd HH:mm:ss"
            type="datetime"
            placeholder="选择结算时间"
          >
          </el-date-picker>
        </el-col>
        <el-col :span="4">
          <el-button @click="addSettlement" plain size="small" type="primary"
            >新增结算记录</el-button
          >
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop, Watch } from "vue-property-decorator";
import { Getter, Action } from "vuex-class";
import * as Api from "../../../../../api/finance";
@Component({})
export default class About extends Vue {
  // prop
  @Prop() editData?: any;
  @Prop() member_id?: number;
  @Prop() invoiceTypes!: any;
  @Prop() settingObject!: any;
  @Prop() settingStatus!: any;
  @Prop() billNumber!: string;

  //Watch
  @Watch("editData", { deep: true, immediate: true })
  editDataChange(newVal: any, oldVal: any) {
    this.data.edit = newVal;
  }
  @Watch("member_id", { deep: true })
  member_idChange(newVal: any, oldVal: any) {
    this.data.member_id = newVal;
  }
  @Watch("invoiceTypes", { deep: true })
  invoiceTypesChange(newVal: any, oldVal: any) {
    this.data.invoiceTypes = newVal;
  }
  @Watch("settingObject", { deep: true })
  settingObjectChange(newVal: any, oldVal: any) {
    this.data.settingObject = newVal;
  }
  @Watch("settingStatus", { deep: true })
  settingStatusChange(newVal: any, oldVal: any) {
    this.data.settingStatus = newVal;
  }
  @Watch("billNumber", { deep: true })
  billNumberChange(newVal: string, oldVal: string) {
    this.data.bill_number = newVal;
  }
  // data
  data: any = {
    member_id: 0,
    edit: [],
    bill_number: "", //账单编号
    add: {
      id: 0,
      settlement_type: "", //支付方式
      pay_platform_number: "", //支付平台流水号
      paid_amount: "", //结算金额
      settlement_time: "" //结算时间
    },
    invoiceTypes: [], //开票状态字典
    settingObject: [], //结算对象字典
    settingStatus: [], //结算状态字典
    settingMethod: [] //结算方式字典
  };

  created() {
    //
  }

  activated() {
    //
  }

  mounted() {
    this.getSettingMethod();
  }
  //结算基础信息保存
  settingSave() {
    let data: any = {};
    this.data.edit.info.forEach((item: any) => {
      item.forEach((item2: any) => {
        data[item2.prop] = item2.value;
      });
    });
    let invoice_status_name: any = this.data.invoiceTypes.filter(
      (item: any) => {
        return item.dic_content == data.invoice_status_name;
      }
    );
    let settlement_object_name: any = this.data.settingObject.filter(
      (item: any) => {
        return item.dic_content == data.settlement_object_name;
      }
    );
    let settlement_status_name: any = this.data.settingStatus.filter(
      (item: any) => {
        return item.dic_content == data.settlement_status_name;
      }
    );
    data.invoice_status_name =
      invoice_status_name.length == 0
        ? data.invoice_status_name
        : invoice_status_name[0].dic_code;
    data.settlement_object_name =
      settlement_object_name.length == 0
        ? data.settlement_object_name
        : settlement_object_name[0].dic_code;
    data.settlement_status_name =
      settlement_status_name.length == 0
        ? data.settlement_status_name
        : settlement_status_name[0].dic_code;
    this.$emit("edit", data);
  }
  //获取结算方式字典
  getSettingMethod() {
    Api.GetType("Clearing_form_back").then((res: any) => [
      (this.data.settingMethod = res.data)
    ]);
  }
  //新增结算记录
  addSettlement() {
    let isOk: boolean = true;
    let self: any = this;
    self.data.add["bill_number"] = self.data.bill_number;
    Object.keys(self.data.add).forEach((key: string) => {
      if (self.data.add[key] === "") {
        isOk = false;
      }
    });
    if (isOk) {
      self.$emit("addSettlement", self.data.add);
    } else {
      self.$message.warning("请完善结算信息");
    }
  }
  //修改结算记录
  editRecord(data: any) {
    let upData: any = {
      id: data.id,
      settlement_type: data.settlement_type,
      pay_platform_number: data.pay_platform_number,
      paid_amount: data.paid_amount,
      settlement_time: data.settlement_time,
      bill_number: this.data.bill_number
    };
    this.$emit("editRecord", upData);
  }
  //删除结算记录
  deleteRecord(id: number) {
    this.$emit("deleteRecord", id);
  }
}
</script>

<style lang="scss">
@import "@/assets/scss/variables";

.settlementEdit-wrap {
  width: 100%;
  & > .settlementEdit-box {
    & > .el-form {
      width: 100%;
      display: flex;
      & > .el-row {
        width: 33.33%;
        & > .el-form-item {
          & > .el-form-item__label {
            font-size: 12px;
            color: $Secondary-text;
          }
        }
      }
    }
    & > .el-button {
      // display: block;
      margin: 0 auto 20px auto;
    }
    & .add {
      margin-bottom: 20px;
      .el-col {
        input {
          width: 220px;
        }
      }
    }
  }
}
</style>
