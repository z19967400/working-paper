<template>
  <div class="InvoiceEdit-wrap">
    <div class="InvoiceEdit-box">
      <el-row style="width:100%">
        <div v-for="(item, index) in data.select" :key="index">
          <el-col :span="2">
            <span>{{ item.name }}</span>
          </el-col>
          <el-col :span="6">
            <el-select
              size="small"
              v-model="item.value"
              :placeholder="item.placeholder"
              @change="item.change"
            >
              <el-option
                v-for="(item2, index2) in item.options"
                :key="index2"
                :label="
                  index == 0
                    ? item2.dic_content
                    : index == 1
                    ? item2.invoice_title
                    : item2.country_name +
                      item2.province_name +
                      item2.city_name +
                      item2.county_name
                "
                :value="
                  index == 0 ? item2.dic_code : index == 1 ? item2.id : item2.id
                "
              >
              </el-option>
            </el-select>
          </el-col>
        </div>
      </el-row>
      <div v-for="(item, index) in data.edit" :key="index" class="text">
        <p v-for="(item2, index2) in item" :key="index2">
          <el-col v-if="item2.name != null" :span="6">
            <span>{{ item2.name }}</span>
          </el-col>
          <el-col
            v-if="
              item2.name != '后台备注' &&
                item2.name != null &&
                item2.name != '抬头类别' &&
                item2.name != '发票类别' &&
                item2.name != '开票日期'
            "
            :span="12"
          >
            <el-input size="small" v-model="item2.value"></el-input>
          </el-col>
          <el-col
            v-if="item2.name == '后台备注' && item2.name != null"
            :span="16"
          >
            <el-input
              type="textarea"
              size="small"
              v-model="item2.value"
            ></el-input>
          </el-col>
          <el-col
            v-if="item2.name == '抬头类别' || item2.name == '发票类别'"
            :span="16"
          >
            <el-select size="small" v-model="item2.value" placeholder="请选择">
              <el-option
                v-for="(item3, index3) in item2.name == '抬头类别'
                  ? data.InvoiceTitles
                  : data.InvoiceTypes"
                :key="index3"
                :label="item3.dic_content"
                :value="item3.dic_code"
              >
              </el-option>
            </el-select>
          </el-col>
          <el-col v-if="item2.name == '开票日期'" :span="16">
            <el-date-picker
              v-model="item2.value"
              type="datetime"
              size="small"
              value-format="yyyy-MM-dd HH:mm:ss"
              placeholder="选择开票日期"
            >
            </el-date-picker>
          </el-col>
        </p>
      </div>
    </div>
    <el-button @click="preservation" plain size="small" type="primary"
      >立即保存</el-button
    >
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop, Watch } from "vue-property-decorator";
import { Getter, Action } from "vuex-class";
import * as Api from "../../../../../api/finance";
@Component({})
export default class About extends Vue {
  // prop
  @Prop() editData!: any;
  @Prop() member_id!: number;
  @Prop() invoiceTypes!: any; //开票状态字典库
  @Prop() invoice_status?: string; //开票状态
  @Prop() invoiceId?: string; //发票id
  @Prop() invoice_address_id?: string; // 收票地址id
  @Prop() state!: number; //是否大客户 0不是，1是
  @Prop() invoice_amount?: number; //发票金额
  //Watch
  @Watch("editData", { deep: true, immediate: true })
  editDataChange(newVal: any, oldVal: any) {
    this.data.edit = newVal;
  }
  @Watch("member_id", { deep: true })
  member_idChange(newVal: any, oldVal: any) {
    this.data.member_id = newVal;
    this.getInvoice();
    this.getInvoiceAddress();
  }
  @Watch("invoiceTypes", { deep: true })
  invoiceTypesChange(newVal: any, oldVal: any) {
    this.data.select[0].options = newVal;
  }
  @Watch("invoice_status")
  invoice_statusChange(newVal: any, oldVal: any) {
    this.data.select[0].value = newVal;
  }
  @Watch("invoiceId")
  invoiceIdChange(newVal: any, oldVal: any) {
    this.data.select[1].value = newVal;
  }
  @Watch("invoice_address_id")
  invoice_address_idChange(newVal: any, oldVal: any) {
    this.data.select[2].value = newVal;
  }
  @Watch("state", { deep: true, immediate: true })
  stateChange(newVal: number, oldVal: number) {
    this.data.state = newVal;
  }
  @Watch("invoice_amount")
  invoice_amountChange(newVal: number, oldVal: number) {
    if (this.data.edit[0][7].value == "") {
      this.data.edit[0][7].value = newVal;
    }
  }
  // data
  data: any = {
    member_id: 0,
    edit: [],
    editData: {},
    state: 0, //是否大客户 0不是，1是
    select: [
      {
        name: "开票状态",
        value: "", //开票状态
        placeholder: "请选择开票状态",
        options: [],
        change: this.openInvoice
      },
      {
        name: "选择发票",
        value: "", //选择的发票
        placeholder: "请选择发票",
        options: [],
        change: this.invoice
      },
      {
        name: "收票地址",
        value: "", //收票地址
        placeholder: "请选择收票地址",
        options: [],
        change: this.collectionInvoice
      }
    ],
    InvoiceTitles: [], //发票抬头类别字典
    InvoiceTypes: [] //发票类别字典
  };

  created() {
    //
  }

  activated() {
    //
  }

  mounted() {
    this.getTitle();
    this.getInvoiceTypes();
  }
  //开票/编辑
  preservation() {
    let data: any = this.data.editData;
    this.data.edit.forEach((item: any) => {
      item.forEach((item2: any) => {
        data[item2.prop] = item2.value;
      });
    });
    let InvoiceTitle: any = this.data.InvoiceTitles.filter((item: any) => {
      return data["invoice_title_type_name"] == item.dic_content;
    });
    let InvoiceType: any = this.data.InvoiceTypes.filter((item: any) => {
      return data["invoice_type_name"] == item.dic_content;
    });
    if (InvoiceTitle.length != 0) {
      data["invoice_title_type_name"] = InvoiceTitle[0].dic_code;
    }
    if (InvoiceType.length != 0) {
      data["invoice_type_name"] = InvoiceType[0].dic_code;
    }
    data["invoice_status"] = this.data.select[0].value;
    data["invoice_id"] = this.data.select[1].value;
    data["invoice_address_id"] = this.data.select[2].value;
    data["invoice_type"] = data["invoice_type_name"];
    data["invoice_title_type"] = data["invoice_title_type_name"];
    this.$emit("edit", data);
  }
  //开票选择监听
  openInvoice(val: any) {
    //
  }
  //发票选择监听
  invoice(val: any) {
    let list: any = this.data.select[1].options;
    let data: any = list.filter((item: any) => {
      return item.id == val;
    });
    this.data.edit.forEach((item: any) => {
      item.forEach((item2: any) => {
        if (item2.prop == "bank_address") {
          item2.value = data[0]["detailed_address"];
        } else if (
          data[0][item2.prop] != undefined &&
          item2.prop != "back_remarks"
        ) {
          item2.value = data[0][item2.prop];
        }
      });
    });
  }
  //收票选择监听
  collectionInvoice(val: any) {
    let list: any = this.data.select[2].options;
    let data: any = list.filter((item: any) => {
      return item.id == val;
    });
    this.data.editData["payee_name"] =
      this.data.state == 0 ? data[0].name : data[0].admin_name;
    this.data.edit.forEach((item: any) => {
      item.forEach((item2: any) => {
        if (item2.prop == "consignee_address") {
          item2.value = data[0]["detailed_address"];
        } else if (data[0][item2.prop] != undefined) {
          item2.value = data[0][item2.prop];
        }
      });
    });
  }
  //获取收票地址下拉
  getInvoiceAddress() {
    Api.getInvoiceAddress(this.data.member_id).then((res: any) => {
      this.data.select[2].options = res.data;
    });
  }
  //获取发票下拉
  getInvoice() {
    Api.getInvoice(this.data.member_id).then((res: any) => {
      this.data.select[1].options = res.data;
    });
  }
  //获取抬头类别字典
  getTitle() {
    Api.GetType("Rise_type").then((res: any) => {
      this.data.InvoiceTitles = res.data;
    });
  }
  //获取发票类别字典
  getInvoiceTypes() {
    Api.GetType("Invoice_type").then((res: any) => {
      this.data.InvoiceTypes = res.data;
    });
  }
}
</script>

<style lang="scss">
@import "@/assets/scss/variables";

.InvoiceEdit-wrap {
  width: 100%;
  & > .InvoiceEdit-box {
    width: 100%;
    display: flex;
    flex-wrap: wrap;
    & > .el-row {
      height: 32px;
      line-height: 32px;
      margin-bottom: 20px;
      & > div {
        & .el-col {
          & > span {
            font-size: 12px;
            color: $Secondary-text;
          }
        }
      }
    }
    & > .text {
      width: 33.33%;
      p {
        color: $General-colors;
        font-size: 14px;
        margin: 0;
        margin-bottom: 20px;
        line-height: 32px;
        height: 32px;
        & > .el-col span {
          font-size: 12px;
          color: $Secondary-text;
        }
      }
    }
  }
  & > .el-button {
    margin-top: 20px;
  }
}
</style>
