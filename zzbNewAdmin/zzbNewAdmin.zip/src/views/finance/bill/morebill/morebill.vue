<template>
  <div class="entrustAdmin-wrap">
    <div class="entrustAdmin-box">
      <div :style="{ height: data.labers.length * 40 + 'px' }" class="left">
        <div class="text">
          <div
            v-for="(item, index) in data.labers"
            :key="index"
            :class="{
              act: index == data.actIndex,
              isHide: item.name == '操作权限' && data.state == 0
            }"
            @click="laberClick(index)"
          >
            {{ item.name }}
          </div>
        </div>
        <div class="shuxian-box">
          <div
            :style="{ transform: ' translateY(' + data.actIndex * 40 + 'px)' }"
            class="shuxian"
          ></div>
        </div>
      </div>
      <div ref="right" :style="{ height: height + 'px' }" class="right">
        <!-- 账单概括 -->
        <div ref="section0" class="section">
          <span style="margin-top:0;" :class="{ act: data.actIndex == 0 }">{{
            data.labers[0].name
          }}</span>
          <el-divider></el-divider>
          <div class="box">
            <div
              v-for="(item, index) in data.BasicInfo"
              :key="index"
              class="text"
            >
              <p v-for="(item2, index2) in item" :key="index2">
                <span>{{ item2.name }}</span>
                <span>{{ item2.value }}</span>
              </p>
            </div>
          </div>
        </div>
        <!-- 账单明细 -->
        <div ref="section1" class="section">
          <span :class="{ act: data.actIndex == 1 }"
            >{{ data.labers[1].name }}
            <el-button
              class="info"
              type="text"
              size="small"
              icon="el-icon-circle-plus-outline"
              @click="billSplit"
              >账单拆分</el-button
            ></span
          >
          <el-divider></el-divider>
          <div class="box">
            <el-table border :data="data.details" style="width: 100%">
              <el-table-column prop="pay_number" label="收支编号">
              </el-table-column>
              <el-table-column prop="total_amount" label="原单金额">
              </el-table-column>
              <el-table-column prop="batch_no" label="委托批次号">
              </el-table-column>
              <el-table-column prop="e_total" label="委托数量(起)">
              </el-table-column>
              <el-table-column prop="time" label="委托时间"> </el-table-column>
            </el-table>
          </div>
        </div>
        <!-- 操作权限 -->
        <div
          ref="section2"
          :class="{
            isHide: data.labers[2].name == '操作权限' && data.state == 0
          }"
          class="section"
        >
          <span :class="{ act: data.actIndex == 2 }">{{
            data.labers[2].name
          }}</span>
          <el-divider></el-divider>
          <div class="box">
            <el-row style="width:100%">
              <el-col :span="2"
                ><span style="font-size:12px;color:#909399;line-height: 32px;"
                  >当前权限</span
                ></el-col
              >
              <el-col :span="4"
                ><span
                  style="font-size:12px;color:#909399;line-height: 32px;"
                  >{{ data.actaccountName }}</span
                ></el-col
              >
              <el-col :span="2"
                ><span style="font-size:12px;color:#909399;line-height: 32px;"
                  >选择账户</span
                ></el-col
              >
              <el-col :span="5">
                <el-select
                  size="small"
                  v-model="data.accountName"
                  placeholder="请选择账户名称"
                >
                  <el-option
                    v-for="item in data.sonAccont"
                    :key="item.id"
                    :label="item.account_name"
                    :value="item.id"
                  ></el-option>
                </el-select>
              </el-col>
              <el-col :span="2">
                <el-button
                  @click="accountPreservation"
                  plain
                  size="small"
                  type="primary"
                  >立即保存</el-button
                >
              </el-col>
            </el-row>
          </div>
        </div>
        <!-- 开票收票 -->
        <div ref="section3" class="section">
          <span :class="{ act: data.actIndex == 3 }"
            >{{ data.labers[3].name }}
            <el-button
              class="edit"
              type="text"
              size="small"
              @click="data.nvoiceType = !data.nvoiceType"
              >{{ data.nvoiceType ? "返回" : "编辑" }}</el-button
            >
          </span>
          <el-divider></el-divider>
          <div
            v-show="data.invoice_type != null && !data.nvoiceType"
            class="box"
          >
            <div
              v-for="(item, index) in data.invoice1"
              :key="index"
              class="text"
            >
              <p v-for="(item2, index2) in item" :key="index2">
                <span>{{ item2.name }}</span>
                <span>{{ item2.value }}</span>
              </p>
            </div>
          </div>
          <invoiceEdit
            v-show="data.nvoiceType"
            :editData="data.invoice1"
            :invoiceTypes="data.invoiceTypes"
            :invoice_status="data.invoiceType"
            :invoiceId="data.invoiceId"
            :invoice_address_id="data.invoice_address_id"
            :member_id="data.member_id"
            :state="data.state"
            :invoice_amount="data.BasicInfo[1][2].value"
            @edit="invoice1Edit"
          ></invoiceEdit>
          <div
            v-show="data.invoice_type == null && !data.nvoiceType"
            class="box"
          >
            <el-button
              @click="data.nvoiceType = !data.nvoiceType"
              plain
              size="small"
              type="primary"
              >开票</el-button
            >
          </div>
        </div>
        <!-- 结算信息 -->
        <div ref="section4" class="section">
          <span :class="{ act: data.actIndex == 4 }"
            >{{ data.labers[4].name }}
            <el-button
              class="edit"
              type="text"
              size="small"
              @click="data.settlementType = !data.settlementType"
              >{{ data.settlementType ? "返回" : "编辑" }}</el-button
            >
          </span>
          <el-divider></el-divider>
          <div v-show="!data.settlementType" class="box">
            <div
              v-for="(item, index) in data.settlement.info"
              :key="index"
              class="text"
            >
              <p v-for="(item2, index2) in item" :key="index2">
                <span>{{ item2.name }}</span>
                <span>{{ item2.value }}</span>
              </p>
            </div>
          </div>
          <!-- 结算记录 -->
          <div v-show="!data.settlementType" class="box">
            <el-table border :data="data.settlement.list" style="width: 100%">
              <el-table-column prop="settlement_time" label="支付时间">
              </el-table-column>
              <el-table-column
                prop="pay_platform_number"
                label="支付平台流水号"
              >
              </el-table-column>
              <el-table-column prop="paid_amount" label="结算金额">
              </el-table-column>
              <el-table-column prop="settlement_type_name" label="支付方式">
              </el-table-column>
              <el-table-column
                v-if="data.settlement.info[0][0].value == '律师'"
                prop="settlement_type_name"
                label="原平台管理费率"
              >
              </el-table-column>
              <el-table-column
                v-if="data.settlement.info[0][0].value == '律师'"
                prop="settlement_type_name"
                label="结算平台管理费率"
              >
              </el-table-column>
            </el-table>
          </div>
          <!-- 结算编辑 -->
          <div v-show="data.settlementType" class="box">
            <settlementEdit
              :invoiceTypes="data.invoiceTypes"
              :settingStatus="data.settingStatus"
              :settingObject="data.settingObject"
              :editData="data.settlement"
              :billNumber="data.BasicInfo[0][0].value"
              @edit="billEdit"
              @addSettlement="addSettlement"
              @editRecord="editRecord"
              @deleteRecord="deleteRecord"
            ></settlementEdit>
          </div>
        </div>
        <!-- 通知管理 -->
        <div ref="section5" class="section">
          <span :class="{ act: data.actIndex == 5 }">{{
            data.labers[5].name
          }}</span>
          <el-divider></el-divider>
          <div style="flex-wrap:wrap" class="box">
            <el-row class="notice" style="width:100%">
              <el-col :span="2">
                <label>发送付款通知</label>
              </el-col>
              <el-col :span="5">
                <el-select
                  v-model="data.notice.payment.id"
                  placeholder="请选择发送人"
                  size="small"
                >
                  <el-option
                    v-for="item in data.notice.Sender"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>
              </el-col>
              <el-col :span="4">
                <el-input
                  size="small"
                  v-model="data.notice.payment.email"
                ></el-input>
              </el-col>
              <el-col :span="2">
                <el-button
                  @click="sendPayment"
                  plain
                  size="small"
                  type="primary"
                  >发送</el-button
                >
              </el-col>
            </el-row>
            <el-row class="notice" style="width:100%">
              <el-col :span="2">
                <label>发送开票通知</label>
              </el-col>
              <el-col :span="5">
                <el-select
                  v-model="data.notice.Invoice.id"
                  placeholder="请选择发送人"
                  size="small"
                >
                  <el-option
                    v-for="item in data.notice.Sender"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  >
                  </el-option>
                </el-select>
              </el-col>
              <el-col :span="4">
                <el-input
                  size="small"
                  v-model="data.notice.Invoice.email"
                ></el-input>
              </el-col>
              <el-col :span="2">
                <el-button
                  @click="sendPayment"
                  plain
                  size="small"
                  type="primary"
                  >发送</el-button
                >
              </el-col>
            </el-row>
          </div>
        </div>
        <!-- 后台备注 -->
        <div ref="section6" class="section">
          <span :class="{ act: data.actIndex == 6 }">{{
            data.labers[6].name
          }}</span>
          <el-divider></el-divider>
          <div class="box">
            <el-form :model="data.shenhe" label-width="60px">
              <el-form-item label="备注">
                <el-input
                  type="textarea"
                  :rows="4"
                  v-model="data.shenhe.desc"
                ></el-input>
              </el-form-item>
              <el-form-item>
                <el-button @click="beizhu" plain size="small" type="primary"
                  >保存</el-button
                >
              </el-form-item>
            </el-form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from "vue-property-decorator";
import { Getter, Action } from "vuex-class";
import * as Api from "../../../../api/finance";
import { verifyPhone, verifyEmall } from "../../../../utils/common";
import invoiceEdit from "./components/InvoiceEdit.vue";
import settlementEdit from "./components/settlementEdit.vue";
import { finance } from "../../../../types/index";
@Component({
  components: {
    invoiceEdit,
    settlementEdit
  }
})
export default class About extends Vue {
  //手机号码验证
  validatePhone = (rule: any, value: any, callback: any) => {
    let vtf: any = verifyPhone(value);
    if (!vtf.done) {
      callback(new Error(vtf.errMsg));
    } else {
      callback();
    }
  };
  //邮箱验证
  validateEmall = (rule: any, value: any, callback: any) => {
    let vtf: any = verifyEmall(value);
    if (!vtf.done) {
      callback(new Error(vtf.errMsg));
    } else {
      callback();
    }
  };
  // data
  data: any = {
    actIndex: 0,
    visible: false,
    sendstates: [],
    editShow: false,
    labers: [
      { name: "账单概况" },
      { name: "账单明细" },
      { name: "操作权限" },
      { name: "开票信息" },
      { name: "结算信息" },
      { name: "通知管理" },
      { name: "后台备注" }
    ],
    BasicInfo: [
      //账单概括
      [
        { name: "账单编号", value: "", prop: "bill_number" },
        { name: "会员名称", value: "", prop: "name" },
        { name: "原单金额", value: "", prop: "total_amount" }
      ],
      [
        { name: "账单类别", value: "", prop: "invoice_title_name" },
        { name: "开票状态", value: "", prop: "invoice_status_name" },
        { name: "应结算(发票)金额", value: "", prop: "paid_amount" }
      ],
      [
        { name: "创建时间", value: "", prop: "time" },
        { name: "结算状态", value: "", prop: "settlement_status_name" },
        { name: "已结算金额", value: "", prop: "invoice_amount" }
      ]
    ],
    //账单明细
    details: [],
    //当前权限
    actaccountName: "",
    //操作权限选择
    accountName: "",
    //子账号下拉列表
    sonAccont: [],
    //开票，收票信息
    invoice1: [
      //ai律师函 和 案件服务显示开票信息
      [
        { name: "发票抬头", value: "", prop: "invoice_title" },
        { name: "纳税人识别号", value: "", prop: "tax_number" },
        { name: "开票电话", value: "", prop: "bank_telephone" },
        { name: "开票地址", value: "", prop: "bank_address" },
        { name: "收票人姓名", value: "", prop: "consignee_name" },
        { name: "收票地址", value: "", prop: "consignee_address" },
        { name: "发票号码", value: "", prop: "invoice_number" },
        { name: "发票金额", value: "", prop: "paid_amount" },
        { name: "后台备注", value: "", prop: "back_remarks" }
      ],
      [
        { name: "发票类别", value: "", prop: "invoice_type_name" },
        {},
        { name: "开户银行", value: "", prop: "bank_name" },
        {},
        { name: "收票人邮箱", value: "", prop: "consignee_email" },
        {},
        { name: "快递单号", value: "", prop: "tracking_number" },
        {}
      ],
      [
        { name: "抬头类别", value: "", prop: "invoice_title_type_name" },
        {},
        { name: "银行账号", value: "", prop: "bank_account" },
        {},
        { name: "收票人电话", value: "", prop: "consignee_telephone" },
        {},
        { name: "开票日期", value: "", prop: "invoice_time" }
      ]
    ],
    //律师线下收票信息
    invoice2: [
      [
        { name: "收款户名", value: "", prop: "" },
        { name: "发票类型", value: "", prop: "" },
        { name: "快递单号", value: "", prop: "" },
        { name: "是否到付", value: "", prop: "" }
      ],
      [
        { name: "收款账号", value: "", prop: "" },
        { name: "发票税率", value: "", prop: "" },
        { name: "发票金额", value: "", prop: "" },
        { name: "后台备注", value: "", prop: "" }
      ],
      [
        { name: "收款银行全称", value: "", prop: "" },
        { name: "发票号码", value: "", prop: "" },
        { name: "收票日期", value: "", prop: "" }
      ]
    ],
    nvoiceType: false, //开票编辑
    //通知管理
    notice: {
      payment: {
        //付款通知
        id: "",
        email: "请输入邮箱"
      },
      Invoice: {
        //开票通知
        id: "",
        email: "请输入邮箱"
      },
      record: [], //发送记录
      Sender: [] //发送人
    },
    settlementType: false, // 结算状态
    //结算信息
    settlement: {
      info: [
        [
          { name: "结算对象", value: "", prop: "settlement_object_name" },
          { name: "原单金额", value: "", prop: "total_amount" }
        ],
        [
          { name: "开票状态", value: "", prop: "invoice_status_name" },
          { name: "应结算(发票)金额", value: "", prop: "paid_amount" }
        ],
        [
          { name: "结算状态", value: "", prop: "settlement_status_name" },
          { name: "已结算金额", value: "", prop: "invoice_amount" }
        ]
      ],
      list: [] //结算记录
    },
    //后台备注
    shenhe: {
      desc: ""
    },
    invoiceTypes: [], //开票状态字典
    settingObject: [], // 结算对象字典
    settingStatus: [], //结算状态字典
    vipId: 0, //会员总账户id
    state: 0, //是否大客户 0：普通客户，1:大客户
    invoice_title: "", //账单类型
    invoice_type: "", //是否开票
    member_id: 0, //会员id
    invoiceType: "", //开票状态
    invoiceId: "", //发票id
    invoice_address_id: "", //收票地址Id
    invoice_object: "" //开票对象
  };
  height: number = 0;
  sectionDom: any = {};
  created() {
    //
  }

  activated() {
    //
  }

  mounted() {
    let self: any = this;
    this.init();
    self.height = document.body.offsetHeight - 148;
    this.getInvoiceTypes();
    this.getSettingObject();
    this.getSettingStatus();
  }

  beforeDestroy() {
    //
  }
  init() {
    let self: any = this;
    if (self.$route.params.id != 0 && self.$route.params.id != null) {
      this.getInfo(self.$route.params.id);
    }
    let top: number = self.$refs.right.offsetTop; //初始位置
    for (let index = 0; index <= 6; index++) {
      const domTop = self.$refs["section" + index].offsetTop - top;
      self.sectionDom["section" + index] = domTop;
    }
  }
  //获取管理详情
  getInfo(id: number) {
    Api.getpagingbilldetails(id).then((res: any) => {
      //vip总账户id
      this.data.vipid = res.data.member_vip_account_id;
      this.getSubAccountSelect();
      //是否大客户
      this.data.state = res.data.member_vip_account_id;
      //会员id
      this.data.member_id = res.data.member_id;
      //当前操作权限
      this.data.actaccountName = res.data.account_name;
      //账单类型
      this.data.invoice_title = res.data.invoice_title;
      //开票对象
      this.data.invoice_object =
        res.data.invoice_title == "Bill_type_0" ? "Settlement_object_0" : ""; //如果账单类型是AI律师函,开票对象就是用户,反之待定
      //账单概括
      this.data.BasicInfo.forEach((item: any) => {
        item.forEach((item2: any) => {
          item2.value = res.data[item2.prop];
        });
      });
      //结算信息
      this.data.settlement.info.forEach((item: any) => {
        item.forEach((item2: any) => {
          item2.value = res.data[item2.prop];
        });
      });
      this.data.invoiceType = res.data.invoice_status; //开票状态
      if (res.invoice != null) {
        this.data.invoiceId = res.invoice.invoice_id; //发票ID
        this.data.invoice_address_id = res.invoice.invoice_address_id; //收票地址ID
      }
      //结算记录
      this.data.settlement.list = res.settlement;
      //账单明细
      this.data.details = res.pay;
      //开票信息
      if (
        this.data.invoice_title == "Bill_type_7" ||
        this.data.invoice_title == "Bill_type_6" ||
        this.data.invoice_title == "Bill_type_1" ||
        this.data.invoice_title == "Bill_type_0"
      ) {
        if (res.invoice == null) {
          this.data.invoice_type = null;
        } else {
          this.data.invoice1.forEach((item: any) => {
            item.forEach((item2: any) => {
              if (item2.prop == "paid_amount") {
                item2.value = res.data.invoice_amount;
              } else {
                item2.value = res.invoice[item2.prop];
              }
            });
          });
        }
      } else {
        //
      }
      //后台备注
      this.data.shenhe.desc = res.data.back_remarks;
    });
  }

  //点击左侧菜单事件
  laberClick(index: number) {
    let self: any = this;
    self.data.actIndex = index;
    let top: number = self.$refs.right.offsetTop; //初始位置
    let dom: any = "section" + index; //点击元素的位置
    let actTop: number = self.$refs[dom].offsetTop;
    self.$refs.right.scrollTop = actTop - top;
  }
  //账单拆分
  billSplit() {
    //
  }
  //账户名称立即保存
  accountPreservation() {
    let slef: any = this;
    Api.allocation(slef.$route.params.id, slef.data.accountName).then(
      (res: any) => {
        if (res.data != 0) {
          slef.$message.success(res.msg);
        } else {
          slef.$message.warning(res.msg);
        }
      }
    );
  }
  //开票，编辑提交
  invoice1Edit(data: any) {
    let self: any = this;
    let upData: any = {
      id: Number(self.$route.params.id),
      bill_number: self.data.BasicInfo[0][0].value, // 账单编号
      invoice_object: self.data.invoice_object, // 开票对象
      invoice_id: 0, // 发票id
      invoice_type: "", // 发票类型
      invoice_title_type: "", // 发票抬头类型
      invoice_title: "", // 发票抬头
      invoice_number: "", //发票号码
      tax_number: "", // 纳税人识别号
      bank_name: "", // 开户银行
      bank_account: "", // 银行账号
      bank_telephone: "", // 银行电话
      bank_address: "", // 详细地址
      open_invoice_type: "", // 开票类型
      invoice_tax_rate: 6, // 发票税率
      invoice_address_id: 0, // 收票地址id
      consignee_name: "", // 收票人姓名
      consignee_telephone: "", // 收票人电话
      consignee_email: "", // 收票人邮箱
      consignee_address: "", // 详细地址
      is_cash_delivery: 0, // 是否到付 0：否 1：是
      collect_money_id: 0, // 收款信息id
      payee_name: "", // 收款人姓名
      alipay_account: "", // 支付宝账号
      tracking_number: "", // 快递单号
      invoice_time: "", // 开票日期
      back_remarks: "", // 后台备注
      invoice_status: "", //开票状态
      invoice_amount: 0 //发票金额
    };
    Object.keys(upData).forEach((key: string) => {
      if (data[key] != undefined) {
        if (key == "invoice_amount") {
          upData[key] = data["paid_amount"];
        } else {
          upData[key] = data[key];
        }
      }
    });
    Api.openInvoice(upData).then((res: any) => {
      if (res.data != 0) {
        self.data.nvoiceType = false;
        self.$message.success(res.msg);
        self.init();
      } else {
        self.$message.warning(res.msg);
      }
    });
  }
  //新增结算记录
  addSettlement(data: any) {
    let self: any = this;
    Api.addSettingRecord(data).then((res: any) => {
      if (res.data != 0) {
        self.$message.success(res.msg);
        self.init();
      } else {
        self.$message.warning(res.msg);
      }
    });
  }
  //结算记录修改
  editRecord(data: any) {
    let self: any = this;
    Api.addSettingRecord(data).then((res: any) => {
      if (res.data != 0) {
        self.$message.success(res.msg);
        self.init();
      } else {
        self.$message.warning(res.msg);
      }
    });
  }
  //删除结算记录
  deleteRecord(id: number) {
    let self: any = this;
    Api.deleteSettingRecord(id).then((res: any) => {
      if (res.data != 0) {
        self.$message.success(res.msg);
        self.init();
      } else {
        self.$message.warning(res.msg);
      }
    });
  }
  //账单修改
  billEdit(data: any) {
    let self: any = this;
    data["id"] = Number(self.$route.params.id);
    data["invoice_status"] = data.invoice_status_name;
    data["settlement_status"] = data.settlement_status_name;
    data["settlement_object"] = data.settlement_object_name;
    delete data.invoice_status_name;
    delete data.settlement_object_name;
    delete data.settlement_status_name;
    delete data.total_amount;
    Api.billEdit(data).then((res: any) => {
      if (res.data != 0) {
        self.$message.success(res.msg);
        self.init();
        self.data.settlementType = !self.data.settlementType;
      } else {
        self.$message.warning(res.msg);
      }
    });
  }
  //发送付款通知
  sendPayment() {
    //
  }
  //备注
  beizhu() {
    let self: any = this;
    Api.billRemarks(self.$route.params.id, self.data.shenhe.desc).then(
      (res: any) => {
        if (res.data != 0) {
          self.$message.success(res.msg);
        } else {
          self.$message.warning(res.msg);
        }
      }
    );
  }
  //获取子账号下拉
  getSubAccountSelect() {
    Api.getSubAccountSelect(this.data.vipid).then((res: any) => {
      this.data.sonAccont = res.data;
    });
  }
  //获取开票状态字典
  getInvoiceTypes() {
    Api.GetType("Invoice_state").then((res: any) => {
      this.data.invoiceTypes = res.data;
    });
  }
  //获取结算对象字典
  getSettingObject() {
    Api.GetType("Settlement_object").then((res: any) => {
      this.data.settingObject = res.data;
    });
  }
  //结算状态字典
  getSettingStatus() {
    Api.GetType("Settlement_status_back").then((res: any) => {
      this.data.settingStatus = res.data;
    });
  }
}
</script>

<style lang="scss">
@import "@/assets/scss/variables";

.entrustAdmin-wrap {
  width: 100%;
  min-height: 100%;
  background-color: $main-body-bgColor;
  position: relative;
  .entrustAdmin-box {
    display: flex;
    & .el-table th,
    .el-table td {
      text-align: center;
    }
    & .left {
      width: 10%;
      display: flex;
      & > .text {
        div {
          color: $Main-characters;
          font-size: $Text-font;
          height: 40px;
          line-height: 40px;
          padding: 0 25px 0 0;
          text-align: center;
          cursor: pointer;
        }
        .act {
          color: #ec193a;
        }
      }
      & > .shuxian-box {
        height: 100%;
        width: 2px;
        background-color: #e4e7ed;
        position: relative;
        & > .shuxian {
          width: 100%;
          height: 40px;
          background-color: #ec193a;
          transition: transform 0.5s ease;
          transform: translateY(0);
        }
      }
    }
    & .right {
      width: 90%;
      overflow-y: auto;
      padding-right: 20px;
      .act {
        color: #ec193a !important;
      }
      & .section {
        margin-bottom: 20px;
        & > span:first-child {
          font-size: 12px;
          color: $Secondary-text;
          margin-top: 10px;
          display: block;
          display: flex !important;
          justify-content: space-between !important;
          line-height: 32px;
        }
        .box {
          display: flex;
          .text {
            width: 33.33%;
            p {
              color: $General-colors;
              font-size: 14px;
              margin: 0;
              margin-bottom: 10px;
              line-height: 32px;
              & > span:first-child {
                margin-right: 20px;
                font-size: 12px;
                color: $Secondary-text;
              }
            }
          }
          & .notice {
            height: 32px;
            line-height: 32px;
            margin-bottom: 20px;
            & label {
              font-size: 12px;
              color: #909399;
            }
            & button {
              margin-left: 30px;
            }
          }
        }
      }
    }
  }
  .el-form {
    width: 600px;
  }
  .el-divider--horizontal {
    margin: 5px 0 20px 0;
  }
  .info {
    color: #62d493;
  }
  .edit {
    color: #e6a23c;
  }
  .btn-box {
    position: absolute;
    bottom: 0;
    left: 10%;
  }
  .obligor {
    width: 600px;
    padding: 20px 40px;
  }
  .isHide {
    display: none;
  }
}
</style>
