<template>
  <div class="ailistbill">
    <comselect
      :options="data.options"
      @select="search"
      @clear="clearSelection"
    ></comselect>
    <comOperation :totalize="data.totalize" @add="add"></comOperation>
    <div class="tableres">
      <div style="width:55%" class="left">
        <choicetable
          :rightchoice="true"
          @choicedata="handlechoicedata"
          :tableData="data.list"
          :load="data.loading"
          :tableType="data.dataType"
          @Delete="handleDelete"
          :edit="false"
          :info="false"
        ></choicetable>
        <comPaging
          :totalize="data.totalize"
          @watchChange="watchChange"
        ></comPaging>
      </div>
      <div style="width:40%" class="right">
        <comtable
          :tableData="data.lists"
          :tableType="data.dataTypes"
          @Delete="handleDelete"
          :edit="false"
          :info="false"
        ></comtable>
        <!-- <el-row type="flex" justify="">
          <el-col :span="3">后台备注</el-col>
        </el-row> -->
        <el-row style="margin-top:20px;" type="flex" justify="space-between">
          <el-col class="totle" :span="3">总计 {{ data.tatal }}</el-col>
          <el-button
            size="small"
            type="primary"
            @click="getbillinsertlist(data.listss)"
            >生成账单</el-button
          >
        </el-row>
      </div>
    </div>
  </div>
</template>
<script lang="ts" src="./ailistbill.ts"></script>
<style lang="scss">
@import "./ailistbill.scss";
</style>
