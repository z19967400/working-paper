import { Component, Vue, Watch } from "vue-property-decorator";
// import { computed } from "vue-class-component";
import {
  comtable,
  comselect,
  comOperation,
  comPaging,
  choicetable
} from "@/components/index";
import { AdminOptions, finance } from "@/types/index.ts";
import * as Api from "@/api/finance.ts";
@Component({
  components: {
    comtable,
    comselect,
    comOperation,
    comPaging,
    choicetable
  }
})
export default class About extends Vue {
  // Getter

  // Action
  // data
  // @Watch("data.index", { immediate: true })
  // onChangeIndex(nval: any, oval: any) {
  //   let self: any = this;
  //   this.data.arr = self.data.list;
  //   window.console.log(self.data.list, "原数组");
  //   this.data.list = this.data.arr.filter((item: any, index: any) => {
  //     return index != nval;
  //   });
  // }
  @Watch("data.lists", { immediate: true, deep: true })
  onChangelists(nval: any, oval: any) {
    this.data.tatal = 0;
    this.data.paid_amount = 0;
    let paid_amount: any = 0;
    nval.forEach((item: any) => {
      this.data.tatal += item.total_amount;
      paid_amount += item.paid_amount;
    });
    this.data.paid_amount = paid_amount.toFixed(2);
  }
  data: any = {
    tatal: 0,
    paid_amount: 0,
    loading: false,
    list: [],
    lists: [],
    listss: [],
    select: {},
    value: [],
    arr: [],
    //被选中的单元格
    index: "",
    totalize: 0,
    options: [
      {
        value: "member_id",
        label: "会员id"
      },
      {
        value: "name",
        label: "会员名称"
      },
      {
        value: "account_name",
        label: "vip账户名称"
      },
      {
        value: "admin_name",
        label: "管理员名称"
      },
      {
        value: "pay_method",
        label: "支付方式"
      }
    ],
    dataType: [
      {
        label: "会员名称",
        prop: "name"
      },
      {
        label: "会员id",
        prop: "member_id"
      },
      {
        label: "收支编号",
        prop: "pay_number"
      },
      {
        label: "委托批次号",
        prop: "batch_no"
      },
      {
        label: "委托起数",
        prop: "e_total"
      },
      {
        label: "原单金额",
        prop: "total_amount"
      },
      {
        label: "委托时间",
        prop: "time"
      }
    ],
    dataTypes: [
      {
        label: "收支编号",
        prop: "pay_number"
      },
      {
        label: "委托批次号",
        prop: "batch_no"
      }
    ]
  };
  options: finance["getpagingbilltable"] = {
    page: 1,
    limit: this.$store.getters.limit,
    member_id: 0,
    name: "",
    account_name: "",
    admin_name: "",
    pay_method: ""
  };
  created() {
    //
  }

  activated() {
    this.init();
  }

  mounted() {
    //
  }

  // 初始化函数
  init() {
    let self: any = this;
    let params: any =
      JSON.stringify(self.data.select) == "{}"
        ? self.options
        : self.data.select;
    this.getList(params);
  }
  //获取数据
  getList(params: finance["getpagingbilltable"]) {
    let data: any = this.data;
    data.loading = true;
    Api.getpagingbilltable(params)
      .then((res: any) => {
        data.loading = false;
        data.list = res.data;
        data.totalize = res.count;
      })
      .catch(() => {
        data.loading = false;
        this.$message.error("网络异常");
      });
  }
  //账单详情
  handleInfo(index: number, row: any) {
    window.console.log(index, row);
  }
  // 生成账单
  getbillinsertlist(lists: any) {
    if (!lists) return this.$message.warning("请添加账单");
    let listype;
    if (
      lists[0].pay_method.indexOf("微信") == -1 ||
      lists[0].pay_method.indexOf("支付宝") == -1
    ) {
      listype = 0;
    } else {
      listype = 1;
    }
    let paynaby: any = [];
    lists.forEach((item: any) => {
      paynaby.push(item.pay_number);
    });
    var params: finance["getbillinsertlist"] = {
      type: listype,
      member_id: lists[0].member_id,
      member_vip_account_id: lists[0].member_vip_account_id,
      invoice_title: "个人",
      total_amount: this.data.tatal,
      back_remarks: "",
      pay_numbers: paynaby,
      paid_amount: this.data.paid_amount
    };
    Api.getbillinsertlist(params).then((res: any) => {
      if (res.msg == "操作成功") {
        this.$message.success("生成账单成功");
        this.$router.go(-1);
      } else {
        this.$message.warning("失败，请重试");
      }
    });
  }
  //编辑
  handleEdit(data: any) {
    //
  }
  //被选择的行内容
  handlechoicedata(data: any) {
    //全部数据
    this.data.listss = data.val;
    //表单显示数据
    this.data.lists = data.val;
    setTimeout(() => {
      this.data.index = data.index;
    }, 1500);
  }
  //删除
  handleDelete(data: any) {
    window.console.log(data);
  }
  //搜索
  search(data: any) {
    let self: any = this;
    self.data.loading = true;
    self.options.page = 1;
    let params: any = Object.assign({}, self.options);
    data.forEach((item: any) => {
      let name: string = item.label;
      params[name] = item.value;
    });
    self.data.select = params;
    this.getList(params);
  }
  //清除搜索项
  clearSelection(data: any) {
    let self: any = this;
    self.data.select = {};
    this.init();
  }
  //添加编辑
  add() {
    //
  }
  //账单添加
  watchChange(index: number) {
    let self: any = this;
    let params: any =
      JSON.stringify(self.data.select) == "{}"
        ? self.options
        : self.data.select;
    params.page = index;
    self.init();
  }
}
