import { Component, Vue } from "vue-property-decorator";
import {
  comtable,
  comselect,
  comOperation,
  comPaging
} from "@/components/index";
import { AdminOptions, finance } from "@/types/index.ts";
import * as Api from "@/api/finance.ts";
import * as Api2 from "@/api/template";
@Component({
  components: {
    comtable,
    comselect,
    comOperation,
    comPaging
  }
})
export default class About extends Vue {
  // Getter

  // Action

  // data
  dialogVisible: boolean = false;
  data: any = {
    loading: false,
    list: [],
    select: {},
    totalize: 0,
    options: [
      {
        value: "暂无",
        label: "###"
      }
    ],
    dataType: [
      { label: "收支ID", prop: "id" },
      { label: "收支编号", prop: "pay_number" },
      { label: "账单编号", prop: "bill_number" },
      { label: "会员名称", prop: "name" },
      { label: "会员ID", prop: "member_id" },
      { label: "VIP账户名称", prop: "account_name" },
      { label: "VIP账户ID", prop: "member_vip_account_id" },
      { label: "VIP管理员", prop: "admin_name" },
      { label: "VIP管理员ID", prop: "member_vip_admin_id" },
      { label: "原单金额", prop: "total_amount" },
      { label: "委托批次号", prop: "batch_no" },
      { label: "委托数(起)", prop: "e_total" },
      { label: "收支类别", prop: "pay_type_name" },
      { label: "支付方式", prop: "pay_method_name" },
      { label: "支付时间", prop: "pay_time" },
      { label: "创建时间", prop: "time" }
    ]
  };
  options: finance["getinandout"] = {
    page: 1,
    limit: this.$store.getters.limit
  };
  info: any = [
    [
      { label: "收支id", value: "", prop: "id" },
      { label: "收支编号", value: "", prop: "pay_number" },
      { label: "创建时间", value: "", prop: "member_id" }
    ],
    [
      { label: "会员名称", value: "", prop: "name" },
      { label: "收支类别", value: "", prop: "pay_type_name" },
      { label: "业务编号", value: "", prop: "pay_number" }
    ],
    [
      { label: "原单金额", value: "", prop: "total_amount" },
      { label: "实付金额", value: "", prop: "paid_amount" },
      { label: "支付方式", value: "", prop: "pay_method_name" }
    ],
    [
      { label: "支付状态", value: "", prop: "pay_status_name" },
      { label: "支付时间", value: "", prop: "time" }
    ],
    [
      { label: "账单编号", value: "", prop: "bill_number" },
      { label: "发票状态", value: "", prop: "invoice_status_name" },
      { label: "结算状态", value: "", prop: "settlement_status_name" }
    ]
  ];
  edit: any = [
    [
      { label: "收支id", value: "", prop: "id" },
      { label: "收支编号", value: "", prop: "pay_number" },
      { label: "创建时间", value: "", prop: "member_id" }
    ],
    [
      { label: "会员名称", value: "", prop: "name" },
      { label: "收支类别", value: "", prop: "pay_type_name" },
      { label: "业务编号", value: "", prop: "pay_number" }
    ],
    [{ label: "原单金额", value: "", prop: "total_amount" }],
    [
      { label: "支付方式", value: "", prop: "pay_method" },
      { label: "实付金额", value: "", prop: "paid_amount" },
      { label: "支付状态", value: "", prop: "pay_status" }
    ],
    [{ label: "平台流水", value: "", prop: "pay_platform_number" }]
  ];
  payMode: any = []; //支付方式列表
  payTypes: any = []; //支付状态列表
  payStatus: string = ""; //是否支付
  created() {
    //
  }

  activated() {
    this.init();
  }

  mounted() {
    this.getPayMode();
    this.getPayType();
  }

  // 初始化函数
  init() {
    let self: any = this;
    let params: any =
      JSON.stringify(self.data.select) == "{}"
        ? self.options
        : self.data.select;
    this.getList(params);
  }
  //获取数据
  getList(params: AdminOptions["AdminList"]) {
    let data: any = this.data;
    data.loading = true;
    Api.getinandout(params)
      .then((res: any) => {
        data.loading = false;
        data.list = res.data;
        data.totalize = res.count;
      })
      .catch(() => {
        data.loading = false;
        this.$message.error("网络异常");
      });
  }
  //获取支付方式字典
  getPayMode() {
    Api2.getDicInfoList("Pay_manner").then((res: any) => {
      this.payMode = res.data;
    });
  }
  //获取支付状态字典
  getPayType() {
    Api2.getDicInfoList("pay_status2").then((res: any) => {
      this.payTypes = res.data;
    });
  }
  // 查看详情
  handleInfo(...data: any) {
    let id: any = data[0].row.id;
    Api.getdetails(id)
      .then((res: any) => {
        this.payStatus = res.data.pay_status;
        if (this.payStatus == "pay_status2_1") {
          //该订单已支付，渲染已支付数据
          this.info.forEach((item: any) => {
            item.forEach((item2: any) => {
              item2.value = res.data[item2.prop];
            });
          });
        } else {
          this.edit.forEach((item: any) => {
            item.forEach((item2: any) => {
              item2.value = res.data[item2.prop];
            });
          });
        }
        this.dialogVisible = true;
      })
      .catch(() => {
        this.$message.error("网络异常");
      });
  }
  //订单修改
  editOrder() {
    let isok: boolean = true;
    let parmas: any = {
      id: this.edit[0][0].value,
      pay_method: this.edit[3][0].value,
      paid_amount: this.edit[3][1].value,
      pay_status: this.edit[3][2].value,
      pay_platform_number: this.edit[4][0].value
    };
    Object.keys(parmas).forEach((key: string) => {
      if (parmas[key] == null || parmas[key] == "") {
        isok = false;
      }
    });
    if (isok) {
      Api.editOrder(parmas).then((res: any) => {
        if (res.data == 0) {
          this.$message.warning(res.msg);
        } else {
          this.$message.success(res.msg);
        }
        setTimeout(() => {
          this.dialogVisible = false;
        }, 1000);
      });
    } else {
      this.$message.warning("必要内容为空");
    }
  }
  //编辑
  handleEdit(data: any) {
    //
  }
  //删除
  handleDelete(data: any) {
    //
  }
  //搜索
  search(data: any) {
    let self: any = this;
    self.data.loading = true;
    self.options.page = 1;
    let params: any = Object.assign({}, self.options);
    data.forEach((item: any) => {
      let name: string = item.label;
      params[name] = item.value;
    });
    self.data.select = params;
    this.getList(params);
  }
  //清除搜索项
  clearSelection(data: any) {
    let self: any = this;
    self.data.select = {};
    this.init();
  }
  //添加编辑
  add() {
    //
  }
  //分页
  watchChange(index: number) {
    let self: any = this;
    let params: any =
      JSON.stringify(self.data.select) == "{}"
        ? self.options
        : self.data.select;
    params.page = index;
    self.init();
  }
}
