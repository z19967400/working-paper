<template>
  <div class="inandout">
    <comselect
      :options="data.options"
      @select="search"
      @clear="clearSelection"
    ></comselect>
    <comOperation :totalize="data.totalize" @add="add"></comOperation>
    <comtable
      :tableData="data.list"
      :load="data.loading"
      :tableType="data.dataType"
      :info="true"
      :edit="false"
      @Delete="handleDelete"
      @Info="handleInfo"
    ></comtable>
    <comPaging :totalize="data.totalize" @watchChange="watchChange"></comPaging>
    <!--收支详情弹框 -->
    <el-dialog title="收支详情" :visible.sync="dialogVisible">
      <el-row
        v-for="(item, index) in payStatus == 'pay_status2_1' ? info : edit"
        :key="index"
      >
        <div v-if="payStatus == 'pay_status2_1'">
          <el-col v-for="(item2, index2) in item" :key="index2" :span="8">
            <el-col :span="8">
              {{ item2.label }}
            </el-col>
            <span>{{ item2.value }}</span>
          </el-col>
        </div>
        <div v-else>
          <el-col v-for="(item2, index2) in item" :key="index2" :span="8">
            <el-col :span="8">
              {{ item2.label }}
            </el-col>
            <span
              v-if="
                item2.prop != 'pay_method' &&
                  item2.prop != 'paid_amount' &&
                  item2.prop != 'pay_status' &&
                  item2.prop != 'pay_platform_number'
              "
              >{{ item2.value }}</span
            >
            <el-col v-else :span="14">
              <el-select
                v-if="item2.prop == 'pay_method' || item2.prop == 'pay_status'"
                size="small"
                v-model="item2.value"
                placeholder="请选择"
              >
                <el-option
                  v-for="item3 in item2.prop == 'pay_method'
                    ? payMode
                    : payTypes"
                  :key="item3.id"
                  :label="item3.dic_content"
                  :value="item3.dic_code"
                >
                </el-option>
              </el-select>
              <el-input
                v-else
                size="small"
                v-model="item2.value"
                placeholder="请输入内容"
              ></el-input>
            </el-col>
          </el-col>
        </div>
      </el-row>
      <span
        v-if="payStatus != 'pay_status2_1'"
        slot="footer"
        class="dialog-footer"
      >
        <el-button type="primary" size="small" @click="editOrder"
          >确 定</el-button
        >
        <el-button size="small" @click="dialogVisible = false">取 消</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script lang="ts" src="./inandout.ts"></script>

<style lang="scss">
@import "./inandout.scss";
</style>
