<template>
  <div class="index-wrap">
    404
  </div>
</template>

<script lang="ts" src="./404.ts"></script>

<style lang="scss">
@import "./404.scss";
</style>
