<template>
  <div class="vipRelatAdmin-wrap">
    <div class="vipRelatAdmin-box">
      <comselect
        :options="data.options"
        @select="search"
        @clear="clearSelection"
      ></comselect>
      <comOperation :totalize="data.totalize" @add="add"></comOperation>
      <comtable
        :tableData="data.list"
        :load="data.loading"
        :tableType="data.dataType"
        :creditor="true"
        @creditor="handCreditor"
        @Edit="handleEdit"
        @Delete="handleDelete"
      ></comtable>
      <div class="zhezhao" v-show="creditorType"></div>
      <el-popover title="债权人" popper-class="creditor" v-model="creditorType">
        <comCreditor
          :loading="creditorLoading"
          @close="creditorClose"
          @determine="determine"
          :tableData="creditorData"
        ></comCreditor>
      </el-popover>
      <comPaging
        :page="getData.page"
        :totalize="data.totalize"
        @watchChange="watchChange"
      ></comPaging>
      <div class="zhezhao" v-show="visible"></div>
      <el-popover title="添加/编辑" popper-class="editData" v-model="visible">
        <span
          @click="visible = !visible"
          class="el-icon-circle-close close"
        ></span>
        <comAdd :children="childrenData"></comAdd>
      </el-popover>
    </div>
  </div>
</template>

<script lang="ts" src="./vipRelatAdmin.ts"></script>

<style lang="scss">
@import "./vipRelatAdmin.scss";
</style>
