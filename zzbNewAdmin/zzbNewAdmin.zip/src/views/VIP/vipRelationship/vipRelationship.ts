import { Component, Vue } from "vue-property-decorator";
import {
  comselect,
  comOperation,
  comPaging,
  comtable
} from "@/components/index";
import { UserData, UserOptions } from "@/types/index.ts";
import * as Api from "@/api/user.ts";
import comCreditor from "./components/creditor.vue";
import comRelating from "./vipRelatAdmin.vue";
import comCreditoList from "./components/creditorList.vue";
@Component({
  components: {
    comtable,
    comselect,
    comOperation,
    comPaging,
    comCreditor,
    comRelating,
    comCreditoList
  }
})
export default class About extends Vue {
  // Getter

  // Action

  // data
  data: UserData = {
    loading: false,
    list: [],
    select: {},
    totalize: 0,
    input: "", //输入框查询内容
    options: [
      {
        value: "account_name",
        label: "公司名称"
      }
    ],
    dataType: [
      {
        label: "ID",
        prop: "id",
        width: "60px"
      },
      {
        label: "总账户",
        prop: "parent_account_name",
        width: "120px"
      },
      {
        label: "子账户",
        prop: "account_name",
        width: "120px"
      }
    ]
  };
  accounts: any = [];
  visible: boolean = false;
  creditorType: boolean = false;
  btnLoad: boolean = false;
  getData: any = {
    page: 1,
    limit: this.$store.getters.limit,
    account_name: ""
  };
  editData: any = {
    parent_account_id: "",
    account_name: ""
  };
  rules: any = {
    parent_account_id: [
      { required: true, message: "请选择总账号", trigger: "change" }
    ],
    account_name: [
      { required: true, message: "请输入子账号名称", trigger: "blur" },
      { max: 15, message: "长度不能超过15个字符", trigger: "blur" }
    ]
  };
  list: any = [
    {
      ID: 1,
      headeImg:
        "http://file.zhaizhubang.net/Img/20200618/90bc9e7a-b951-47fd-9df7-4704e9ea5e7e.jpg",
      name: "会员xxx",
      phone: "18897924015",
      email: "1269674774@qq.com",
      leibie: "律师",
      renzhen: "个人",
      state: 0,
      created_time: "2020-02-02"
    }
  ];
  creditorData: any = []; //债权人数据
  creditorLoading: boolean = false;
  childrenData: any = {
    member_vip_account_id: "",
    mid: ""
  };
  isAdmin: boolean = true; //显示管理员还是债权人
  account_id: any = "";
  created() {
    //
  }

  activated() {
    this.init();
  }

  mounted() {
    //
  }
  // 初始化函数
  init() {
    let self: any = this;
    let params: any =
      JSON.stringify(self.data.select) == "{}"
        ? self.getData
        : self.data.select;
    this.getList(params);
  }
  //获取数据
  getList(params: UserOptions["getVipRelationship"]) {
    let data: any = this.data;
    data.loading = true;
    data.list = this.list;
    Api.getVipRelationship(params).then((res: any) => {
      data.loading = false;
      data.list = res.data;
      data.totalize = res.count;
    });
  }
  //管理员
  handleAdmin(data: any) {
    this.isAdmin = true;
    this.childrenData.member_vip_account_id = data.id;
    this.childrenData.mid =
      data.parent_account_id == 0 ? data.id : data.parent_account_id;
  }
  //删除
  handleDelete(data: any) {
    Api.subAccountDelet(data.row.id).then((res: any) => {
      if (res.data != 0) {
        this.$message.success(res.msg);
        this.init();
      } else {
        this.$message.warning(res.msg);
      }
    });
  }
  //搜索
  search() {
    let self: any = this;
    self.getData.account_name = self.data.input;
    self.getList(self.getData);
  }
  //获取所有总账户
  getAllAccounts() {
    Api.getAllAccounts().then((res: any) => {
      this.accounts = res.data;
    });
  }
  //添加
  add() {
    this.accounts = [];
    this.getAllAccounts();
    this.visible = true;
  }
  //取消，重置
  resetForm(formName: string) {
    let from: any = this.$refs[formName];
    from.resetFields();
    this.visible = false;
  }
  //编辑添加提交
  submitForm(formName: string) {
    let from: any = this.$refs[formName];
    let self: any = this;
    from.validate((valid: boolean) => {
      this.btnLoad = true;
      if (valid) {
        let ids: any = self.editData.parent_account_id.split(",");
        self.editData.parent_account_id = ids[0];
        self.editData.member_vip_id = ids[1];
        Api.addSubAccount(self.editData).then((res: any) => {
          if (res.data != 0) {
            self.visible = false;
            self.$message.success(res.msg);
            from.resetFields();
            this.btnLoad = false;
            self.init();
          } else {
            self.$message.warning(res.msg);
            this.btnLoad = false;
          }
        });
      } else {
        // eslint-disable-next-line no-console
        console.log("error submit!!");
        this.btnLoad = false;
        return false;
      }
    });
  }
  //分页
  watchChange(index: number, limit: number | null) {
    let self: any = this;
    let params: any =
      JSON.stringify(self.data.select) == "{}"
        ? self.getData
        : self.data.select;
    params.page = index;
    params.limit = limit == null ? params.limit : limit;
    self.init();
  }
  //子账户获取债权人
  getSubAccountCreditor(id: number) {
    this.creditorData = [];
    this.creditorLoading = true;
    Api.getSubAccountCreditor(id).then((res: any) => {
      this.creditorData = res.data;
      this.creditorLoading = false;
    });
  }
  //债权人
  handCreditor(data: any) {
    // this.creditorType = true;
    // this.getSubAccountCreditor(data.row.id);
    this.isAdmin = false;
    this.account_id = data.row.id;
  }
  //债权人弹窗关闭
  creditorClose() {
    this.creditorType = false;
  }
}
