<template>
  <div class="vipRelationship-wrap">
    <div class="left">
      <div class="vipRelationship-box">
        <div class="chaxun">
          <el-input
            size="small"
            v-model="data.input"
            @keyup.enter.native="search"
            placeholder="请输入公司名称"
          ></el-input>
          <el-button
            @click="search"
            size="small"
            type="primary"
            icon="el-icon-search"
            plain
            >查询</el-button
          >
        </div>
        <comOperation :totalize="data.totalize" @add="add"></comOperation>
        <comtable
          :tableData="data.list"
          :load="data.loading"
          :tableType="data.dataType"
          :edit="false"
          :administrators="true"
          :creditor="true"
          @creditor="handCreditor"
          @admin="handleAdmin"
          @Delete="handleDelete"
        ></comtable>
        <div class="zhezhao" v-show="visible || creditorType"></div>
        <el-popover title="添加/编辑" popper-class="editData" v-model="visible">
          <el-form
            ref="form"
            :rules="rules"
            :model="editData"
            label-width="100px"
          >
            <span
              @click="resetForm('form')"
              class="el-icon-circle-close close"
            ></span>
            <el-form-item label="选择总账号" prop="parent_account_id">
              <el-col :span="22">
                <el-select
                  v-model="editData.parent_account_id"
                  placeholder="请选择总账号"
                >
                  <el-option
                    v-for="item in accounts"
                    :key="item.id"
                    :label="item.account_name"
                    :value="item.id + ',' + item.member_vip_id"
                  >
                  </el-option>
                </el-select>
              </el-col>
            </el-form-item>
            <el-form-item label="子账号名称" prop="account_name">
              <el-col :span="22">
                <el-input v-model="editData.account_name"></el-input>
              </el-col>
            </el-form-item>
            <el-form-item class="btn-box">
              <el-button
                type="primary"
                :loading="btnLoad"
                @click="submitForm('form')"
                >确定</el-button
              >
              <el-button @click="resetForm('form')">取消</el-button>
            </el-form-item>
          </el-form>
        </el-popover>
        <el-popover
          title="债权人"
          popper-class="creditor"
          v-model="creditorType"
        >
          <comCreditor
            :type="0"
            :loading="creditorLoading"
            @close="creditorClose"
            :tableData="creditorData"
          ></comCreditor>
        </el-popover>
        <comPaging
          :page="getData.page"
          :totalize="data.totalize"
          @watchChange="watchChange"
        ></comPaging>
      </div>
    </div>
    <div class="right">
      <comRelating v-show="isAdmin" :Data="childrenData"></comRelating>
      <comCreditoList
        v-show="!isAdmin"
        :account_id="account_id"
      ></comCreditoList>
    </div>
  </div>
</template>

<script lang="ts" src="./vipRelationship.ts"></script>

<style lang="scss">
@import "./vipRelationship.scss";
</style>
