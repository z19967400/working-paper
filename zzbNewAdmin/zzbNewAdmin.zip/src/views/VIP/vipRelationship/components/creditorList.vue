<template>
  <div class="creditorList-wrap">
    <div class="creditorList-box">
      <comselect
        :options="data.options"
        @select="search"
        @clear="clearSelection"
      ></comselect>
      <comOperation :totalize="data.totalize" @add="add"></comOperation>
      <comtable
        :tableData="data.list"
        :load="data.loading"
        :tableType="data.dataType"
        :creditor="true"
        @creditor="handCreditor"
        @Edit="handleEdit"
        @Delete="handleDelete"
      ></comtable>
      <div class="zhezhao" v-show="creditorType"></div>
      <el-popover title="债权人" popper-class="creditor" v-model="creditorType">
        <comCreditor
          :loading="creditorLoading"
          @close="creditorClose"
          @determine="determine"
          :tableData="creditorData"
        ></comCreditor>
      </el-popover>
      <comPaging
        :page="getData.page"
        :totalize="data.totalize"
        @watchChange="watchChange"
      ></comPaging>
      <div class="zhezhao" v-show="visible"></div>
      <el-popover title="添加/编辑" popper-class="editData" v-model="visible">
        <span
          @click="visible = !visible"
          class="el-icon-circle-close close"
        ></span>
        <comAdd :children="childrenData"></comAdd>
      </el-popover>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop, Watch } from "vue-property-decorator";
import {
  comselect,
  comOperation,
  comPaging,
  comtable
} from "../../../../components/index";
import { UserData, UserOptions } from "../../../../types/index";
import * as Api from "../../../../api/user";
import comCreditor from "./creditor.vue";
import comAdd from "../addEditAdmin.vue";
@Component({
  components: {
    comtable,
    comselect,
    comOperation,
    comPaging,
    comCreditor,
    comAdd
  }
})
export default class About extends Vue {
  // Getter
  // Action

  //prop
  @Prop() account_id: any;
  //wacth
  @Watch("account_id")
  DataChangeValue(newVal: any, oldVal: any) {
    // eslint-disable-next-line no-console
    console.log(newVal);
    this.getData.account_id = newVal;
    this.init();
  }
  // data
  data: UserData = {
    loading: false,
    list: [],
    select: {},
    totalize: 0,
    options: [
      {
        value: "id",
        label: "ID"
      },
      {
        value: "admin_name",
        label: "会员名称"
      },
      {
        value: "admin_phone_number",
        label: "债权人名称"
      },
      {
        value: "admin_email",
        label: "债权人类别"
      },
      {
        value: "audit_status",
        label: "审核状态"
      }
    ],
    dataType: [
      {
        label: "ID",
        prop: "id",
        width: "30px"
      },
      {
        label: "会员名称",
        prop: "admin_name",
        width: "80px"
      },
      {
        label: "债权人名称",
        prop: "creditor_name"
      },
      {
        label: "债权人类别",
        prop: "creditor_type_name"
      },
      {
        label: "审核状态",
        prop: "audit_status"
      },
      {
        label: "创建时间",
        prop: "create_time"
      }
    ]
  };
  getData: any = {
    page: 1,
    limit: this.$store.getters.limit,
    name: "", //会员名称
    admin_name: "", //管理员名称
    creditor_name: "", //债权人名称
    creditor_type: "", //审核状态
    audit_status: -1,
    account_id: 0
  };
  list: any = [];
  creditorData: any = [];
  creditorType: boolean = false;
  creditorLoading: boolean = false;
  member_vip_admin_id: number = 0;
  visible: boolean = false;
  childrenData: any = {};
  created() {
    //
  }

  activated() {
    //
  }

  mounted() {
    //
  }
  // 初始化函数
  init() {
    let self: any = this;
    let params: any =
      JSON.stringify(self.data.select) == "{}"
        ? self.getData
        : self.data.select;
    this.getList(params);
  }
  //获取数据
  getList(params: UserOptions["getVipRelationship"]) {
    let slef: any = this;
    slef.data.loading = true;
    Api.getAccountCreditor(params).then((res: any) => {
      slef.data.loading = false;
      if (res.data != undefined) {
        res.data.forEach((item: any) => {
          item.audit_status =
            item.audit_status == 0
              ? "待审核"
              : item.audit_status == 1
              ? "未通过"
              : "已通过";
        });
      }
      slef.data.list = res.data;
      slef.data.totalize = res.data.count;
    });
  }
  //编辑
  handleEdit(data: any) {
    // let id: number =
    //   data.row.parent_account_id == 0
    //     ? data.row.member_vip_account_id
    //     : data.row.parent_account_id;
    // this.childrenData = {
    //   id: data.row.id,
    //   mid: this.Data.mid || id
    // };
    this.visible = true;
  }
  //删除
  handleDelete(data: any) {
    Api.subAccountAdminDelet(data.row.id).then((res: any) => {
      let self: any = this;
      if (res.data != 0) {
        self.$message.success(res.msg);
        self.init();
      } else {
        self.$message.warning(res.msg);
      }
    });
  }
  //搜索
  search(data: any) {
    let self: any = this;
    self.data.loading = true;
    self.getData.page = 1;
    let params: any = Object.assign({}, self.getData);
    data.forEach((item: any) => {
      let name: string = item.label;
      params[name] = item.value;
    });
    self.data.select = params;
    this.getList(params);
  }
  //清除搜索项
  clearSelection(data: any) {
    let self: any = this;
    self.data.select = {};
    this.init();
  }
  //添加
  add() {
    // if (this.Data.mid == "") {
    //   this.$message.warning("请先选择左侧账户");
    //   return false;
    // }
    this.visible = true;
    // this.childrenData = {
    //   id: 0,
    //   mid: this.Data.mid
    // };
  }
  //债权人分配
  determine(data: any) {
    let parmas: any = {
      member_vip_account_id: this.getData.member_vip_account_id,
      member_vip_admin_id: this.member_vip_admin_id,
      ids: []
    };
    data.forEach((item: any) => {
      parmas.ids.push(item.id);
    });
    parmas.ids = parmas.ids.toString();
    Api.fenpeiCreditor(parmas).then((res: any) => {
      let self: any = this;
      if (res.data != 0) {
        self.$message.success(res.msg);
        self.creditorClose();
      } else {
        self.$message.warning(res.msg);
      }
    });
  }
  //债权人
  handCreditor(data: any) {
    this.creditorType = true;
    this.member_vip_admin_id = data.row.id;
    let id: number =
      data.row.parent_account_id == 0 || data.row.parent_account_id == undefined
        ? data.row.member_vip_account_id
        : data.row.parent_account_id;
    this.getUserCreditor(data.row.member_id, id);
  }
  //获取会员债权人
  getUserCreditor(id: number, mid: number) {
    this.creditorData = [];
    this.creditorLoading = true;
    Api.getUserCreditor(id, mid).then((res: any) => {
      this.creditorData = res.data;
      this.creditorLoading = false;
    });
  }
  //债权人弹窗关闭
  creditorClose() {
    this.creditorType = false;
  }
  //分页
  watchChange(index: number, limit: number | null) {
    let self: any = this;
    let params: any =
      JSON.stringify(self.data.select) == "{}"
        ? self.getData
        : self.data.select;
    params.page = index;
    params.limit = limit == null ? params.limit : limit;
    self.init();
  }
}
</script>

<style lang="scss">
@import "@/assets/scss/variables";

.creditorList-wrap {
  height: 100%;
  background-color: $main-body-bgColor;
  width: 100%;
  // position: relative;
  .creditor {
    width: 50%;
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
  }
  .zhezhao + button {
    display: none;
  }
  & .editData {
    width: 670px;
  }
}
</style>
