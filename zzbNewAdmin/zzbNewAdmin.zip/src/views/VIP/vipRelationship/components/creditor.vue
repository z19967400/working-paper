<template>
  <div class="creditor-wrap">
    <span @click="close" class="el-icon-close"></span>
    <el-table
      v-if="type != 0"
      ref="multipleTable"
      v-loading="data.loading"
      :data="data.tableData"
      style="width: 100%"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection"> </el-table-column>
      <el-table-column prop="creditor_name" label="债权人"></el-table-column>
      <el-table-column prop="phone_number" label="手机号"></el-table-column>
      <el-table-column prop="email" label="邮箱"></el-table-column>
    </el-table>
    <el-table
      v-else
      ref="multipleTable"
      v-loading="data.loading"
      :data="data.tableData"
      style="width: 100%"
    >
      <el-table-column prop="creditor_name" label="债权人"></el-table-column>
      <el-table-column prop="phone_number" label="手机号"></el-table-column>
      <el-table-column prop="email" label="邮箱"></el-table-column>
    </el-table>
    <div v-show="type != 0" class="btns">
      <el-button type="primary" size="small" @click="determine">确定</el-button>
      <el-button size="small" @click="cancel">取消</el-button>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop, Watch } from "vue-property-decorator";
import { Getter, Action } from "vuex-class";
// import {  } from "@/components" // 组件

@Component({})
export default class About extends Vue {
  // prop
  @Prop({}) tableData!: any;
  @Prop({ default: false }) loading!: boolean;
  @Prop({}) type?: number;
  //watch
  @Watch("tableData")
  dataChangeValue(newVal: any, oldVal: any) {
    this.data.tableData = newVal;
  }
  @Watch("loading")
  loadingChangeValue(newVal: any, oldVal: any) {
    this.data.loading = newVal;
  }
  // data
  data: any = {
    tableData: [],
    loading: false,
    multipleSelection: []
  };

  created() {
    //
  }

  activated() {
    //
  }

  mounted() {
    //
  }
  // 确定
  determine() {
    this.$emit("determine", this.data.multipleSelection);
  }
  //取消
  cancel() {
    this.data.multipleSelection = [];
    this.$emit("close", "");
  }
  //关闭
  close() {
    this.$emit("close", "");
  }
  //多选数据
  handleSelectionChange(val: any) {
    this.data.multipleSelection = val;
  }
}
</script>

<style lang="scss">
@import "@/assets/scss/variables";

.creditor-wrap {
  width: 100%;
  .el-icon-close {
    position: absolute;
    right: 15px;
    top: 15px;
    cursor: pointer;
    font-size: 16px;
  }
  .btns {
    text-align: center;
    margin-top: 20px;
  }
}
</style>
