import { Component, Vue, Prop, Watch } from "vue-property-decorator";
import {
  comselect,
  comOperation,
  comPaging,
  comtable
} from "@/components/index";
import { UserData, UserOptions } from "@/types/index.ts";
import * as Api from "@/api/user.ts";
import comCreditor from "./components/creditor.vue";
import comAdd from "./addEditAdmin.vue";
@Component({
  components: {
    comtable,
    comselect,
    comOperation,
    comPaging,
    comCreditor,
    comAdd
  }
})
export default class About extends Vue {
  // Getter
  // Action

  //prop
  @Prop() Data: any;
  //wacth
  @Watch("Data", { deep: true })
  DataChangeValue(newVal: any, oldVal: any) {
    this.getData.member_vip_account_id = newVal.member_vip_account_id;
    this.init();
  }
  // data
  data: UserData = {
    loading: false,
    list: [],
    select: {},
    totalize: 0,
    options: [
      {
        value: "id",
        label: "ID"
      },
      {
        value: "admin_name",
        label: "姓名"
      },
      {
        value: "admin_phone_number",
        label: "手机号"
      },
      {
        value: "admin_email",
        label: "邮箱"
      }
    ],
    dataType: [
      {
        label: "ID",
        prop: "id",
        width: "30px"
      },
      // {
      //   label: "头像",
      //   prop: "admin_head_img",
      //   width: "60px"
      // },
      {
        label: "姓名",
        prop: "admin_name",
        width: "80px"
      },
      {
        label: "手机号",
        prop: "admin_phone_number"
      },
      {
        label: "邮箱",
        prop: "admin_email"
      },
      // {
      //   label: "债权人数量",
      //   prop: "admin_phone_number"
      // },
      {
        label: "审核状态",
        prop: "audit_status"
      },
      {
        label: "创建时间",
        prop: "create_time"
      }
    ]
  };
  getData: any = {
    page: 1,
    limit: this.$store.getters.limit,
    member_vip_account_id: 0,
    admin_name: "",
    admin_phone_number: "",
    admin_email: ""
  };
  list: any = [
    {
      ID: 1,
      headeImg:
        "http://file.zhaizhubang.net/Img/20200618/90bc9e7a-b951-47fd-9df7-4704e9ea5e7e.jpg",
      name: "会员xxx",
      phone: "18897924015",
      email: "1269674774@qq.com",
      leibie: "律师",
      renzhen: "个人",
      state: 0,
      created_time: "2020-02-02"
    }
  ];
  creditorData: any = [];
  creditorType: boolean = false;
  creditorLoading: boolean = false;
  member_vip_admin_id: number = 0;
  visible: boolean = false;
  childrenData: any = {};
  created() {
    //
  }

  activated() {
    let self: any = this;
    // self.getData.member_vip_account_id =
    //   self.$route.query.member_vip_account_id;
    // self.getData.member_vip_account_id = this.Data.member_vip_account_id;
    self.init();
  }

  mounted() {
    //
  }
  // 初始化函数
  init() {
    let self: any = this;
    let params: any =
      JSON.stringify(self.data.select) == "{}"
        ? self.getData
        : self.data.select;
    this.getList(params);
  }
  //获取数据
  getList(params: UserOptions["getVipRelationship"]) {
    let data: any = this.data;
    data.loading = true;
    data.list = this.list;
    Api.getVipRelatAdmin(params).then((res: any) => {
      data.loading = false;
      data.list = res.data.data;
      data.list.forEach((item: any) => {
        item.audit_status =
          item.audit_status == 0
            ? "待审核"
            : item.audit_status == 1
            ? "未通过"
            : "已通过";
      });
      data.totalize = res.data.count;
    });
  }
  //编辑
  handleEdit(data: any) {
    let id: number =
      data.row.parent_account_id == 0
        ? data.row.member_vip_account_id
        : data.row.parent_account_id;
    this.childrenData = {
      id: data.row.id,
      mid: this.Data.mid || id
    };
    this.visible = true;
    // this.$router.push({
    //   path: "/VIP/addEditAdmin",
    //   query: {
    //     id: data.row.id,
    //     // mid: this.$route.query.mid
    //     mid: this.Data.mid || id
    //   }
    // });
  }
  //删除
  handleDelete(data: any) {
    Api.subAccountAdminDelet(data.row.id).then((res: any) => {
      if (res.data != 0) {
        this.$message.success(res.msg);
        this.init();
      } else {
        this.$message.warning(res.msg);
      }
    });
  }
  //搜索
  search(data: any) {
    let self: any = this;
    self.data.loading = true;
    self.getData.page = 1;
    let params: any = Object.assign({}, self.getData);
    data.forEach((item: any) => {
      let name: string = item.label;
      params[name] = item.value;
    });
    self.data.select = params;
    this.getList(params);
  }
  //清除搜索项
  clearSelection(data: any) {
    let self: any = this;
    self.data.select = {};
    this.init();
  }
  //添加
  add() {
    if (this.Data.mid == "") {
      this.$message.warning("请先选择左侧账户");
      return false;
    }
    this.visible = true;
    this.childrenData = {
      id: 0,
      mid: this.Data.mid
    };
    // this.$router.push({
    //   path: "/VIP/addEditAdmin",
    //   query: {
    //     id: "0",
    //     // mid: this.$route.query.mid
    //     mid: this.Data.mid
    //   }
    // });
  }
  //债权人分配
  determine(data: any) {
    let parmas: any = {
      member_vip_account_id: this.getData.member_vip_account_id,
      member_vip_admin_id: this.member_vip_admin_id,
      ids: []
    };
    data.forEach((item: any) => {
      parmas.ids.push(item.id);
    });
    parmas.ids = parmas.ids.toString();
    Api.fenpeiCreditor(parmas).then((res: any) => {
      if (res.data != 0) {
        this.$message.success(res.msg);
        this.creditorClose();
      } else {
        this.$message.warning(res.msg);
      }
    });
  }
  //债权人
  handCreditor(data: any) {
    this.creditorType = true;
    this.member_vip_admin_id = data.row.id;
    let id: number =
      data.row.parent_account_id == 0
        ? data.row.member_vip_account_id
        : data.row.parent_account_id;
    this.getUserCreditor(data.row.id, id);
  }
  //获取会员债权人
  getUserCreditor(id: number, mid: number) {
    this.creditorData = [];
    this.creditorLoading = true;
    Api.getUserCreditor(id, mid).then((res: any) => {
      this.creditorData = res.data;
      this.creditorLoading = false;
    });
  }
  //债权人弹窗关闭
  creditorClose() {
    this.creditorType = false;
  }
  //分页
  watchChange(index: number, limit: number | null) {
    let self: any = this;
    let params: any =
      JSON.stringify(self.data.select) == "{}"
        ? self.getData
        : self.data.select;
    params.page = index;
    params.limit = limit == null ? params.limit : limit;
    self.init();
  }
}
