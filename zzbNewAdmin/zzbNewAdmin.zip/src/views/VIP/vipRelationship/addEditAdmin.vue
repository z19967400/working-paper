<template>
  <div class="addEditAdmin-wrap">
    <div class="addEditAdmin-box">
      <el-form
        ref="form"
        :rules="data.rules"
        :inline="true"
        :model="data.edit"
        label-width="120px"
        :style="{ height: height + 'px' }"
      >
        <el-form-item
          size="small"
          label="选择子账户"
          prop="member_vip_account_id"
        >
          <el-select
            v-model="data.edit.member_vip_account_id"
            placeholder="请选择子账户"
          >
            <el-option
              v-for="item in data.subAccounts"
              :key="item.id"
              :label="item.account_name"
              :value="item.id"
            ></el-option>
          </el-select>
        </el-form-item>
        <div>
          <el-form-item label="头像" prop="admin_head_img">
            <el-upload
              class="avatar-uploader"
              :action="burl + '/Upload/UploadImage?type=0'"
              :show-file-list="false"
              :on-success="handleAvatarSuccess"
              :before-upload="beforeAvatarUpload"
            >
              <img
                v-if="data.edit.admin_head_img != ''"
                :src="data.edit.admin_head_img"
                class="avatar"
              />
              <i v-else class="el-icon-plus avatar-uploader-icon"></i>
            </el-upload>
          </el-form-item>
          <el-form-item label="授权书" prop="authorization_img">
            <el-upload
              class="avatar-uploader"
              :action="burl + '/Upload/UploadImage?type=0'"
              :show-file-list="false"
              :on-success="handleAvatarSuccess2"
              :before-upload="beforeAvatarUpload"
            >
              <img
                v-if="data.edit.authorization_img != ''"
                :src="data.edit.authorization_img"
                class="avatar"
              />
              <i v-else class="el-icon-plus avatar-uploader-icon"></i>
            </el-upload>
          </el-form-item>
        </div>
        <div>
          <el-form-item size="small" label="管理员账号" prop="admin_account">
            <el-input v-model="data.edit.admin_account"></el-input>
          </el-form-item>
          <el-form-item size="small" label="管理员姓名" prop="admin_name">
            <el-input v-model="data.edit.admin_name"></el-input>
          </el-form-item>
        </div>
        <div>
          <el-form-item
            size="small"
            label="管理员手机"
            prop="admin_phone_number"
          >
            <el-input v-model="data.edit.admin_phone_number"></el-input>
          </el-form-item>
          <el-form-item size="small" label="管理员邮箱" prop="admin_email">
            <el-input v-model="data.edit.admin_email"></el-input>
          </el-form-item>
        </div>
        <div>
          <el-form-item size="small" label="身份证号码" prop="id_number">
            <el-input v-model="data.edit.id_number"></el-input>
          </el-form-item>
        </div>
        <div style="position: relative;top: 15px;" v-if="sandType">
          <el-form-item size="small" label="登录密码">
            <el-select
              v-model="data.passworldsandEmail"
              placeholder="请选择发送邮箱"
            >
              <el-option
                v-for="item in data.adminEmail"
                :key="item.email"
                :label="item.name"
                :value="item.email"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-button @click="sendOut" size="small" type="primary" plain
            >发送</el-button
          >
          <el-button @click="Reset" size="small" type="primary" plain
            >重置</el-button
          >
        </div>
        <!-- <div>
          <el-form-item size="small" label="设为管理员" prop="is_super">
            <el-radio-group
              style="line-height: 40px;"
              v-model="data.edit.is_super"
            >
              <el-radio label="是"></el-radio>
              <el-radio label="否"></el-radio>
            </el-radio-group>
          </el-form-item>
        </div>
        <div>
          <el-form-item
            size="small"
            label="设为总管理员"
            prop="is_account_admin"
          >
            <el-radio-group
              style="line-height: 40px;"
              v-model="data.edit.is_account_admin"
            >
              <el-radio label="是"></el-radio>
              <el-radio label="否"></el-radio>
            </el-radio-group>
          </el-form-item>
        </div> -->
        <div style="margin-top:10px;">
          <el-form-item size="small" label="审核状态" prop="audit_status">
            <el-radio-group
              style="line-height: 40px;"
              v-model="data.edit.audit_status"
            >
              <el-radio label="待审核"></el-radio>
              <el-radio label="未通过"></el-radio>
              <el-radio label="已通过"></el-radio>
            </el-radio-group>
          </el-form-item>
        </div>
        <div>
          <el-form-item size="small" label="审核反馈" prop="audit_feedback">
            <el-input
              type="textarea"
              v-model="data.edit.audit_feedback"
            ></el-input>
          </el-form-item>
        </div>
        <el-form-item
          style="margin-bottom:0;margin-left:120px;"
          class="edit-bottom-bin"
        >
          <el-button
            :loading="data.submitType"
            type="primary"
            @click="submitForm('form')"
            >确定</el-button
          >
          <el-button @click="resetForm('form')">取消</el-button>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop, Watch } from "vue-property-decorator";
import { Getter, Action } from "vuex-class";
import * as Api from "../../../api/user";
import { baseURL } from "../../../utils/request";
import { verifyPhone, verifyEmall, verifyIdCard } from "../../../utils/common";
@Component({})
export default class About extends Vue {
  //prop
  @Prop() children!: any;
  //watch
  @Watch("children", { deep: true })
  childrenChangeValue(newVal: any, oldVal: any) {
    let self: any = this;
    self.data.edit.id = newVal.id;
    self.getSubAccounts(newVal.mid);
    self.getAdminEmail();
    if (self.data.edit.id != 0) {
      self.getInfo(self.data.edit.id);
      this.sandType = true;
    } else {
      this.sandType = false;
      let from: any = this.$refs["form"];
      from.resetFields();
    }
    self.data.edit.member_vip_account_id = newVal.mid;
  }
  //手机号码验证
  validatePhone = (rule: any, value: any, callback: any) => {
    let vtf: any = verifyPhone(value);
    if (!vtf.done) {
      callback(new Error(vtf.errMsg));
    } else {
      callback();
    }
  };
  //邮箱验证
  validateEmall = (rule: any, value: any, callback: any) => {
    let vtf: any = verifyEmall(value);
    if (!vtf.done) {
      callback(new Error(vtf.errMsg));
    } else {
      callback();
    }
  };
  //身份证验证
  validateIdCard = (rule: any, value: any, callback: any) => {
    let vtf: any = verifyIdCard(value);
    if (!vtf.done) {
      callback(new Error(vtf.errMsg));
    } else {
      callback();
    }
  };
  // data
  data: any = {
    edit: {
      id: 0,
      member_vip_account_id: "",
      admin_head_img: "",
      authorization_img: "",
      admin_name: "",
      admin_phone_number: "",
      admin_email: "",
      admin_account: "",
      // id_number: "",
      // is_super: "",
      is_account_admin: "",
      audit_status: "",
      audit_feedback: ""
    },
    passworldsandEmail: "", //登录密码发送邮箱
    submitType: false,
    subAccounts: [],
    adminEmail: [],
    rules: {
      member_vip_account_id: [
        { required: true, message: "请选择子账户", trigger: "change" }
      ],
      authorization_img: [
        { required: true, message: "请上传授权书", trigger: "blur" }
      ],
      admin_account: [
        { required: true, message: "请输入管理员账号", trigger: "blur" }
      ],
      id_number: [
        { required: true, validator: this.validateIdCard, trigger: "blur" }
      ],
      is_super: [
        { required: true, message: "请选择是否为管理员", trigger: "blur" }
      ],
      is_account_admin: [
        { required: true, message: "请选择是否为总管理员", trigger: "blur" }
      ],
      audit_status: [
        { required: true, message: "请选择审核状态", trigger: "blur" }
      ],
      admin_name: [
        { required: true, message: "请输入管理员姓名", trigger: "blur" }
      ],
      admin_phone_number: [
        { required: true, validator: this.validatePhone, trigger: "blur" }
      ],
      admin_email: [
        { required: true, validator: this.validateEmall, trigger: "blur" }
      ],
      audit_feedback: [
        { required: true, message: "请输入审核反馈", trigger: "blur" },
        { max: 200, message: "长度不能超过200个字符", trigger: "blur" }
      ]
    }
  };
  height: number = 0;
  burl: string = "";
  sandType: boolean = false;
  created() {
    let self:any = this
    // this.height = document.body.offsetHeight - 180;
    // let bH: number = this.sandType ? 40 : 0;
    self.height = 569;
    self.burl = baseURL;
  }

  activated() {
    // this.init();
  }

  mounted() {
    //
  }

  beforeDestroy() {
    //
  }

  // init() {
  //   let self: any = this;
  //   self.data.edit.id = self.$route.query.id;
  //   self.getSubAccounts(self.$route.query.mid);
  //   self.getAdminEmail();
  //   if (self.data.edit.id != 0) {
  //     self.getInfo(self.data.edit.id);
  //     this.sandType = true;
  //   } else {
  //     this.sandType = false;
  //     let from: any = this.$refs["form"];
  //     from.resetFields();
  //   }
  //   self.data.edit.member_vip_account_id = self.$route.query.mid;
  // }
  //获取详情
  getInfo(id: number) {
    Api.getVipSubAccountInfo(id).then((res: any) => {
      this.data.edit = res.data;
      this.sandType = res.data.audit_status == 2;
      this.data.edit.audit_status =
        this.data.edit.audit_status == 0
          ? "待审核"
          : this.data.edit.audit_status == 1
          ? "未通过"
          : "已通过";
      this.data.edit.is_super = this.data.edit.is_super == 0 ? "否" : "是";
      this.data.edit.is_account_admin =
        this.data.edit.is_account_admin == 0 ? "否" : "是";
    });
  }
  //获取管理员邮箱
  getAdminEmail() {
    Api.getAdminEmail().then((res: any) => {
      this.data.adminEmail = res.data;
    });
  }
  //表单提交
  submitForm(formName: string) {
    let from: any = this.$refs[formName];
    let self: any = this;
    from.validate((valid: Boolean) => {
      if (valid) {
        self.data.submitType = true;
        self.data.edit.is_super = self.data.edit.is_super == "是" ? 1 : 0;
        self.data.edit.is_account_admin =
          self.data.edit.is_account_admin == "是" ? 1 : 0;
        self.data.edit.audit_status =
          self.data.edit.audit_status == "待审核"
            ? 0
            : self.data.edit.audit_status == "未通过"
            ? 1
            : 2;
        Api.vipSubAccountEdit(self.data.edit).then((res: any) => {
          if (res.data == 1) {
            self.resetForm("form");
            self.$message.success(res.msg);
            setTimeout(() => {
              self.data.submitType = false;
              self.$router.go(-1);
            }, 1000);
          } else {
            self.$message.warning(res.msg);
            self.data.submitType = false;
          }
        });
      } else {
        // eslint-disable-next-line no-console
        console.log("error submit!!");
        return false;
      }
    });
  }
  //获取子账号下拉
  getSubAccounts(id: number) {
    Api.getSubAccountSelect(id).then((res: any) => {
      this.data.subAccounts = res.data;
    });
  }
  //发送
  sendOut() {
    let self: any = this;
    let parmas: any = {
      id: self.$route.query.id,
      password: self.data.edit.password,
      send_number: self.data.edit.admin_email,
      type: 1
    };
    Api.sendPassword(parmas).then((res: any) => {
      if (res.data != 0) {
        this.$message.success(res.msg);
      } else {
        this.$message.warning(res.msg);
      }
    });
  }
  //重置
  Reset() {
    let self: any = this;
    let parmas: any = {
      id: self.$route.query.id,
      password: self.data.edit.password,
      send_number: self.data.edit.admin_email,
      type: 0
    };
    Api.sendPassword(parmas).then((res: any) => {
      if (res.data != 0) {
        this.$message.success(res.msg);
      } else {
        this.$message.warning(res.msg);
      }
    });
  }
  //头像上传
  handleAvatarSuccess(res: any, file: any) {
    let self: any = this;
    if (res.data.State == true) {
      this.$message.success(res.data.Msg);
      self.data.edit.admin_head_img =
        "http://file.zhaizhubang.net" +
        res.data.FileUrl +
        res.data.FileExtension;
    } else {
      this.$message.warning(res.data.Msg);
    }
  }
  //授权书上传
  handleAvatarSuccess2(res: any, file: any) {
    let self: any = this;
    if (res.data.State == true) {
      this.$message.success(res.data.Msg);
      self.data.edit.authorization_img =
        "http://file.zhaizhubang.net" +
        res.data.FileUrl +
        res.data.FileExtension;
    } else {
      this.$message.warning(res.data.Msg);
    }
  }
  beforeAvatarUpload(file: any) {
    const isLt2M = file.size / 1024 / 1024 < 2;
    if (!isLt2M) {
      this.$message.error("上传头像图片大小不能超过 2MB!");
    }
    return isLt2M;
  }
  //重置表单
  resetForm(formName: string) {
    let from: any = this.$refs[formName];
    from.resetFields();
  }
}
</script>

<style lang="scss">
@import "@/assets/scss/variables";

.addEditAdmin-wrap {
  width: 100%;
  min-height: 100%;
  background-color: $main-body-bgColor;
  .addEditAdmin-box {
    .el-form {
      overflow-y: auto;
      .el-form-item__content {
        line-height: normal;
      }
      .el-textarea__inner {
        height: 100px;
        width: 520px;
      }
    }
  }
}
</style>
