<template>
  <div class="addVip-wrap">
    <div class="addVip-box">
      <el-form :model="add" :rules="data.rules" :inline="true" class="demo-form-inline demo-ruleForm" ref="ruleForm" label-width="100px" :style="{ height: height + 'px' }">

        <el-form-item label="企业名称" prop="corporate_name">
          <el-input v-model="add.corporate_name"></el-input>
        </el-form-item>
        <el-form-item label="联系人" prop="contacts_name">
          <el-input v-model="add.contacts_name"></el-input>
        </el-form-item>
        <el-form-item label="联系电话" prop="phone_number">
          <el-input v-model="add.phone_number"></el-input>
        </el-form-item>
        <el-form-item label="电子邮箱" prop="email">
          <el-input v-model="add.email"></el-input>
        </el-form-item>
        <el-form-item label="所属行业" prop="industry">
          <el-input v-model="add.industry"></el-input>
        </el-form-item>
        <!-- <el-row>
          <el-form-item label="债务类别" prop="debt_type">
            <el-select v-model="add.debt_type" placeholder="选择债务类别">
              <el-option
                v-for="item in data.debt_types"
                :key="item.dic_code"
                :label="item.dic_content"
                :value="item.dic_code"
              ></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="年催需求" prop="demand_quantity">
            <el-select v-model="add.demand_quantity" placeholder="选择年催需求">
              <el-option label="1-10" value="1-10"></el-option>
              <el-option label="10-100" value="10-100"></el-option>
              <el-option label="100-1000" value="100-1000"></el-option>
              <el-option label="1000以上" value="1000以上"></el-option>
            </el-select>
          </el-form-item>
        </el-row> -->
        <el-form-item style="margin-top:20px;" label="需求描述" prop="desc">
          <el-input type="textarea" v-model="add.requirement_desc"></el-input>
        </el-form-item>
        <!-- <el-form-item label="后台备注" prop="desc">
          <el-input type="textarea" v-model="add.back_remarks"></el-input>
        </el-form-item> -->
      </el-form>
      <el-col class="edit-bottom-bin" :span="12">
        <el-button style="margin-left: 100px;" type="primary" :loading="data.submitType" @click="submitForm('ruleForm')">确定</el-button>
        <el-button @click="resetForm('ruleForm')">取消</el-button>
      </el-col>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator'
import { Getter, Action } from 'vuex-class'
import * as Api from '../../../api/user'
import { UserOptions } from '../../../types/index'
import { verifyPhone, verifyEmall } from '../../../utils/common'
@Component({})
export default class About extends Vue {
  //prop
  @Prop() userData?: any
  //watch
  @Watch('userData', { deep: true })
  userDataChange(newVal: any, oldVal: any) {
    let self: any = this
    self.add.contacts_name = newVal.name
    self.add.email = newVal.email
    self.add.phone_number = newVal.phone_number
    self.add.member_id = newVal.member_id || 0
  }
  //邮箱规则验证
  validateEmall = (rule: any, value: any, callback: any) => {
    let vtf: any = verifyEmall(value)
    if (!vtf.done) {
      callback(new Error(vtf.errMsg))
    } else {
      callback()
    }
  }
  //手机号码验证
  validatePhone = (rule: any, value: any, callback: any) => {
    let vtf: any = verifyPhone(value)
    if (!vtf.done) {
      callback(new Error(vtf.errMsg))
    } else {
      callback()
    }
  }
  // data
  data: any = {
    submitType: false,
    rules: {
      corporate_name: [
        { required: true, message: '请输入公司名称', trigger: 'blur' },
        { max: 40, message: '长度不能超过40个字符', trigger: 'blur' },
      ],
      contacts_name: [
        { required: true, message: '请输入联系人', trigger: 'blur' },
        { max: 40, message: '长度不能超过40个字符', trigger: 'blur' },
      ],
      email: [{ required: true, validator: this.validateEmall, trigger: 'blur' }],
      phone_number: [{ required: true, validator: this.validatePhone, trigger: 'blur' }],
      debt_type: [{ required: true, message: '请选择债务类别', trigger: 'change' }],
      demand_quantity: [{ required: true, message: '请输入年催需求', trigger: 'change' }],
    },
    debt_types: [],
  }
  // add: UserOptions["addVip"] = {
  //   id: 0,
  //   member_id: 0,
  //   corporate_name: "", //公司名称
  //   phone_number: "", //手机号
  //   contacts_name: "", //联系人
  //   email: "", //邮箱
  //   debt_type: "", //催收场景
  //   demand_quantity: "", //年催需求
  //   back_remarks: "" // 后台备注
  // };
  add: any = {
    id: 0,
    member_id: 0,
    corporate_name: '', //公司名称
    phone_number: '', //手机号
    contacts_name: '', //联系人
    email: '', //邮箱
    industry: '', //行业
    requirement_desc: '', // 后台备注
  }
  height: number = 0
  created() {
    // this.height = document.body.offsetHeight - 180;
    this.height = 350
  }

  activated() {
    let self: any = this
    let from: any = self.$refs['ruleForm']
    self.add.back_remarks = ''
    from.resetFields()
    self.getDebt_types()
  }

  mounted() {
    //
  }
  //获取催收场景
  getDebt_types() {
    Api.GetType('Debt_type').then((res: any) => {
      this.data.debt_types = res.data
    })
  }
  //表单提交
  submitForm(formName: string) {
    let from: any = this.$refs[formName]
    let self: any = this
    from.validate((valid: Boolean) => {
      if (valid) {
        self.data.submitType = true
        Api.addVip(self.add).then((res: any) => {
          if (res.data != 0) {
            self.$message.success(res.msg)
            setTimeout(() => {
              this.data.submitType = false
              // self.$router.push({
              //   path: "/VIP/vipApply"
              // });
              this.$emit('determine')
            }, 1000)
          } else {
            self.$message.warning(res.msg)
            this.data.submitType = false
          }
        })
      } else {
        // eslint-disable-next-line no-console
        console.log('error submit!!')
        return false
      }
    })
  }
  //重置表单
  resetForm(formName: string) {
    let from: any = this.$refs[formName]
    let self: any = this
    from.resetFields()
    // self.$router.push({
    //   path: "/VIP/vipApply"
    // });
    this.$emit('cancel')
  }
}
</script>

<style lang="scss">
@import '@/assets/scss/variables';

.addVip-wrap {
  width: 100%;
  min-height: 100%;
  background-color: $main-body-bgColor;
  .addVip-box {
    .el-form {
      overflow-y: auto;
      .el-form-item__content {
        line-height: normal;
      }
      .ql-container {
        height: 300px;
      }
    }
  }
  .el-textarea__inner {
    width: 520px;
    height: 100px;
  }
  .el-select {
    width: 202px;
  }
}
</style>
