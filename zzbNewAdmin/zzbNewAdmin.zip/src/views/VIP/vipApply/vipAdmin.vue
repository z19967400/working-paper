<template>
  <div class="vipAdmin-wrap">
    <div class="vipAdmin-box">
      <div :style="{ height: data.labers.length * 40 + 'px' }" class="left">
        <div class="text">
          <div v-for="(item, index) in data.labers" :key="index" :class="{ act: index == data.actIndex }" @click="laberClick(index)">
            {{ item.name }}
          </div>
        </div>
        <div class="shuxian-box">
          <div :style="{ transform: ' translateY(' + data.actIndex * 40 + 'px)' }" class="shuxian"></div>
        </div>
      </div>
      <div class="right" ref="right" :style="{ height: height + 'px' }">
        <div class="section" ref="section0">
          <span style="margin-top:0;" :class="{ act: data.actIndex == 0 }">
            <span class="title">申请信息</span>
            <el-button class="edit" @click="editVip" type="text" size="small">{{ BasicInfoEdit ? "返回" : "编辑" }}</el-button>
          </span>
          <el-divider></el-divider>
          <!-- 申请信息展示内容 -->
          <div v-if="!BasicInfoEdit" class="box">
            <div v-for="(item, index) in data.BasicInfo" :key="index" class="text">
              <p v-for="(item2, index2) in item" :key="index2">
                <span>{{ item2.name }}</span>
                <span>{{ item2.value }}</span>
              </p>
            </div>
          </div>
          <!-- 申请信息内容编辑 -->
          <el-form v-if="BasicInfoEdit" label-width="80px" :inline="true" :model="edit.BasicInfo" class="demo-form-inline" :rules="edit.BasicInfoRules">
            <div class="box">
              <div class="text">
                <el-form-item label="企业名称" prop="corporate_name">
                  <el-input v-model="edit.BasicInfo.corporate_name" placeholder="请输入企业名称"></el-input>
                </el-form-item>
                <el-form-item label="邮箱" prop="email">
                  <el-input v-model="edit.BasicInfo.email" placeholder="请输入邮箱"></el-input>
                </el-form-item>
              </div>
              <div class="text">
                <el-form-item label="联系人" prop="contacts_name">
                  <el-input v-model="edit.BasicInfo.contacts_name" placeholder="请输入联系人"></el-input>
                </el-form-item>
                <el-form-item label="行业" prop="industry">
                  <el-input v-model="edit.BasicInfo.industry" placeholder="请输入行业"></el-input>
                </el-form-item>
              </div>
              <div class="text">
                <el-form-item label="手机号码" prop="phone_number">
                  <el-input v-model="edit.BasicInfo.phone_number" placeholder="请输入手机号码"></el-input>
                </el-form-item>
                <el-form-item label="需求描述" prop="requirement_desc">
                  <el-input v-model="edit.BasicInfo.requirement_desc" placeholder="请输入需求"></el-input>
                </el-form-item>
              </div>
            </div>
            <el-form-item style="padding-left:40px;">
              <el-button type="primary" @click="vipUserEditi" size="small">保存</el-button>
              <el-button @click="BasicInfoEdit = !BasicInfoEdit" size="small">取消</el-button>
            </el-form-item>
          </el-form>
        </div>
        <div class="section" ref="section1">
          <span style="margin-top:0;" :class="{ act: data.actIndex == 1 }">
            <span class="title">会员信息</span>
            <el-button v-if="data.memberInfo.member_id != 0" class="edit" @click="goMenber(data.memberInfo.member_id)" type="text" size="small">管理</el-button>
          </span>
          <el-divider></el-divider>
          <div v-if="data.memberInfo.member_id == 0">
            <el-button type="primary" size="small" @click="openSelect()">绑定普通会员</el-button>
          </div>
          <!-- 会员信息展示 -->
          <div v-else class="box">
            <el-row style="width:100%;">
              <span class="lable">ID</span>
              <span class="value">{{data.memberInfo.member_id}}</span>
              <span class="lable">名称</span>
              <span style="color: #303133;font-size: 14px;">{{data.memberInfo.name}}</span>
            </el-row>
          </div>
          <div class="box">
            <el-form label-width="80px" :inline="true" :model="edit.addNewVip" class="demo-form-inline" :rules="edit.addNewVipRules">
            </el-form>
          </div>
        </div>
        <div v-show="data.BasicInfo[0][2].value == '已通过'" class="section" ref="section2">
          <span style="margin-top:0;" :class="{ act: data.actIndex == 2 }">
            <span class="title">支付管理</span>
            <el-button class="edit" @click="paySetType" type="text" size="small">{{ paySetTypeEdit ? "返回" : "编辑" }}</el-button>
          </span>
          <el-divider></el-divider>
          <!-- 支付管理展示 -->
          <div v-if="!paySetTypeEdit" class="box">
            <div class="text">
              <p>
                <span>先催后付</span>
                <span> {{ data.pay_set.is_postpaid ==1 ? "开通" : "未开通" }}</span>
              </p>
              <p>
                <span>标准AI律师函</span>
                <span>{{ data.pay_set.standard_ai_price }} 元</span>
              </p>
              <p>
                <span>电子AI律师函</span>
                <span>{{ data.pay_set.electron_ai_price }} 元</span>
              </p>
            </div>
          </div>
          <!-- 支付管理编辑 -->
          <el-form :model="edit.pay_set" :rules="edit.pay_setRules" label-width="120px" class="demo-ruleForm" v-if="paySetTypeEdit">
            <div class="box">
              <div class="text">
                <el-form-item label="先催后付">
                  <el-radio-group v-model="edit.pay_set.is_postpaid">
                    <el-radio :label="0">关闭</el-radio>
                    <el-radio :label="1">开通</el-radio>
                  </el-radio-group>
                </el-form-item>
                <el-form-item label="标准AI律师函" prop="standard_ai_price">
                  <el-input v-model="edit.pay_set.standard_ai_price"></el-input>
                </el-form-item>
                <el-form-item label="电子AI律师函" prop="electron_ai_price">
                  <el-input v-model="edit.pay_set.electron_ai_price"></el-input>
                </el-form-item>
                <el-form-item>
                  <el-button @click="paySetEdit" type="primary">保存</el-button>
                  <el-button @click="paySetCancel">取消</el-button>
                </el-form-item>
              </div>
            </div>
          </el-form>
        </div>
        <div v-show="data.BasicInfo[0][2].value == '已通过'" class="section" ref="section3">
          <span style="margin-top:0;" :class="{ act: data.actIndex == 3 }">
            <span class="title">账户管理</span>
            <el-button class="edit" @click="addAccount" type="text" size="small">新增</el-button>
          </span>
          <el-divider></el-divider>
          <!-- 账户管理列表 -->
          <table1 @addAdmin="addAdmin2" @Edit="adminEdit" @Delete="accmentDel" :tableData="data.account_list"></table1>
        </div>
        <div v-show="data.BasicInfo[0][2].value == '已通过'" class="section" ref="section4">
          <span style="margin-top:0;" :class="{ act: data.actIndex == 4 }">
            <span class="title">管理员管理</span>
          </span>
          <el-divider></el-divider>
          <table2 @Edit="editAdmin" @addCreditor="addCreditor" @examine="adminExamine" @Delete="adminDel" :tableData="data.admin_list"></table2>
        </div>
        <div v-show="data.BasicInfo[0][2].value == '已通过'" class="section" ref="section5">
          <span style="margin-top:0;" :class="{ act: data.actIndex == 5 }">
            <span class="title">债权人信息</span>
          </span>
          <el-divider></el-divider>
          <table3 @Edit="editCreditor" @settingAdmin="settingAdmin" @examine="creditorExamine" :tableData="data.creditorList"></table3>
        </div>
        <div class="section" ref="section6">
          <span style="margin-top:0;" :class="{ act: data.actIndex == 6 }">
            <span class="title">后台备注</span>
          </span>
          <el-divider></el-divider>
          <el-form :model="data.passwordAdmin">
            <el-form-item label="备注">
              <el-input type="textarea" :rows="4" v-model="data.back_remarks"></el-input>
            </el-form-item>
            <el-form-item style="padding-left:40px;">
              <el-button type="primary" @click="beizhu" size="small">保存</el-button>
            </el-form-item>
          </el-form>
        </div>
      </div>
      <div class="footer">
        <el-button @click="goBaack" plain>返回</el-button>
        <el-button @click="footerShenhe" plain>审核</el-button>
        <el-button @click="handDelete" type="primary">删除</el-button>
      </div>
      <div class="zhezhao" v-show="data.addNewUserIsShow || data.selectUserIsShow"></div>
      <el-popover title="选择已有普通会员" popper-class="selectUser" v-model="data.selectUserIsShow">
        <comUserSelect :tabeData="selectList" @search="search" @guanbi="selectUserClose" @clearSelection="clearSelection" @xuanze="xuanze"></comUserSelect>
      </el-popover>
      <el-popover title="审核" popper-class="selectUser" v-model="examineType">
        <i @click="examineType = false" class="el-icon-close close"></i>
        <div v-if="data.examineData.type == 1|| data.examineData.type == 2" class="examineData">
          <el-row style="width:100%;margin-bottom:20px;" v-for="(item,index) in examineState" :key="index">
            <el-col style="margin-right:15px;" :span="3">{{item.name}}</el-col>
            <el-col v-if="item.name != '授权书' && item.name != '营业执照' && item.name != '代理人授权书' && item.name != '身份证正面'&& item.name != '身份证反面'" :span="12">{{item.value}}</el-col>
            <el-col v-else :span="8">
              <span v-if="substr(item.value) == '.pdf'">
                <el-link :href="item.value" target="_blank" type="success">{{item.value}}</el-link>
              </span>
              <span v-else>
                <img v-show="item.value" style="width:200px;cursor:pointer;border: 1px dashed #d9d9d9;" @click="preview(item.value)" :src="item.value" alt="授权书">
              </span>
            </el-col>
            <el-col :span="10" v-show="item.name == '营业执照'">
              <span style="color:#909399;">营业执照为最新版原文件拍照照片，要求文件四角都在图片内，清晰无遮挡，图片水印"仅限办理债主帮法催业务”。</span>
            </el-col>
          </el-row>
        </div>
        <el-radio-group style="margin-top:20px;" v-model="data.examineData.audit_status">
          <el-radio label="Audit_states_0">待审核</el-radio>
          <el-radio label="Audit_states_1">未通过</el-radio>
          <el-radio label="Audit_states_2">已通过</el-radio>
        </el-radio-group>
        <p style="position: relative;top:10px;margin:20px 0 0 0;">审核反馈（确认审核后，此反馈将同步发送至用户邮箱）</p>
        <el-input style="margin:20px 0;" type="textarea" :rows="4" v-model="data.examineData.audit_feedback"></el-input>
        <el-button @click="examine" type="primary">确认审核</el-button>
        <el-button @click="examineType = false" type="primary" plain>取消</el-button>
      </el-popover>
      <!-- end -->
    </div>
    <el-popover title="新增/编辑债权人" popper-class="editData" v-model="visible2">
      <span @click="visible2 = !visible2" class="el-icon-circle-close close"></span>
      <enterpriseCreditor :userData="userData" @determine="creditorDetermine" :key="data.creditorKey" @cancel="cancel"></enterpriseCreditor>
    </el-popover>
    <el-popover title="新增/编辑管理员" popper-class="editData" v-model="visible3">
      <addAdmin :addData="addAdmin" @sandAdminPassword="sandAdminPassword" @determine="addAdminSave" :key="data.adminKey" @cancel="addAdminCancel"></addAdmin>
    </el-popover>
    <el-popover title="新增/编辑账户" popper-class="editData Tswith" v-model="visible4">
      <span @click="visible4 = !visible4" class="el-icon-circle-close close"></span>
      <el-row>
        <el-col :span="24">
          <el-input v-model="account_name" placeholder="请输入账户名称"></el-input>
        </el-col>
      </el-row>
      <el-button style="position:relative;top:50px;" @click="saveAccount" type="primary">保存</el-button>
    </el-popover>
    <el-popover title="设置管理员" popper-class="editData Tswith" v-model="visible5">
      <span @click="visible5 = !visible5" class="el-icon-circle-close close"></span>
      <div class="admin-box">
        <el-checkbox-group v-model="checkList" @change="checkChange">
          <el-checkbox v-for="(item,index) in data.admin_list" :key="index" :label="item.id">{{item.admin_name}}</el-checkbox>
        </el-checkbox-group>
      </div>
      <!-- <el-button style="position:relative;top:50px;" type="primary">保存</el-button> -->
    </el-popover>
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator'
import { Getter, Action } from 'vuex-class'
import * as Api from '../../../api/user'
import { verifyPhone, verifyEmall } from '../../../utils/common'
import { UserOptions } from '../../../types'
import comAdd from './components/add.vue'
import comUserSelect from './components/userSelect.vue'
import table1 from './components/table1.vue'
import table2 from './components/table2.vue'
import table3 from './components/table3.vue'
import addAdmin from './components/addAdmin.vue'
import { comAddress, enterpriseCreditor } from '../../../components/index'
@Component({
  components: {
    comAdd,
    comUserSelect,
    table1,
    table2,
    table3,
    comAddress,
    addAdmin,
    enterpriseCreditor,
  },
})
export default class About extends Vue {
  //手机号码验证
  validatePhone = (rule: any, value: any, callback: any) => {
    let vtf: any = verifyPhone(value)
    if (!vtf.done) {
      callback(new Error(vtf.errMsg))
    } else {
      callback()
    }
  }
  //邮箱验证
  validateEmall = (rule: any, value: any, callback: any) => {
    let vtf: any = verifyEmall(value)
    if (!vtf.done) {
      callback(new Error(vtf.errMsg))
    } else {
      callback()
    }
  }
  //数字验证
  checkAge = (rule: any, value: any, callback: any) => {
    if (!value) {
      return callback(new Error('价格不能为空'))
    }
    setTimeout(() => {
      if (!Number.isInteger(Number(value))) {
        callback(new Error('请输入数字值'))
      } else {
        callback()
      }
    }, 1000)
  }
  // 展示信息
  data: any = {
    actIndex: 0,
    labers: [
      { name: '申请信息' },
      { name: '会员信息' },
      { name: '支付管理' },
      { name: '账户管理' },
      { name: '管理员管理' },
      { name: '债权人信息' },
      { name: '后台备注' },
    ],
    id: 0,
    tabPosition: 'left',
    isVip: false,
    debt_types: ['Debt_type_0'], //催收场景列表
    checkAll: false,
    checkedCities: [],
    isIndeterminate: true,
    activeName: '申请信息',
    adminEmailList: [],
    addNewUserIsShow: false,
    selectUserIsShow: false,
    //审核情况
    examineData: {
      id: '',
      audit_status: 'Audit_states_0',
      audit_feedback: '',
      type: 0,
    },
    //绑定的会员信息
    memberInfo: {
      member_id: 0,
      name: '',
    },
    BasicInfo: [
      //基础信息
      [
        { name: '企业名称', value: '', prop: 'corporate_name' },
        { name: '邮箱', value: '', prop: 'email' },
        { name: '审核状态', value: '', prop: 'audit_status' },
      ],
      [
        { name: '联系人', value: '', prop: 'contacts_name' },
        { name: '所属行业', value: '', prop: 'industry' },
        { name: '审核反馈', value: '', prop: 'audit_feedback' },
      ],
      [
        { name: '联系电话', value: '', prop: 'phone_number' },
        { name: '需求描述', value: '', prop: 'requirement_desc' },
      ],
    ],
    //债权人
    creditorList: [],
    //催收场景
    scence: [],
    // 支付管理
    pay_set: {
      is_postpaid: 0,
      standard_ai_price: 99,
      electron_ai_price: 29,
    },
    //后台备注
    back_remarks: '',
    //账户列表
    account_list: [],
    //管理员
    admin_list: [],
    adminKey: 0,
    creditorKey: 0,
  }
  //编辑信息
  edit: any = {
    BasicInfo: {
      id: 0,
      member_id: 0,
      corporate_name: '',
      contacts_name: '',
      phone_number: '',
      email: '',
      industry: '',
      requirement_desc: '',
    },
    BasicInfoRules: {
      corporate_name: [
        { required: true, message: '请输入企业名称', trigger: 'blur' },
        { max: 20, message: '长度不能超过20个字符', trigger: 'blur' },
      ],
      contacts_name: [
        { required: true, message: '请输入联系人', trigger: 'blur' },
        { max: 10, message: '长度不能超过10个字符', trigger: 'blur' },
      ],
      email: [{ required: true, validator: this.validateEmall, trigger: 'blur' }],
      phone_number: [{ required: true, validator: this.validatePhone, trigger: 'blur' }],
      industry: [{ required: true, message: '清输入行业', trigger: 'blur' }],
      requirement_desc: [{ required: true, message: '请输入需求描述', trigger: 'blur' }],
    },
    pay_set: {
      member_vip_id: '',
      is_postpaid: '',
      standard_ai_price: '',
      electron_ai_price: '',
    },
    pay_setRules: {
      standard_ai_price: [{ validator: this.checkAge, trigger: 'blur' }],
      electron_ai_price: [{ validator: this.checkAge, trigger: 'blur' }],
    },
    addNewVip: {},
  }
  BasicInfoEdit: boolean = false
  debtTypeEdit: boolean = false
  scenceType: boolean = false
  paySetTypeEdit: boolean = false
  examineType: boolean = false
  visible2: boolean = false
  visible3: boolean = false
  visible4: boolean = false
  visible5: boolean = false
  //获取可选择会员列表
  getUserSelectData: any = {
    page: 1,
    limit: this.$store.state.layout.limit,
    name: '',
    phone_number: '',
  }
  //会员选择列表
  selectList: any = []
  height: number = 0
  sectionDom: any = {}
  userData: any = {} //债权人信息
  addAdmin: any = {} //添加编辑管理员信息
  checkList: any = [] //设置管理员选中列表
  checkList2: any = [] //设置管理员列表
  account_name: string = ''
  account_Id: any = ''
  member_vip_admin_id: any = '' //管理员id
  creditorAdminList: any = [] //债权人的管理员列表
  creditorId: any = '' //债权人id
  examineState: any = [] //审核时查看的数据
  created() {
    this.height = document.body.offsetHeight - 178
  }

  activated() {
    //
    let self: any = this
    this.data.id = self.$route.params.id
    this.edit.BasicInfo.id = this.data.id
    this.BasicInfoEdit = false
    this.debtTypeEdit = false
    this.paySetTypeEdit = false
    this.data.activeName = '申请信息'
    this.getVipMemberInfo(this.data.id)
    this.getCreditor(this.data.id)
    let top: number = self.$refs.right.offsetTop //初始位置
    for (let index = 0; index <= 6; index++) {
      const domTop = self.$refs['section' + index].offsetTop - top
      self.sectionDom['section' + index] = domTop
    }
  }

  mounted() {
    //
  }

  beforeDestroy() {
    //
  }
  //获取vip会员基础信息
  getVipMemberInfo(id: any) {
    let self: any = this
    Api.getVipMemberInfo(id).then((res: any) => {
      const info: any = res.data.info //基础信息
      const pay_set: any = res.data.pay_set //先催后付
      const account_list: any = res.data.account_list //账户列表
      const admin_list: any = res.data.admin_list //管理员列表
      if (info != null) {
        self.data.back_remarks = info.back_remarks
        self.data.memberInfo.member_id = info.member_id
        if (self.data.memberInfo.member_id != 0) {
          Api.getDinaryBasicInfo(info.member_id).then((res: any) => {
            self.data.memberInfo.name = res.data.name
          })
        }
        info.audit_status =
          info.audit_status == 'Audit_states_0'
            ? '待审核'
            : info.audit_status == 'Audit_states_1'
            ? '未通过'
            : '已通过'
        self.data.BasicInfo.forEach((item: any) => {
          item.forEach((item2: any) => {
            item2.value = info[item2.prop]
          })
        })
        if (self.data.BasicInfo[0][2].value != '已通过') {
          self.data.labers = [{ name: '申请信息' }, { name: '会员信息' }, { name: '后台备注' }]
        }
      }
      if (pay_set != null) {
        this.data.pay_set = pay_set
      }
      account_list.forEach((item: any) => {
        item.is_super = item.is_super == 0 ? '否' : '是'
        item.create_time = item.create_time
          .replace('T', ' ')
          .substring(0, item.create_time.replace('T', ' ').lastIndexOf(':'))
      })
      this.data.account_list = account_list
      admin_list.forEach((item: any) => {
        item.is_super = item.is_super == 0 ? '关闭' : '开放'
        item.is_account_admin = item.is_account_admin == 0 ? '关闭' : '开放'
        item.create_time = item.create_time
          .replace('T', ' ')
          .substring(0, item.create_time.replace('T', ' ').lastIndexOf(':'))
        item.audit_status =
          item.audit_status == 'Audit_states_0'
            ? '待审核'
            : item.audit_status == 'Audit_states_1'
            ? '未通过'
            : '已通过'
      })
      this.data.admin_list = admin_list
    })
  }
  //获取债权人列表
  getCreditor(id: any) {
    Api.vipGetCreditor(id).then((res: any) => {
      res.data.forEach((item: any) => {
        item.creditor_type = item.creditor_type == 'Creditor_states_1' ? '个人' : '企业'
        item.create_time = item.create_time
          .replace('T', ' ')
          .substring(0, item.create_time.replace('T', ' ').lastIndexOf(':'))
        item.audit_status =
          item.audit_status == 'Audit_states_0'
            ? '待审核'
            : item.audit_status == 'Audit_states_1'
            ? '未通过'
            : '已通过'
      })
      this.data.creditorList = res.data
    })
  }
  //修改Vip基础信息
  editVip() {
    this.BasicInfoEdit = !this.BasicInfoEdit
    if (this.BasicInfoEdit) {
      this.data.BasicInfo.forEach((item: any) => {
        item.forEach((item2: any) => {
          this.edit.BasicInfo[item2.prop] = item2.value
        })
      })
    }
  }
  //会员申请信息编辑
  vipUserEditi() {
    let self: any = this
    let parmas: any = {
      id: self.edit.BasicInfo.id,
      member_id: self.data.BasicInfo.member_id || 0,
      corporate_name: self.edit.BasicInfo.corporate_name,
      contacts_name: self.edit.BasicInfo.contacts_name,
      phone_number: self.edit.BasicInfo.phone_number,
      email: self.edit.BasicInfo.email,
      industry: self.edit.BasicInfo.industry,
      requirement_desc: self.edit.BasicInfo.requirement_desc,
    }
    Api.addVip(parmas).then((res: any) => {
      if (res.state) {
        self.$message.success(res.msg)
        self.getVipMemberInfo(self.$route.params.id)
        self.BasicInfoEdit = false
      } else {
        self.$message.warning(res.msg)
      }
    })
  }
  //支付管理编辑切换
  paySetType() {
    this.paySetTypeEdit = !this.paySetTypeEdit
    this.edit.pay_set.standard_ai_price = this.data.pay_set.standard_ai_price
    this.edit.pay_set.electron_ai_price = this.data.pay_set.electron_ai_price
    this.edit.pay_set.is_postpaid = this.data.pay_set.is_postpaid
  }
  //支付管理编辑提交
  paySetEdit() {
    let self: any = this
    self.edit.pay_set.member_vip_id = self.$route.params.id
    self.edit.pay_set['id'] = self.data.pay_set.id
    Api.vipEditPaySet(self.edit.pay_set).then((res: any) => {
      if (res.state) {
        self.$message.success(res.msg)
        self.getVipMemberInfo(self.$route.params.id)
        this.paySetTypeEdit = false
      } else {
        self.$message.warning(res.msg)
      }
    })
  }
  //支付管理取消编辑
  paySetCancel() {
    // this.edit.pay_set = Object.assign({}, this.data.pay_set)
    // this.edit.pay_set.is_postpaid = this.edit.pay_set.is_postpaid ? '开通' : '关闭'
    this.paySetTypeEdit = false
  }
  //后台备注保存
  beizhu() {
    let self: any = this
    let parmas: any = {
      member_vip_id: self.data.id,
      back_remarks: self.data.back_remarks,
    }
    if (self.data.back_remarks == null) {
      self.$message.warning('保存内容不能为空')
      return false
    }
    Api.vipSaveNotes(parmas).then((res: any) => {
      if (res.state) {
        self.$message.success(res.msg)
      } else {
        self.$message.warning(res.msg)
      }
    })
  }

  //打开会员选择弹窗
  openSelect() {
    this.data.selectUserIsShow = true
    Api.getUserSelectList(this.getUserSelectData).then((res: any) => {
      this.selectList = res.data
    })
  }
  //搜索
  search(data: any) {
    let self: any = this
    self.getUserSelectData.page = 1
    let params: any = Object.assign({}, self.getUserSelectData)
    data.forEach((item: any) => {
      let name: string = item.label
      params[name] = item.value
    })
    Api.getUserSelectList(params).then((res: any) => {
      this.selectList = res.data
    })
  }
  //清除搜索
  clearSelection() {
    Api.getUserSelectList(this.getUserSelectData).then((res: any) => {
      this.selectList = res.data
    })
  }
  //会员选择弹窗关闭
  selectUserClose() {
    this.data.selectUserIsShow = false
  }
  //会员选中
  xuanze(data: any) {
    let self: any = this
    let parmas: any = {
      member_vip_id: self.$route.params.id,
      member_id: data.id,
    }
    Api.userSelect(parmas).then((res: any) => {
      if (res.state) {
        self.$message.success(res.msg)
        self.getVipMemberInfo(self.data.id)
        self.selectUserClose()
      } else {
        self.$message.warning(res.msg)
      }
    })
  }
  //点击左侧菜单事件
  laberClick(index: number) {
    let self: any = this
    self.data.actIndex = index
    let top: number = self.$refs.right.offsetTop //初始位置
    let dom: any = 'section' + index //点击元素的位置
    let actTop: number = self.$refs[dom].offsetTop
    self.$refs.right.scrollTop = actTop - top
  }
  //滚动监听
  scrollGet(e: any) {
    if (e.target.scrollTop <= this.sectionDom.section0) {
      this.data.actIndex = 0
    } else if (e.target.scrollTop <= this.sectionDom.section1) {
      this.data.actIndex = 1
    } else if (e.target.scrollTop <= this.sectionDom.section2) {
      this.data.actIndex = 2
    } else if (e.target.scrollTop <= this.sectionDom.section3) {
      this.data.actIndex = 3
    } else if (e.target.scrollTop <= this.sectionDom.section4) {
      this.data.actIndex = 4
    } else if (e.target.scrollTop <= this.sectionDom.section5) {
      this.data.actIndex = 5
    } else if (e.target.scrollTop <= this.sectionDom.section6) {
      this.data.actIndex = 6
    }
  }
  //返回
  goBaack() {
    let self: any = this
    self.$router.push({
      path: '/VIP/vipApply',
    })
  }
  //底部审核
  footerShenhe() {
    let self: any = this
    let status: any = self.data.BasicInfo[0][2].value
    this.data.examineData.type = 0
    self.examineType = true
    self.data.examineData.id = self.$route.params.id
    self.data.examineData.audit_status =
      status == '待审核'
        ? 'Audit_states_0'
        : status == '未通过'
        ? 'Audit_states_1'
        : 'Audit_states_2'
    self.data.examineData.audit_feedback = self.data.BasicInfo[1][2].value
  }
  //审核
  examine() {
    this.$confirm('确认审核?', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning',
    })
      .then(() => {
        //vip会员审核
        if (this.data.examineData.type == 0) {
          Api.examineVIp(this.data.examineData).then((res: any) => {
            if (res.state) {
              this.$message.success(res.msg)
              this.examineType = false
              this.getVipMemberInfo(this.data.id)
              if (this.data.BasicInfo[0][2].value != '已通过') {
                this.data.labers = [
                  { name: '申请信息' },
                  { name: '会员信息' },
                  { name: '支付管理' },
                  { name: '账户管理' },
                  { name: '管理员管理' },
                  { name: '债权人信息' },
                  { name: '后台备注' },
                ]
              }
            } else {
              this.$message.warning(res.msg)
            }
          })
        }
        //管理员审核
        if (this.data.examineData.type == 1) {
          Api.examineVipAdmin(this.data.examineData).then((res: any) => {
            if (res.state) {
              this.$message.success(res.msg)
              this.examineType = false
              this.getVipMemberInfo(this.data.id)
            } else {
              this.$message.warning(res.msg)
            }
          })
        }
        //债权人审核
        if (this.data.examineData.type == 2) {
          let self: any = this
          Api.examineVipCreditor(self.data.examineData).then((res: any) => {
            if (res.state) {
              self.$message.success(res.msg)
              self.examineType = false
              self.getCreditor(self.$route.params.id)
            } else {
              self.$message.warning(res.msg)
            }
          })
        }
      })
      .catch(() => {
        this.$message({
          type: 'info',
          message: '已取消',
        })
      })
  }
  //删除
  handDelete() {
    let self: any = this
    let id = self.data.id
    self
      .$confirm('您确定删除吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
      .then(() => {
        Api.vipDelete(id).then((res: any) => {
          if (res.state) {
            self.$message.success(res.msg)
            self.goBaack()
          } else {
            self.$message.warning(res.msg)
          }
        })
      })
      .catch(() => {
        self.$message({
          type: 'info',
          message: '已取消删除',
        })
      })
  }
  //取消
  cancel() {
    this.visible2 = false
  }
  // //获取债权人信息
  // getCreditorInfoByid(id: any) {
  //   let self: any = this
  //   Api.getCreditorInfoByid(id).then((res: any) => {
  //     self.userData = res.data
  //   })
  // }
  //打开新增债权人
  addCreditor(data: any) {
    let self: any = this
    self.visible2 = true
    self.data.creditorKey += 1
    self.userData = {
      add: true,
    }
    self.member_vip_admin_id = data.row.id
    self.account_Id = data.row.member_vip_account_id
  }
  //新增债权人
  creditorDetermine(data: any) {
    let self: any = this
    data.member_vip_admin_id = self.member_vip_admin_id
    data.member_id = self.data.memberInfo.member_id
    data.member_vip_account_id = self.account_Id
    Api.addCreditorNew(data).then((res: any) => {
      if (res.state) {
        self.$message.success(res.msg)
        self.visible2 = false
        self.getCreditor(self.$route.params.id)
      } else {
        self.$message.warning(res.msg)
      }
    })
  }
  //打开新增管理员
  addAdmin2(data: any) {
    this.visible3 = true
    this.data.adminKey += 1
    this.addAdmin = {}
    this.addAdmin['member_vip_account_id'] = data.row.id
  }
  //添加/编辑管理员
  addAdminSave(data: any) {
    let self: any = this
    data['member_vip_account_id'] = self.addAdmin.member_vip_account_id
    Api.vipAddAdmin(data).then((res: any) => {
      if (res.state) {
        self.$message.success(res.msg)
        this.visible3 = false
        self.getVipMemberInfo(self.data.id)
      } else {
        self.$message.warning(res.msg)
      }
    })
  }
  //取消添加/编辑管理员
  addAdminCancel() {
    this.visible3 = false
  }
  //发送管理员密码
  sandAdminPassword(data: any) {
    let self: any = this
    Api.sandAdminPassword(data).then((res: any) => {
      if (res.state) {
        self.$message.success(res.msg)
      } else {
        self.$message.warning(res.msg)
      }
    })
  }
  //打开新增账户弹窗
  addAccount() {
    this.visible4 = true
    this.account_name = ''
    this.account_Id = 0
  }

  //新增账号
  saveAccount() {
    let self: any = this
    let parmas: any = {
      id: self.account_Id || 0,
      member_vip_id: self.$route.params.id,
      account_name: self.account_name,
    }
    Api.updateAccount(parmas).then((res: any) => {
      if (res.state) {
        self.$message.success(res.msg)
        self.visible4 = false
        self.getVipMemberInfo(self.data.id)
      } else {
        self.$message.warning(res.msg)
      }
    })
  }
  //编辑账号
  adminEdit(data: any) {
    let self: any = this
    self.visible4 = true
    self.account_Id = data.row.id
    self.account_name = data.row.account_name
  }
  //管理员编辑
  editAdmin(data: any) {
    this.visible3 = true
    this.addAdmin = Object.assign({}, data.row)
  }
  //管理员审核
  adminExamine(data: any) {
    this.examineState = []
    const matching: any = {
      account_name: '登录名',
      id_number: '身份证号',
      authorization_img: '授权书',
      admin_phone_number: '手机号码',
      admin_email: '电子邮箱',
      is_super: '总账户权限',
      // is_account_admin: ' 子账户权限',
    }
    Object.keys(matching).forEach((key: string) => {
      let item: any = {
        name: matching[key],
        value: data.row[key],
      }
      this.examineState.push(item)
    })
    this.examineType = true
    let audit_status: string =
      data.row.audit_status == '待审核'
        ? 'Audit_states_0'
        : data.row.audit_status == '未通过'
        ? 'Audit_states_1'
        : 'Audit_states_2'
    this.data.examineData.audit_status = audit_status
    this.data.examineData.audit_feedback = data.row.audit_feedback
    this.data.examineData.id = data.row.id
    this.data.examineData.type = 1
  }
  //债权人审核
  creditorExamine(data: any) {
    this.examineState = []
    const matching: any = {
      creditor_type: '债权人类型',
      id_type: '证件类型',
      license_img_url: '营业执照',
      id_card_img_01: '身份证正面',
      id_card_img_02: '身份证反面',
      license_no: '统一社会信用代码',
      creditor_name: '债权人名称',
      agent_name: '代理人姓名',
      agent_id_number: '代理人身份证号',
      agent_authorization: '代理人授权书',
      phone_number: '手机号码',
      creditor_address: '所在地区',
      detailed_address: '详细地址',
      email: '电子邮箱',
      back_remarks: '后台备注',
    }
    Object.keys(matching).forEach((key: string) => {
      if (data.row[key] != '') {
        if (key != 'id_type') {
          let item: any = {
            name: matching[key],
            value: data.row[key],
          }
          this.examineState.push(item)
        } else {
          let item: any = {
            name: matching[key],
            value:
              data.row[key] == 5
                ? '营业执照'
                : data.row[key] == 4
                ? '港澳台通行证'
                : data.row[key] == 3
                ? '护照'
                : data.row[key] == 2
                ? '士官证'
                : '身份证',
          }
          this.examineState.push(item)
        }
      }
    })
    this.examineType = true
    let audit_status: string =
      data.row.audit_status == '待审核'
        ? 'Audit_states_0'
        : data.row.audit_status == '未通过'
        ? 'Audit_states_1'
        : 'Audit_states_2'
    this.data.examineData.audit_status = audit_status
    if (data.row.audit_status == '待审核') {
      this.data.examineData.audit_feedback =
        data.row.audit_feedback ||
        '贵司在债主帮平台提交的债权人信息中未填写营业执照的有效期；缺少营业执照、授权书；未填写负责人的手机号、邮箱以及身份证号码；其他（例如手机号有误，身份证号有误）'
    }
    if (data.row.audit_status != '待审核') {
      this.data.examineData.audit_feedback = data.row.audit_feedback
    }
    this.data.examineData.id = data.row.id
    this.data.examineData.type = 2
  }
  //打开债权人编辑
  editCreditor(data: any) {
    let row: any = Object.assign({}, data.row)
    row.creditor_type = row.creditor_type == '企业' ? 'Creditor_states_0' : 'Creditor_states_1'
    this.member_vip_admin_id = row.id
    this.account_Id = row.member_vip_account_id
    this.userData = row
    this.visible2 = true
  }
  //打开设置管理
  settingAdmin(data: any) {
    this.visible5 = true
    this.creditorId = data.row.id
    this.checkList = []
    this.checkList2 = []
    Api.getCreditorAdminNew(data.row.id).then((res: any) => {
      res.data.forEach((item: any) => {
        this.checkList.push(item.member_vip_admin_id)
        this.checkList2.push(item.member_vip_admin_id)
      })
    })
  }
  //管理员选择
  checkChange(val: any) {
    let list: any = this.getArrDifference(val, this.checkList2)
    let info: any = val.indexOf(list[0])
    this.checkList2 = val
    if (info >= 0) {
      //设置
      Api.setCreditorAdmin(this.creditorId, list[0]).then((res: any) => {
        if (res.state) {
          this.$message.success(res.msg)
        } else {
          this.$message.warning(res.msg)
        }
      })
    } else {
      //取消
      Api.deletCreditorAdmin(this.creditorId, list[0]).then((res: any) => {
        if (res.state) {
          this.$message.success(res.msg)
        } else {
          this.$message.warning(res.msg)
        }
      })
    }
  }
  getArrDifference(arr1: any, arr2: any) {
    return arr1.concat(arr2).filter(function (v: any, i: any, arr: any) {
      return arr.indexOf(v) === arr.lastIndexOf(v)
    })
  }
  //删除账户
  accmentDel(data: any) {
    Api.accmentDelect(data.row.id).then((res: any) => {
      if (res.state) {
        this.$message.success(res.msg)
        this.getVipMemberInfo(this.data.id)
      } else {
        this.$message.warning(res.msg)
      }
    })
  }
  //删除管理员
  adminDel(data: any) {
    Api.adminDelect(data.row.id).then((res: any) => {
      if (res.state) {
        this.$message.success(res.msg)
        this.getVipMemberInfo(this.data.id)
      } else {
        this.$message.warning(res.msg)
      }
    })
  }
  //跳转普通会员
  goMenber(id: any) {
    let self: any = this
    self.$router.push({
      path: `/ordinary/ordinaryAdmin/${id}`,
    })
  }
  //图片查看
  preview(val: any) {
    window.open(val)
  }
  //截取小数点后字符
  substr(val: string) {
    let result: string = val.substring(val.lastIndexOf('.'))
    return result
  }
}
</script>

<style lang="scss">
@import '@/assets/scss/variables';

.vipAdmin-wrap {
  width: 100%;
  min-height: 100%;
  background-color: $main-body-bgColor;
  position: relative;
  .vipAdmin-box {
    display: flex;
    .left {
      width: 9%;
      display: flex;
      & > .text {
        div {
          color: $Main-characters;
          font-size: $Text-font;
          height: 40px;
          line-height: 40px;
          padding: 0 25px 0 0;
          text-align: center;
          cursor: pointer;
        }
        .act {
          color: #ec193a;
        }
      }
      & > .shuxian-box {
        height: 100%;
        width: 2px;
        background-color: #e4e7ed;
        position: relative;
        & > .shuxian {
          width: 100%;
          height: 40px;
          background-color: #ec193a;
          transition: transform 0.5s ease;
          transform: translateY(0);
        }
      }
    }
    .right {
      width: 90%;
      overflow-y: auto;
      padding-right: 20px;
      .act {
        span {
          color: #ec193a !important;
        }
      }
      .section {
        margin: 20px auto;
        & > span:first-child {
          margin-top: 10px;
          display: flex;
          justify-content: space-between;
          height: 20px;
        }
        & .el-textarea {
          width: 600px;
        }
        & .table-wrap > .el-table {
          width: 99% !important;
        }
        .box {
          display: flex;
          .text {
            width: 33.33%;
            p {
              margin: 0;
              margin-bottom: 10px;
              line-height: 32px;
              & > span:first-child {
                color: $General-colors;
                font-size: 12px;
                margin-right: 10px;
              }
              & > span:last-child {
                color: $Main-characters;
                font-size: 14px;
              }
            }
          }
        }
      }
    }
  }
  .el-divider--horizontal {
    margin: 5px 0 20px 0;
  }
  .info {
    color: #67c23a;
  }
  .edit {
    color: #e6a23c;
  }
  .el-tabs--left .el-tabs__header.is-left {
    margin-right: 20px;
  }
  .el-checkbox-group {
    margin-bottom: 20px;
  }
  .el-textarea textarea {
    height: 100px;
  }
  .addNewUser,
  .selectUser {
    width: 680px;
    position: absolute;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    border-radius: 20px;
    padding: 30px 20px;
    .close {
      position: absolute;
      right: 20px;
      top: 20px;
      font-size: 18px;
      cursor: pointer;
    }
  }
  .lable {
    color: #606266;
    font-size: 14px;
    margin-bottom: 10px;
    line-height: 32px;
    height: 32px;
    width: 40px;
    display: inline-block;
  }
  .value {
    color: #303133;
    font-size: 14px;
    margin-bottom: 10px;
    line-height: 32px;
    height: 32px;
    width: 80px;
    display: inline-block;
  }
  .footer {
    position: absolute;
    bottom: -10px;
    left: 9%;
  }
  .editData {
    width: 670px;
    padding: 20px 40px 80px 40px;
  }
  .Tswith {
    width: 470px;
  }
  .el-checkbox {
    margin-bottom: 20px;
  }
  .title {
    font-size: 14px;
    color: #606266;
    font-weight: bold;
    display: inline-block;
    border-left: 3px solid #e01f3c;
    height: 15px;
    line-height: 15px;
    padding-left: 10px;
  }
  .examineData {
    max-height: 350px;
    overflow-y: auto;
  }
}
</style>
