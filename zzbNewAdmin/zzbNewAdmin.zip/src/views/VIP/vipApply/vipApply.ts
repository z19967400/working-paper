import { Component, Vue } from "vue-property-decorator";
import {
  comselect,
  comOperation,
  comPaging,
  comtable
} from "@/components/index";
import { UserData, UserOptions } from "@/types/index";
import * as Api from "@/api/user";
import comAdd from "./addVip.vue";
@Component({
  components: {
    comtable,
    comselect,
    comOperation,
    comPaging,
    comAdd
  }
})
export default class About extends Vue {
  // Getter

  // Action

  // data
  data: UserData = {
    loading: false,
    list: [],
    select: {},
    totalize: 0,
    options: [
      {
        value: "corporate_name",
        label: "企业名称"
      },
      {
        value: "contacts_name",
        label: "联系人名称"
      },
      {
        value: "phone_number",
        label: "手机号码"
      }
    ],
    dataType: [
      {
        label: "ID",
        prop: "id",
        width: "80px"
      },
      {
        label: "会员ID",
        prop: "member_id",
        width: "80px"
      },
      {
        label: "会员名称",
        prop: "member_name",
        width: "220px"
      },
      {
        label: "企业名称",
        prop: "corporate_name",
        width: "220px"
      },
      {
        label: "联系人",
        prop: "contacts_name"
      },
      {
        label: "联系电话",
        prop: "phone_number"
      },
      {
        label: "邮箱",
        prop: "email"
      },
      {
        label: "所属行业",
        prop: "industry"
      },
      {
        label: "需求描述",
        prop: "requirement_desc"
      },
      {
        label: "审核状态",
        prop: "audit_status"
      },
      {
        label: "备注",
        prop: "back_remarks"
      },
      {
        label: "申请时间",
        prop: "create_time"
      }
    ]
  };
  getData: UserOptions["getVIP"] = {
    page: 1,
    limit: this.$store.getters.limit,
    corporate_name: "", //公司名称
    contacts_name: "", //联系人名称
    phone_number: "" //手机号
  };
  list: any = [];
  visible: boolean = false;
  created() {
    //
  }

  activated() {
    this.init();
  }

  mounted() {
    //
  }
  // 初始化函数
  init() {
    let self: any = this;
    let params: any =
      JSON.stringify(self.data.select) == "{}"
        ? self.getData
        : self.data.select;
    this.getList(params);
  }
  //获取数据
  getList(params: UserOptions["getVIP"]) {
    let data: any = this.data;
    data.loading = true;
    data.list = this.list;
    Api.getVipUser(params).then((res: any) => {
      data.loading = false;
      res.data.forEach((item: any) => {
        item.audit_status =
          item.audit_status == "Audit_states_0"
            ? "待审核"
            : item.audit_status == "Audit_states_1"
            ? "未通过"
            : "已通过";
      });
      data.list = res.data;
      data.totalize = res.count;
    });
  }
  //跳转管理页面
  goAdmin(data: any) {
    let id: number = data.id;
    this.$router.push({
      path: `/VIP/vipAdmin/${id}`
    });
  }
  //删除
  handleDelete(data: any) {
    Api.vipUserDelet(data.row.id).then((res: any) => {
      if (res.data != 0) {
        this.$message.success(res.msg);
        this.init();
      } else {
        this.$message.warning(res.msg);
      }
    });
  }
  //搜索
  search(data: any) {
    let self: any = this;
    self.data.loading = true;
    self.getData.page = 1;
    let params: any = Object.assign({}, self.getData);
    data.forEach((item: any) => {
      let name: string = item.label;
      params[name] = item.value;
    });
    self.data.select = params;
    this.getList(params);
  }
  //清除搜索项
  clearSelection(data: any) {
    let self: any = this;
    self.data.select = {};
    this.init();
  }
  //添加
  add() {
    // this.$router.push({
    //   path: "/VIP/addVip"
    // });
    this.visible = true;
  }
  //分页
  watchChange(index: number, limit: number | null) {
    let self: any = this;
    let params: any =
      JSON.stringify(self.data.select) == "{}"
        ? self.getData
        : self.data.select;
    params.page = index;
    params.limit = limit == null ? params.limit : limit;
    self.init();
  }
  //弹窗确定
  determine() {
    this.init();
    this.cancel();
  }
  //取消
  cancel() {
    this.visible = false;
  }
}
