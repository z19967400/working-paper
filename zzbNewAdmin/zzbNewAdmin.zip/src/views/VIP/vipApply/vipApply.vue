<template>
  <div class="vipApply-wrap">
    <div class="vipApply-box">
      <comselect :options="data.options" @select="search" @clear="clearSelection"></comselect>
      <comOperation :totalize="data.totalize" @add="add"></comOperation>
      <comtable :tableData="data.list" :load="data.loading" :tableType="data.dataType" :admin="true" @admin="goAdmin" @Delete="handleDelete"></comtable>
      <comPaging :page="getData.page" :totalize="data.totalize" @watchChange="watchChange"></comPaging>
      <div class="zhezhao" v-show="visible"></div>
      <el-popover title="添加VIP会员" popper-class="editData" v-model="visible">
        <span @click="visible = !visible" class="el-icon-circle-close close"></span>
        <comAdd @determine="determine" @cancel="cancel"></comAdd>
      </el-popover>
    </div>
  </div>
</template>

<script lang="ts" src="./vipApply.ts"></script>

<style lang="scss">
@import './vipApply.scss';
</style>
