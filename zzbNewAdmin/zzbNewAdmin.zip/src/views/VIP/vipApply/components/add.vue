<template>
  <div class="add-wrap">
    <span @click="close" class="el-icon-close"></span>
    <el-form
      :model="data"
      :rules="rules"
      ref="ruleForm"
      label-width="100px"
      class="demo-ruleForm"
    >
      <el-form-item label="公司名称" prop="corporate_name">
        <el-col :span="22"
          ><el-input v-model="data.corporate_name"></el-input
        ></el-col>
      </el-form-item>
      <el-form-item label="手机号码" prop="phone_number">
        <el-col :span="22"
          ><el-input v-model="data.phone_number"></el-input
        ></el-col>
      </el-form-item>
      <el-form-item label="邮箱" prop="email">
        <el-col :span="22"> <el-input v-model="data.email"></el-input></el-col>
      </el-form-item>
      <el-form-item label="后台备注" prop="back_remarks">
        <el-col :span="22"
          ><el-input type="textarea" v-model="data.back_remarks"></el-input
        ></el-col>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="submitForm('ruleForm')"
          >确定</el-button
        >
        <el-button @click="resetForm('ruleForm')">取消</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop, Watch } from "vue-property-decorator";
import { Getter, Action } from "vuex-class";
import { UserOptions } from "../../../../types/index";
import { verifyPhone, verifyEmall } from "../../../../utils/common";
import * as Api from "../../../../api/user";
// import {  } from "@/components" // 组件

@Component({})
export default class About extends Vue {
  //邮箱规则验证
  validateEmall = (rule: any, value: any, callback: any) => {
    let vtf: any = verifyEmall(value);
    if (!vtf.done) {
      callback(new Error(vtf.errMsg));
    } else {
      callback();
    }
  };
  //手机号码验证
  validatePhone = (rule: any, value: any, callback: any) => {
    let vtf: any = verifyPhone(value);
    if (!vtf.done) {
      callback(new Error(vtf.errMsg));
    } else {
      callback();
    }
  };
  // prop
  @Prop({
    required: false,
    default: ""
  })
  member_id!: number;
  @Watch("member_id")
  member_idChangeVal(newVal: number, oldVal: number) {
    let self: any = this;
    self.data.member_id = newVal;
  }
  // data
  data: UserOptions["addVip"] = {
    id: 0,
    member_id: 0,
    corporate_name: "", //公司名称
    phone_number: "", //手机号
    contacts_name: "", //联系人
    email: "", //邮箱
    debt_type: "", //催收场景
    demand_quantity: "", //年催需求
    back_remarks: "" // 后台备注
  };
  rules: any = {
    corporate_name: [
      { required: true, message: "请输入公司名称", trigger: "blur" },
      { max: 20, message: "长度不能超过20个字符", trigger: "blur" }
    ],
    email: [{ required: true, validator: this.validateEmall, trigger: "blur" }],
    phone_number: [
      { required: true, validator: this.validatePhone, trigger: "blur" }
    ]
  };
  submitType: boolean = false;
  created() {
    //
  }

  activated() {
    //
  }

  mounted() {
    //
  }
  //确定
  submitForm(formName: string) {
    let from: any = this.$refs[formName];
    let self: any = this;
    from.validate((valid: Boolean) => {
      if (valid) {
        self.data.submitType = true;
        // eslint-disable-next-line no-console
        console.log(self.data);
        Api.addVip(self.data).then((res: any) => {
          if (res.data != 0) {
            self.$message.success(res.msg);
            setTimeout(() => {
              self.submitType = false;
              self.close();
            }, 1000);
          } else {
            self.$message.warning(res.msg);
            self.submitType = false;
          }
        });
      } else {
        // eslint-disable-next-line no-console
        console.log("error submit!!");
        return false;
      }
    });
  }
  // 取消
  resetForm(formName: string) {
    let form: any = this.$refs[formName];
    form.resetFields();
    this.close();
  }

  //关闭
  close() {
    let form: any = this.$refs["ruleForm"];
    form.resetFields();
    this.$emit("close", "");
  }
}
</script>

<style lang="scss">
@import "@/assets/scss/variables";

.add-wrap {
  width: 100%;
  .el-icon-close {
    position: absolute;
    right: 15px;
    top: 15px;
    cursor: pointer;
    font-size: 16px;
  }
  .el-textarea {
    width: 100% !important;
    .el-textarea__inner {
      height: 100px;
    }
  }
}
</style>
