<template>
  <div class="table-wrap">
    <el-table id="comTable" v-loading="data.loading" border :data="data.Data" style="width: 100%">
      <el-table-column v-for="(item, index) in tableType" :key="index" :prop="item.value" :label="item.label" :width="item.width">
        <template slot-scope="scope">
          <el-popover placement="bottom" trigger="click" :content="tostr(scope.row[item.value])" popper-class="table-click" :visible-arrow="false">
            <div slot="reference" style="padding-left:15px;" class="cell">
              {{ scope.row[item.value] }}
            </div>
          </el-popover>
        </template>
      </el-table-column>
      <el-table-column fixed="right" width="220px" label="操作">
        <template slot-scope="scope">
          <el-button class="edit" type="text" size="small" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
          <el-button class="info" type="text" size="small" @click="addCreditor(scope.$index, scope.row)">添加债权人</el-button>
          <el-button class="examine" type="text" size="small" @click="examine(scope.$index, scope.row)">审核</el-button>
          <el-button type="text" class="delete" size="small" @click="handleDelete(scope.$index, scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator'
import { Getter, Action } from 'vuex-class'

@Component({})
export default class About extends Vue {
  // prop
  @Prop({}) public tableData!: any

  //watch
  @Watch('tableData')
  onChangeValue(newVal: Array<object>, oldVal: Array<object>) {
    this.data.Data = newVal
  }

  // data
  data: any = {
    componentName: 'table',
    loading: false,
    Data: null,
    width: '0px',
    tabInfo: false,
  }
  tableType: any = [
    {
      value: 'id',
      label: 'ID',
    },
    {
      value: 'account_name',
      label: '账户名称',
      width: '320px',
    },
    {
      value: 'admin_name',
      label: '管理员名称',
    },
    {
      value: 'admin_phone_number',
      label: '手机号码',
      width: '150px',
    },
    {
      value: 'admin_email',
      label: '电子邮箱',
      width: '200px',
    },
    {
      value: 'is_super',
      label: '总账户权限',
    },
    {
      value: 'is_account_admin',
      label: '子账户权限',
    },
    {
      value: 'audit_status',
      label: '审核状态',
    },
    // {
    //   value: 'is_super',
    //   label: '专属客服',
    // },
    {
      value: 'create_time',
      label: '创建时间',
      width: '150px',
    },
  ]
  datattp: any = []
  dataData: any = []
  checkList: any = []
  isIndeterminate: boolean = false
  checkAll: boolean = true
  tableSelectType: boolean = false
  height: number = 0
  created() {
    this.init()
  }

  // activated() {
  //   this.init()
  // }

  mounted() {
    let self: any = this
    self.data.width = self.data.tabInfo == true ? '180px' : '150px'
    // if (this.admin) {
    //   self.data.width = 0
    // }
  }
  //初始化
  init() {
    let self: any = this
    self.datattp = [...self.tableType]
    self.dataData = [...self.tableType]
    let value: string = localStorage.getItem(self.$route.path) || ''
    if (value != '') {
      self.dataData = self.dataData.filter((item: any) => {
        return value.indexOf(item.label) != -1
      })
      this.datattp.forEach((item: any, index: number) => {
        item.index = index
        if (value.indexOf(item.label) != -1) {
          item.checked = true
        } else {
          item.checked = false
        }
      })
    } else {
      this.datattp.forEach((item: any, index: number) => {
        item.index = index
        item.checked = true
      })
    }
  }
  //审核
  examine(index: number, row: object) {
    let params: any = {
      index,
      row,
    }
    this.$emit('examine', params)
    //
  }
  //编辑
  handleEdit(index: number, row: object) {
    let params: any = {
      index,
      row,
    }
    this.$emit('Edit', params)
    //
  }
  //删除
  handleDelete(index: number, row: any) {
    let self: any = this
    let params: any = {
      index,
      row,
    }
    self
      .$confirm('您确定删除吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
      .then(() => {
        self.$emit('Delete', params)
      })
      .catch(() => {
        self.$message({
          type: 'info',
          message: '已取消删除',
        })
      })
  }
  //添加债权人
  addCreditor(index: number, row: object) {
    let params: any = {
      index,
      row,
    }
    this.$emit('addCreditor', params)
  }
  //转字符串
  tostr(val: any) {
    if (val != null) {
      return val.toString()
    } else {
      return val
    }
  }
}
</script>

<style lang="scss">
@import '@/assets/scss/variables';

.table-wrap {
  width: 100%;
  position: relative;
  .el-table th:last-child > .cell {
    text-align: center;
  }
  .el-table tr td:last-child > .cell {
    text-align: center;
  }
  .edit {
    color: #55a3f4;
  }
  .el-table thead {
    color: #999;
  }
  .el-table {
    color: #555;
  }
  .el-table th > .cell {
    font-weight: normal;
  }
  .info {
    color: #67c23a;
  }
  .delete {
    color: #f56c6c;
  }
  .examine {
    color: #e6a23c;
  }
  .el-table .cell {
    padding-left: 0px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .close {
    position: absolute;
    right: 20px;
    top: 20px;
    cursor: pointer;
    font-size: 16px;
  }
  & .el-table__body tr.current-row > td {
    background-color: #f5f7fa;
  }
}
.table-select {
  max-width: 600px;
  position: fixed;
  z-index: 1000;
  background-color: white;
  box-shadow: 0 2px 9px #a29a9a;
  padding: 20px 40px;
  left: 50%;
  top: 45%;
  transform: translate(-50%, -50%);
  border-radius: 10px;
  .el-checkbox {
    margin-bottom: 20px;
  }
  .select-header {
    font-size: 14px;
    margin-bottom: 30px;
    color: #606266;
  }
  .el-checkbox-group {
    min-height: 150px;
  }
  .table-select-buttom {
    text-align: center;
    margin-top: 30px;
  }
}
.table-wrap .el-table .cell {
  cursor: pointer;
}
.table-click {
  background-color: #303133;
  color: #fff;
  padding: 12px;
  font-size: 12px;
  max-width: 200px;
  min-width: 50px !important;
}
</style>
