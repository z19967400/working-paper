<template>
  <div class="userSelect-wrap">
    <span @click.stop="guanbi" class="el-icon-close"></span>
    <div class="select-box">
      <div class="select">
        <label class="label">选择条件</label>
        <el-select size="small" v-model="data.value" placeholder="请选择">
          <el-option v-for="item in data.options" :key="item.value" :label="item.label" :value="item.value"></el-option>
        </el-select>
        <el-input size="small" v-model="data.input" @keyup.enter.native="search" placeholder="请输入内容"></el-input>
        <el-button @click="search" size="small" type="primary" icon="el-icon-search" plain>查询</el-button>
      </div>
      <div v-show="data.select.length != 0" class="seleted">
        <div>
          <label class="label">已选条件</label>
          <el-tag :key="index" v-for="(tag, index) in data.select" closable :disable-transitions="false" @close="handleClose(tag)" type="primary">
            {{ tag.value }}
          </el-tag>
        </div>
        <el-button @click="clearSelection()" size="small" type="primary" icon="el-icon-delete" plain></el-button>
      </div>
    </div>
    <el-table :data="data.tabeData" height="250" border style="width: 100%">
      <el-table-column prop="id" label="会员ID" width="180"> </el-table-column>
      <el-table-column prop="name" label="会员名称" width="180"> </el-table-column>
      <el-table-column prop="phone_number" label="手机号"> </el-table-column>
      <el-table-column label="操作" width="100">
        <template slot-scope="scope">
          <el-button @click="handleClick(scope.row)" type="text" class="info" size="small">选择</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator'
import { Getter, Action } from 'vuex-class'
@Component({})
export default class About extends Vue {
  // prop
  @Prop({})
  tabeData!: Array<object>

  //watg
  @Watch('tabeData')
  dataChangeValue(newVal: any, oldVal: any) {
    this.data.tabeData = newVal
  }

  // data
  data: any = {
    tabeData: [],
    options: [
      // {
      //   value: "id",
      //   label: "会员ID"
      // },
      {
        value: 'name',
        label: '会员名称',
      },
      {
        value: 'phone_number',
        label: '会员手机号',
      },
    ],
    input: '',
    value: '',
    select: [],
  }

  created() {
    //
  }

  activated() {
    //
  }

  mounted() {
    //
  }
  //关闭
  guanbi() {
    this.$emit('guanbi', '')
  }
  //搜索
  search(data: any) {
    if (this.data.value == '') {
      let self: any = this
      self.$message.warning('请选择查询条件')
      return false
    }
    if (this.data.value != '' && this.data.input == '') {
      let self: any = this
      self.$message.warning('请选择输入查询内容条件')
      return false
    }
    if (this.data.input != '' && this.data.value != '') {
      if (this.data.input.length > 20) {
        let self: any = this
        self.$message.warning('查询内容不得超过20字')
        return false
      }
      let data: any = {
        label: this.data.value,
        value: this.data.input,
      }
      let includes: any = this.data.select.filter((item: any) => {
        return data.label.includes(item.label)
      })
      if (includes.length == 0) {
        this.data.select.push(data)
      } else {
        includes[0].value = data.value
      }
      this.data.input = ''
      this.data.value = ''
      this.$emit('search', this.data.select)
    } else if (this.data.select.length != 0) {
      this.$emit('search', this.data.select)
    } else {
      return false
    }
  }
  //清除搜索
  clearSelection() {
    this.data.input = ''
    this.data.value = ''
    this.data.select = []
    this.$emit('clearSelection', '')
  }
  //删除已选条件
  handleClose(tag: any) {
    // eslint-disable-next-line no-console
    console.log(11)

    this.data.select.splice(this.data.select.indexOf(tag), 1)
    this.$emit('search', this.data.select)
  }
  //选择会员
  handleClick(data: any) {
    this.$confirm('确定绑定该普通会员?', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning',
    })
      .then(() => {
        this.$emit('xuanze', data)
      })
      .catch(() => {
        this.$message({
          type: 'info',
          message: '已取消选择',
        })
      })
  }
}
</script>

<style lang="scss">
@import '@/assets/scss/variables';

.userSelect-wrap {
  width: 100%;
  .info {
    color: #62d493;
  }
  .el-icon-close {
    position: absolute;
    right: 15px;
    top: 15px;
    cursor: pointer;
    font-size: 16px;
  }
  .select-box {
    .el-input {
      width: auto;
      margin-right: 20px;
    }
    .label {
      font-size: $Text-font;
      color: $General-colors;
      margin-right: 20px;
    }
    .el-button {
      margin-right: 15px;
    }
    .select {
      margin-bottom: 20px;
    }
    .seleted {
      display: flex;
      justify-content: space-between;
      line-height: 32px;
      margin-bottom: 20px;
      .el-tag {
        margin-right: 20px;
        border: none;
        line-height: 32px;
      }
    }
  }
}
</style>
