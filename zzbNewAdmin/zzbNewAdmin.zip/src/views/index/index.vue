<template>
  <div class="index-wrap">
    <div class="index-box">
      <div id="chart" class="chart"></div>
    </div>
  </div>
</template>

<script lang="ts" src="./index.ts"></script>

<style lang="scss">
@import "./index.scss";
</style>
