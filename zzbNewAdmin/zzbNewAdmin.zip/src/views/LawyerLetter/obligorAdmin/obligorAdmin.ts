import { Component, Vue } from "vue-property-decorator";
import {
  comselect,
  comOperation,
  comPaging,
  comtable
} from "@/components/index";
import { businessOptions } from "@/types/index.ts";
import * as Api from "@/api/business.ts";
@Component({
  components: {
    comtable,
    comselect,
    comOperation,
    comPaging
  }
})
export default class About extends Vue {
  // Getter

  // Action

  // data
  data: any = {
    loading: false,
    list: [],
    select: {},
    totalize: 0,
    options: [
      {
        value: "member_id",
        label: "会员ID"
      },
      {
        value: "member_name",
        label: "会员名称"
      },
      {
        value: "phone_number",
        label: "手机号码"
      },
      {
        value: "email",
        label: "邮箱"
      },
      {
        value: "creditor_certification",
        label: "债权人认证"
      },
      {
        value: "corporate_name",
        label: "公司企业名称"
      }
    ],
    dataType: [
      {
        label: "ID",
        prop: "id"
      },
      {
        label: "债务人编号",
        prop: "debtor_no"
      },
      {
        label: "债务人名称",
        prop: "debtor_name"
      },
      {
        label: "会员名称",
        prop: "member_name"
      },
      {
        label: "委托类别",
        prop: "entrust_type_name"
      },
      {
        label: "地区",
        prop: "address_txt"
      },
      {
        label: "欠款币种",
        prop: "currency_name"
      },
      {
        label: "欠款本金(元)",
        prop: "arrears_principal"
      },
      {
        label: "利息/违约金/滞纳金总计(元)",
        prop: "arrears_interest"
      },
      {
        label: "回款金额(元)",
        prop: "repayment_amount"
      },
      {
        label: "债务人反馈",
        prop: "feedback_number"
      },
      {
        label: "失信被执行人",
        prop: " is_dishonesty"
      },
      {
        label: "用户端备注",
        prop: "f_remarks"
      },
      {
        label: "后台备注",
        prop: "d_remarks"
      }
    ]
  };
  getData: businessOptions["getDebtor"] = {
    page: 1,
    limit: this.$store.getters.limit,
    entrust_type: "",
    debtor_no: 0,
    batch_no: "",
    member_name: "",
    debtor_name: "",
    debtor_type: "",
    contact_person: "",
    phone_number: "",
    email: "",
    address_txt: "",
    currency_id: 0,
    creditor_name: "",
    creditor_telphone: "",
    creditor_email: ""
  };
  list: any = [];
  visible: boolean = false;
  created() {
    //
  }

  activated() {
    this.init();
  }

  mounted() {
    //
  }
  // 初始化函数
  init() {
    let self: any = this;
    let params: any =
      JSON.stringify(self.data.select) == "{}"
        ? self.getData
        : self.data.select;
    this.getList(params);
  }
  //获取数据
  getList(params: businessOptions["getDebtor"]) {
    let data: any = this.data;
    data.loading = true;
    data.list = this.list;
    Api.getDebtorList(params).then((res: any) => {
      data.loading = false;
      res.data.forEach((item: any) => {
        item.audit_status =
          item.audit_status == 0
            ? "待审核"
            : item.audit_status == 1
            ? "未通过"
            : "已通过";
      });
      data.list = res.data;
      data.totalize = res.count;
    });
  }
  //跳转管理页面
  goAdmin(data: any) {
    this.$router.push({
      path: `/LawyerLetter/entrustAdmin/${data.row.batch_id}`
    });
  }
  //删除
  handleDelete(data: any) {
    // Api.vipUserDelet(data.row.id).then((res: any) => {
    //   if (res.data != 0) {
    //     this.$message.success(res.msg);
    //     this.init();
    //   } else {
    //     this.$message.warning(res.msg);
    //   }
    // });
  }
  //搜索
  search(data: any) {
    let self: any = this;
    self.data.loading = true;
    self.getData.page = 1;
    let params: any = Object.assign({}, self.getData);
    data.forEach((item: any) => {
      let name: string = item.label;
      params[name] = item.value;
    });
    self.data.select = params;
    this.getList(params);
  }
  //清除搜索项
  clearSelection(data: any) {
    let self: any = this;
    self.data.select = {};
    this.init();
  }
  //添加
  add() {
    // this.$router.push({
    //   path: "/VIP/addVip"
    // });
    this.visible = true;
  }
  //分页
  watchChange(index: number, limit: number | null) {
    let self: any = this;
    let params: any =
      JSON.stringify(self.data.select) == "{}"
        ? self.getData
        : self.data.select;
    params.page = index;
    params.limit = limit == null ? params.limit : limit;
    self.init();
  }
  //弹窗确定
  determine() {
    this.init();
  }
  //取消
  cancel() {
    this.visible = false;
  }
}
