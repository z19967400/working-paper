<template>
  <div class="entrustAdmin-wrap">
    <div class="entrustAdmin-box">
      <div :style="{ height: data.labers.length * 40 + 'px' }" class="left">
        <div class="text">
          <div v-for="(item, index) in data.labers" :key="index" :class="{ act: index == data.actIndex }" @click="laberClick(index)">
            {{ item.name }}
          </div>
        </div>
        <div class="shuxian-box">
          <div :style="{ transform: ' translateY(' + data.actIndex * 40 + 'px)' }" class="shuxian"></div>
        </div>
      </div>
      <div ref="right" :style="{ height: height + 'px' }" class="right">
        <div ref="section0" class="section">
          <span style="margin-top:0;" :class="{ act: data.actIndex == 0 }">
            <span class="title">委托概况</span>
          </span>
          <el-divider></el-divider>
          <div class="box">
            <div v-for="(item, index) in data.BasicInfo" :key="index" class="text">
              <p v-for="(item2, index2) in item" :key="index2">
                <span>{{ item2.name }}</span>
                <span>{{ item2.value }}</span>
              </p>
            </div>
          </div>
        </div>
        <div ref="section1" class="section">
          <span :class="{ act: data.actIndex == 1 }">
            <span class="title">执行进度</span>
          </span>
          <el-divider></el-divider>
          <div class="box">
            <table1 :tableOption="data.implementOption" :tableData="data.implementList"></table1>
          </div>
        </div>
        <div ref="section2" class="section">
          <span :class="{ act: data.actIndex == 2 }">
            <span class="title">债权人</span>
          </span>
          <el-divider></el-divider>
          <div class="box">
            <table1 :operation="true" :tableOption="data.creditorOption" :tableData="data.creditorList"></table1>
          </div>
        </div>
        <div ref="section3" class="section">
          <span :class="{ act: data.actIndex == 3 }">
            <span class="title">债务人</span>
            <el-button @click="DownLoadEMS" style="color:#67C23A;float:right;" type="text" size="small">快递信息下载</el-button>
          </span>
          <el-divider></el-divider>
          <div class="box">
            <table2 :tableOption="data.obligorOption" @tongzhi="tongzhi" :tableData="data.obligorList" @stop="taskStop" @info="openInfo" @edit="openEdit" @address="addressEdit"></table2>
          </div>
        </div>
        <div ref="section4" class="section">
          <span :class="{ act: data.actIndex == 4 }">
            <span class="title">债务明细</span>
          </span>
          <el-divider></el-divider>
          <div class="box">
            <table3 :tableOption="data.debtDetailsOption" :states="data.shenhe.audit_status" :tableData="data.debtDetailsList" @edit="debtDetailsEdit"></table3>
          </div>
        </div>
        <div ref="section5" class="section">
          <span :class="{ act: data.actIndex == 5 }">
            <span class="title">支付信息</span>
          </span>
          <el-divider></el-divider>
          <div class="box">
            <div v-for="(item, index) in data.payment" :key="index" class="text">
              <p v-for="(item2, index2) in item" :key="index2">
                <span>{{ item2.name }}</span>
                <span v-if="item2.name != '收支详情'">{{ item2.value }}</span>
                <el-button v-if="item2.name == '收支详情'" class="info" size="small" type="text" @click="paymentInfo($route.params.id)">查看</el-button>
              </p>
            </div>
          </div>
        </div>
        <div ref="section6" class="section">
          <span :class="{ act: data.actIndex == 6 }">
            <span class="title">审核/反馈</span>
          </span>
          <el-divider></el-divider>
          <div style="width:100%;" class="box">
            <el-form style="width:100%;" :model="data.shenhe" label-width="60px">
              <el-form-item label="状态">
                <el-radio-group v-model="data.shenhe.audit_status">
                  <el-radio label="Audit_states_0">待审核</el-radio>
                  <el-radio label="Audit_states_1">未通过</el-radio>
                  <el-radio label="Audit_states_2">已通过</el-radio>
                </el-radio-group>
              </el-form-item>
              <span style="color:#909399;font-size:14px;margin-left:17px;margin-bottom:10px;display:block;">此处反馈将直接反馈给用户</span>
              <el-form-item label="反馈">
                <el-input style="width:80%;" type="textarea" :rows="5" v-model="data.shenhe.desc"></el-input>
              </el-form-item>
              <el-form-item>
                <el-button @click="beizhu" plain size="small" type="primary">保存</el-button>
              </el-form-item>
            </el-form>
          </div>
        </div>
        <div ref="section7" class="section">
          <span :class="{ act: data.actIndex == 7 }">
            <span class="title">后台备注</span>
          </span>
          <el-divider></el-divider>
          <div style="flex-wrap: wrap;" class="box">
            <el-row style="width:100%;margin-bottom:20px;">
              <el-col :span="18">
                <el-input type="textarea" :rows="5" v-model="data.back_remarks"></el-input>
              </el-col>
            </el-row>
            <el-row style="width:100%;">
              <el-col>
                <el-button @click="back_remarksSave" plain size="small" type="primary">保存</el-button>
              </el-col>
            </el-row>
          </div>
        </div>
      </div>
    </div>
    <div class="zhezhao" @click="data.visible = false;data.editShow=false" v-show="data.visible || data.editShow"></div>
    <el-popover :title="data.infoTitle" popper-class="editData" v-model="data.visible">
      <span @click="close" class="el-icon-close close"></span>
      <comInfo :info="info" :loading="data.loading" :infoData="infoData2" :actName="data.actName" @nameWatch="nameWatch"></comInfo>
    </el-popover>
    <el-popover title="债务人编辑" popper-class="editData obligor" v-model="data.editShow">
      <span @click="data.editShow = false" class="el-icon-close close"></span>
      <comEdit :info="editData" @edit="editSubmit" @close="editClose"></comEdit>
    </el-popover>
    <el-popover title="债务明细编辑" popper-class="editData obligor" v-model="data.detailedShow">
      <span @click="data.detailedShow = false" class="el-icon-close close"></span>
      <el-input v-model="detailed" placeholder="请输入内容"></el-input>
      <el-button style="margin-top:20px;" @click="detailedSave" type="primary">保存</el-button>
    </el-popover>
    <div class="btn-box">
      <!-- <el-button size="small" type="success">下载催收报告</el-button>
        <el-button el-button size="small" type="success">下载快递信息</el-button> -->
      <el-button size="small" @click="revoke" type="primary">返回 </el-button>
      <el-button :disabled="data.executing_states != 'AI_State_1'" size="small" @click="entrustRevoke" plain type="primary">撤销</el-button>
      <el-button size="small" @click="entrustDelet" plain type="primary">删除</el-button>
    </div>
    <el-dialog title="短信通知" width="35%" :visible.sync="tongzhiTost">
      <div class="info-box">
        <el-row>
          <el-col :span="4">
            <span style="line-height: 40px;display:inline-block">债务人名称</span>
          </el-col>
          <el-col :span="20">
            <el-input v-model="tzData.debtor_name" placeholder="请输入债务人名称"></el-input>
          </el-col>
        </el-row>
        <el-row style="margin-top:20px;">
          <el-col :span="4">
            <span style="line-height: 40px;display:inline-block">债权人联系手机</span>
          </el-col>
          <el-col :span="20">
            <el-input v-model="tzData.phone_number" placeholder="请输入债权人联系手机"></el-input>
          </el-col>
        </el-row>
      </div>
      <div slot="footer" class="dialog-footer">
        <el-button @click="tzqx">取 消</el-button>
        <el-button type="primary" @click="tzRelease">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Watch } from 'vue-property-decorator'
import { Getter, Action } from 'vuex-class'
import * as Api from '../../../api/business'
import { verifyPhone, verifyEmall } from '../../../utils/common'
import table1 from './components/table1.vue'
import table2 from './components/table2.vue'
import table3 from './components/table3.vue'
import comInfo from './components/comInfo.vue'
import comEdit from './components/obligorEdit.vue'
import { api } from '../../../../../zzbPc/src/assets/js/api'
@Component({
  components: {
    table1,
    table2,
    table3,
    comInfo,
    comEdit,
  },
})
export default class About extends Vue {
  //手机号码验证
  validatePhone = (rule: any, value: any, callback: any) => {
    let vtf: any = verifyPhone(value)
    if (!vtf.done) {
      callback(new Error(vtf.errMsg))
    } else {
      callback()
    }
  }
  //邮箱验证
  validateEmall = (rule: any, value: any, callback: any) => {
    let vtf: any = verifyEmall(value)
    if (!vtf.done) {
      callback(new Error(vtf.errMsg))
    } else {
      callback()
    }
  }
  // data
  data: any = {
    executing_states: '', //订单状态
    actIndex: 0,
    actName: 'first',
    infoTitle: '债务人详情',
    visible: false,
    loading: true,
    sendstates: [],
    editShow: false,
    detailedShow: false,
    labers: [
      { name: '委托概况' },
      { name: '执行进度' },
      { name: '债权人' },
      { name: '债务人' },
      { name: '债务明细' },
      { name: '支付信息' },
      { name: '审核/反馈' },
      { name: '后台备注' },
    ],
    BasicInfo: [
      //基础信息
      [
        { name: '委托批次号', value: '', prop: 'batch_no' },
        { name: '发函方式', value: '', prop: 'send_type' },
      ],
      [
        { name: '债务类别', value: '', prop: 'debt_type' },
        { name: '创建人', value: '', prop: 'create_name' },
      ],
      [
        { name: '法催主体', value: '', prop: 'logo_type' },
        { name: '创建时间', value: '', prop: 'create_time' },
      ],
    ],
    payment: [
      //支付信息
      [{ name: '支付状态', value: '', prop: 'pay_status' }],
      // [{ name: '支付方式', value: '' }],
      // [{ name: '收支详情', value: '' }],
    ],
    //执行进度
    implementList: [],
    implementOption: [
      { prop: 'send_sort', label: '进程' },
      { prop: 'task_type_name', label: '项目' },
      { prop: 'task_execution_status', label: '执行进度' },
      { prop: 'effect', label: '效果（总数/已完成）' },
      { prop: 'send_time', label: '计划执行时间' },
    ],
    //债权人
    creditorList: [],
    creditorOption: [
      { prop: 'id', label: 'ID', width: '80px' },
      { prop: 'creditor_name', label: '债权人名称' },
      { prop: 'phone_number', label: '公司电话', width: '120px' },
      { prop: 'email', label: '电子邮箱' },
      { prop: 'audit_status', label: '审核状态', width: '120px' },
      { prop: 'create_time', label: '创建时间', width: '180px' },
    ],
    //债务人
    obligorEditOption: [], //债务人修改信息
    obligorList: [],
    obligorOption: [
      { prop: 'debtor_number', label: '委托编号', width: '180px' },
      { prop: 'debtor_name', label: '债务人名称', width: '330px' },
      { prop: 'receiving_name', label: '收件人', width: '180px' },
      { prop: 'phone_number', label: '收件人电话', width: '120px' },
      { prop: 'email', label: '电子邮箱', width: '120px' },
      { prop: 'address_txt', label: '详细地址', width: '500px' },
      { prop: 'address_selected', label: '地区', width: '220px' },
      { prop: 'arrears_principal', label: '欠款本金', width: '180px' },
      { prop: 'arrears_interest', label: '欠款利息', width: '180px' },
      { prop: 'execution_progress', label: '执行进度' },
      { prop: 'sms_01_status', label: '首次短信' },
      { prop: 'call_01_status', label: '首次电话', ishow: false },
      { prop: 'email_01_status', label: '邮件催款函', width: '120px' },
      { prop: 'email_02_status', label: '电子律师函', width: '120px' },
      { prop: 'logistics_status', label: 'EMS律师函', width: '120px' },
      { prop: 'sms_02_status', label: '末次短信' },
      { prop: 'call_02_status', label: '末次电话' },
    ],
    //债务明细
    debtDetailsList: [],
    debtDetailsOption: [
      { prop: 'id', label: '委托编号' },
      { prop: 'id', label: '表头001' },
      { prop: 'id', label: '表头002' },
      { prop: 'id', label: '表头003' },
      { prop: 'id', label: '表头004' },
    ],
    shenhe: {
      //审核反馈
      desc: '', //反馈
      audit_status: '', //审核状态
    },
    back_remarks: '', //后台备注
    state: 0, //是否支付 0：未支付，1:已支付
  }
  height: number = 0
  sectionDom: any = {}
  infoData: any = {
    SmsInfo: {},
    SmsInfo1: {},
    PhoneInfo: {},
    PhoneInfo1: {},
    LawyerInfo: {},
    Email: {},
  }
  editData: any = {
    list: [],
    data: {},
    Collection: '',
    lawyerLetter: '',
  }
  option: any = {} //获取短信等参数
  info: any = {} //子组件数据
  detailed: string = '' //债务明细编辑内容
  detailedId: any = '' //债务明细ID
  infoData2: any = {
    phone: '',
    email: '',
  }
  tongzhiTost: boolean = false
  tzData: any = {
    debtor_name: '',
    phone_number: '',
    debtor_number: '',
  }
  created() {
    //
  }

  activated() {
    let self: any = this
    this.init()
    self.height = document.body.offsetHeight - 188
  }

  mounted() {
    //
  }

  beforeDestroy() {
    //
  }
  init() {
    let self: any = this
    self.data.executing_states = self.$route.params.executing_states
    if (self.$route.params.id != 0 && self.$route.params.id != null) {
      this.getInfo(self.$route.params.id)
      // this.GetType()
    }
    let top: number = self.$refs.right.offsetTop //初始位置
    for (let index = 0; index <= 6; index++) {
      const domTop = self.$refs['section' + index].offsetTop - top
      self.sectionDom['section' + index] = domTop
    }
  }
  //子组件监听
  nameWatch(name: string) {
    this.data.actName = name
    this.info = {}
    if (name == 'first') {
      //首次短信
      if (this.option.sms_01_id != 0) {
        this.data.loading = true
        this.getinfo2(this.option.sms_01_id, 'AI_Task_Code_1')
      }
    }
    if (name == 'second') {
      //首次电话
      if (this.option.call_01_id != 0) {
        this.data.loading = true
        this.getinfo2(this.option.call_01_id, 'AI_Task_Code_2')
      }
    }
    if (name == 'third') {
      //邮件催款函
      if (this.option.email_01_id != 0) {
        this.data.loading = true
        this.getinfo2(this.option.email_01_id, 'AI_Task_Code_3')
      }
    }
    if (name == 'fourth') {
      //电子律师函
      if (this.option.email_02_id != 0) {
        this.data.loading = true
        this.getinfo2(this.option.email_02_id, 'AI_Task_Code_4')
      }
    }
    if (name == 'Five') {
      //ems律师函
      if (this.option.log_logistics_id != 0) {
        this.data.loading = true
        this.getinfo2(this.option.log_logistics_id, 'AI_Task_Code_5')
      }
    }
    if (name == 'six') {
      //末次短信
      if (this.option.sms_02_id != 0) {
        this.data.loading = true
        this.getinfo2(this.option.sms_02_id, 'AI_Task_Code_6')
      }
    }
    if (name == 'seven') {
      //末次电话
      if (this.option.call_02_id != 0) {
        this.data.loading = true
        this.getinfo2(this.option.call_02_id, 'AI_Task_Code_7')
      }
    }
  }
  getinfo2(id: any, code: any) {
    let self: any = this
    let parmas: any = {
      batch_no: self.$route.params.id,
      task_id: id,
      ai_task_code: code,
      debtor_number: self.option.debtor_number,
    }
    Api.getPhoneInfo(parmas).then((res: any) => {
      this.info = res.data
      this.data.loading = false
    })
  }
  //获取管理详情
  getInfo(id: number) {
    Api.getAiLawyerAdmin(id).then((res: any) => {
      //执行进度
      if (res.data.tasks_list.length != 0) {
        res.data.tasks_list.forEach((item: any) => {
          item.send_sort = item.send_sort + 1
          item.task_execution_status =
            item.task_execution_status == 0
              ? '未执行'
              : item.task_execution_status == 1
              ? '执行中'
              : item.task_execution_status == 2
              ? '已结束'
              : item.task_execution_status == 3
              ? '已撤销'
              : item.task_execution_status == 4
              ? '执行中'
              : item.task_execution_status == 5
              ? '执行中'
              : '已终止'
          item.send_time = item.send_time.replace('T', ' ')
          item.send_time = item.send_time.substring(0, item.send_time.lastIndexOf(':'))
          item['effect'] = item.task_total + '/' + item.task_success_total
        })
      }
      this.data.implementList = res.data.tasks_list
      //债权人
      if (res.data.creditor != null) {
        res.data.creditor.audit_status =
          res.data.creditor.audit_status == 'Audit_states_0'
            ? '待审核'
            : res.data.creditor.audit_status == 'Audit_states_1'
            ? '未通过'
            : '已通过'
        res.data.creditor.create_time = res.data.creditor.create_time.replace('T', ' ')
        res.data.creditor.create_time = res.data.creditor.create_time.substring(
          0,
          res.data.creditor.create_time.lastIndexOf(':')
        )
        let arr: any = []
        arr.push(res.data.creditor)
        this.data.creditorList = arr
      }
      //债务人及任务计划
      if (res.data.debtor_list.length != 0) {
        let arr: any = res.data.debtor_list
        let debtor: any = res.data.debtor_list[0]
        arr.forEach((item: any) => {
          item['isAddress'] = false
          item.sms_01_status =
            item.sms_01_id == 0
              ? '未委托'
              : item.sms_01_status == -1
              ? '待执行'
              : item.sms_01_status == 0
              ? '执行成功'
              : item.sms_01_status == 2
              ? '执行失败'
              : '未委托'
          item.call_01_status =
            item.call_01_id == 0
              ? '未委托'
              : item.call_01_status == -1
              ? '待执行'
              : item.call_01_status == 0
              ? '执行中'
              : item.call_01_status == 1
              ? '执行成功'
              : item.call_01_status == 5
              ? '执行中'
              : '执行失败'
          item.email_01_status =
            item.email_01_id == 0
              ? '未委托'
              : item.email_01_status == -1
              ? '待执行'
              : item.email_01_status == 0
              ? '执行成功'
              : '执行失败'
          item.email_02_status =
            item.email_02_id == 0
              ? '未委托'
              : item.email_02_status == -1
              ? '待执行'
              : item.email_02_status == 0
              ? '执行成功'
              : '执行失败'
          item.logistics_status =
            item.log_logistics_id == 0
              ? '未委托'
              : item.logistics_status == 0
              ? '待执行'
              : item.logistics_status == 1
              ? '执行中'
              : item.logistics_status == 3
              ? '执行成功'
              : '执行失败'
          item.sms_02_status =
            item.sms_02_id == 0
              ? '未委托'
              : item.sms_02_status == -1
              ? '待执行'
              : item.sms_02_status == 0
              ? '执行成功'
              : '执行失败'
          item.call_02_status =
            item.call_02_id == 0
              ? '未委托'
              : item.call_02_status == -1
              ? '待执行'
              : item.call_02_status == 0
              ? '执行中'
              : item.call_02_status == 1
              ? '执行成功'
              : item.call_01_status == 5
              ? '执行中'
              : '执行失败'
        })
        arr.forEach((item: any) => {
          if (item.execution_progress == '已终止') {
            if (item.sms_01_status != '执行成功' && item.sms_01_status != '未委托') {
              item.sms_01_status = '已终止'
            }
            if (item.call_01_status != '执行成功' && item.call_01_status != '未委托') {
              item.call_01_status = '已终止'
            }
            if (item.email_01_status != '执行成功' && item.email_01_status != '未委托') {
              item.email_01_status = '已终止'
            }
            if (item.email_02_status != '执行成功' && item.email_02_status != '未委托') {
              item.email_02_status = '已终止'
            }
            if (item.logistics_status != '执行成功' && item.logistics_status != '未委托') {
              item.logistics_status = '已终止'
            }
            if (item.sms_02_status != '执行成功' && item.sms_02_status != '未委托') {
              item.sms_02_status = '已终止'
            }
            if (item.call_02_status != '执行成功' && item.call_02_status != '未委托') {
              item.call_02_status = '已终止'
            }
          }
        })
      }

      this.data.obligorList = res.data.debtor_list
      this.data.payment[0][0].value =
        res.data.overview.pay_status == 'Pay_Status_0' ? '待支付' : '已支付'
      // this.data.payment[1][0].value = res.data.pay_method_name
      this.data.shenhe.audit_status = res.data.overview.audit_status
      this.data.shenhe.desc = res.data.overview.audit_feedback
      this.data.back_remarks = res.data.overview.back_remarks
      this.data.state = res.data.overview.pay_status
      //基础信息
      this.data.BasicInfo.forEach((item: any) => {
        item.forEach((item2: any) => {
          if (res.data.overview[item2.prop] != undefined) {
            item2.value = res.data.overview[item2.prop]
            if (item2.prop == 'logo_type') {
              item2.value = item2.value == 'Logo_type_0' ? '诚收法催' : '债主帮'
            }
            if (item2.name == '发函方式') {
              item2.value = item2.value == '1' ? 'EMS快递' : '电子律师函'
            }
            if (item2.name == '创建时间') {
              item2.value = item2.value
                .replace('T', ' ')
                .substring(0, item2.value.replace('T', ' ').lastIndexOf(':'))
            }
            if (item2.name == '债务类别') {
              item2.value =
                item2.value == 'Debt_type_0'
                  ? '民间借贷'
                  : item2.value == 'Debt_type_4'
                  ? '企业应收款'
                  : item2.value == 'Debt_type_5'
                  ? '逾期贷款'
                  : item2.value == 'Debt_type_6'
                  ? '信用卡逾期'
                  : item2.value == 'Debt_type_7'
                  ? '保险追偿'
                  : item2.value == 'Debt_type_8'
                  ? '物业/采暖欠费'
                  : '不当得利'
            }
          }
        })
      })
      this.data.debtDetailsList = []
      // 债务明细
      if (res.data.debtor_details_list.length > 0) {
        let debtDetailsOption: any = [
          // { prop: 'id', label: 'ID', width: '80px' },
          { prop: 'debtor_no', label: '债务人编号', width: '200px' },
        ]
        let ctt: any = res.data.debtor_details_list.filter((item: any) => {
          return item.is_headers == 1
        })
        let ctt2: any = res.data.debtor_details_list.filter((item: any) => {
          return item.is_headers != 1
        })
        let content: any = ctt[0].debt_content.split('╫')
        content.forEach((item: any, index: number) => {
          if (index == 0) {
            let dd: any = {
              prop: 'prop' + index,
              label: item.split('&')[1],
              // width: item.length * 20 + "px"
            }
            debtDetailsOption.push(dd)
          } else {
            let dd: any = {
              prop: 'prop' + index,
              label: item,
              // width: item.length * 20 + "px"
            }
            debtDetailsOption.push(dd)
          }
        })
        this.data.debtDetailsOption = debtDetailsOption
        if (res.data.debtor_details_list.length > 1) {
          let debtDetailsList: any = []
          ctt2.forEach((item: any, index: number) => {
            let list: any = item.debt_content.split('╫')
            let obj: any = {}
            // obj['debtor_number'] = item.debtor_number
            // obj['debtor_name'] = item.debtor_name
            list.forEach((item2: any, index2: number) => {
              if (index2 == 0) {
                obj['debtor_no'] = item.batch_no + '_' + item.debtor_no
                obj['prop' + index2] = item2.split('&')[1]
              } else {
                obj['prop' + index2] = item2
              }
            })
            debtDetailsList.push(obj)
          })
          this.data.debtDetailsList = debtDetailsList
        }
      }
    })
  }
  //债务人分类
  setObligorOption(res: any) {
    let obligorType: string = res.debtor_type //债务人类别
    let debtorType: string = this.data.BasicInfo[1][0].value //债务类别
    let variable: any = []
    let constant: any = [
      // { prop: 'debtor_number', label: '债务人编号', width: '120px' },
      { prop: 'currency', label: '欠款币种', width: '80px' },
      { prop: 'arrears_principal', label: '欠款本金', width: '200px' },
      { prop: 'arrears_interest', label: '违约金/利息', width: '200px' },
      { prop: 'creditor_name', label: '债权人联系人', width: '200px' },
      { prop: 'creditor_telphone', label: '联系人电话', width: '200px' },
      { prop: 'creditor_email', label: '联系人邮箱', width: '200px' },
      // {
      //   prop: 'lawyer_letter_execution_status',
      //   label: '律师函',
      //   width: '80px',
      // },
      // { prop: 'email_execution_status', label: '邮件', width: '80px' },
      // {
      //   prop: 'first_sms_execution_status',
      //   label: '第一次短信',
      //   width: '100px',
      // },
      // {
      //   prop: 'first_phone_execution_status',
      //   label: '第一次电话',
      //   width: '100px',
      // },
      // {
      //   prop: 'last_sms_execution_status',
      //   label: '第二次短信',
      //   width: '100px',
      // },
      // {
      //   prop: 'last_phone_execution_status',
      //   label: '第二次电话',
      //   width: '100px',
      // },
      // { prop: 'member_remarks', label: '用户端备注', width: '200px' },
    ]
    // 个人
    if (obligorType == 'Creditor_states_1') {
      let currency: any = [
        { prop: 'debtor_name', label: '债务人', width: '120px' },
        { prop: 'phone_number', label: '债务人手机', width: '200px' },
        { prop: 'email', label: '债务人邮箱', width: '200px' },
        // { prop: 'city_name', label: '债务人地区', width: '250px' },
        { prop: 'address_txt', label: '债务人地址', width: '400px' },
      ]
      if (debtorType == '保险追偿') {
        let item: any = {
          prop: 'insurer_name',
          label: '被保险人名称',
          width: '120px',
        }
        currency.push(item)
      } else if (debtorType == '欠费欠租') {
        let item: any = {
          prop: 'arrearage_type',
          label: '欠费类型',
          width: '120px',
        }
        currency.push(item)
      } else if (debtorType == '信用卡逾期') {
        let item: any = {
          prop: 'settlement_date',
          label: '结算日期',
          width: '200px',
        }
        currency.push(item)
      }
      variable = currency
      //企业
    } else if (obligorType == 'Creditor_states_0') {
      let currency: any = [
        { prop: 'debtor_name', label: '债务人', width: '250px' },
        {
          prop: 'contact_person',
          label: '企业负责人',
          width: '120px',
        },
        {
          prop: 'phone_number',
          label: '债务人手机',
          width: '200px',
        },
        { prop: 'email', label: '债务人邮箱', width: '200px' },
        // { prop: 'city_name', label: '债务人地区', width: '250px' },
        {
          prop: 'address_txt',
          label: '债务人地址',
          width: '400px',
        },
      ]
      if (debtorType == '保险追偿') {
        let item: any = {
          prop: 'insurer_name',
          label: '被保险人名称',
          width: '120px',
        }
        currency.push(item)
      } else if (debtorType == '欠费欠租') {
        let item: any = {
          prop: 'arrearage_type',
          label: '欠费类型',
          width: '120px',
        }
        currency.push(item)
      }
      variable = currency
    }
    this.data.obligorEditOption = variable.concat(constant)
  }
  //点击左侧菜单事件
  laberClick(index: number) {
    let self: any = this
    self.data.actIndex = index
    let top: number = self.$refs.right.offsetTop //初始位置
    let dom: any = 'section' + index //点击元素的位置
    let actTop: number = self.$refs[dom].offsetTop
    self.$refs.right.scrollTop = actTop - top
  }
  //滚动监听
  scrollGet(e: any) {
    if (e.target.scrollTop <= this.sectionDom.section0) {
      this.data.actIndex = 0
    } else if (e.target.scrollTop <= this.sectionDom.section1) {
      this.data.actIndex = 1
    } else if (e.target.scrollTop <= this.sectionDom.section2) {
      this.data.actIndex = 2
    } else if (e.target.scrollTop <= this.sectionDom.section3) {
      this.data.actIndex = 3
    } else if (e.target.scrollTop <= this.sectionDom.section4) {
      this.data.actIndex = 4
    } else if (e.target.scrollTop <= this.sectionDom.section5) {
      this.data.actIndex = 5
    } else if (e.target.scrollTop <= this.sectionDom.section6) {
      this.data.actIndex = 6
    }
  }
  //审核
  beizhu() {
    let self: any = this
    let parmas: any = {
      audit_status: self.data.shenhe.audit_status,
      audit_feedback: self.data.shenhe.desc,
      batch_no: self.$route.params.id,
    }
    if (parmas.audit_status == 'Audit_states_2' && self.data.state == 0) {
      self.$message.warning('该订单未完成支付')
      return false
    }
    self
      .$confirm('此笔审核中有反馈内容至用户，您确定保存审核吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
      .then(() => {
        Api.examiningAILawyer(parmas).then((res: any) => {
          if (res.data != 0) {
            self.$message.success(res.msg)
            self.init()
          } else {
            self.$message.warning(res.msg)
          }
        })
      })
      .catch(() => {
        self.$message({
          type: 'info',
          message: '已取消保存',
        })
      })
  }
  //后台备注
  back_remarksSave() {
    let self: any = this
    Api.breakSave(self.data.BasicInfo[0][0].value, self.data.back_remarks).then((res: any) => {
      if (res.state) {
        self.$message.success(res.msg)
        self.init()
      } else {
        self.$message.warning(res.msg)
      }
    })
  }
  //查看收支信息
  paymentInfo(id: number) {
    let self: any = this
    self.$router.push({
      path: '/business/inandout',
      params: {
        id,
      },
    })
  }
  //撤销
  entrustRevoke() {
    let self: any = this
    self
      .$confirm('您确定撤销吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
      .then(() => {
        Api.entrustRevoke(self.data.BasicInfo[0][0].value).then((res: any) => {
          if (res.data != 0) {
            self.$message.success(res.msg)
            self.$router.push({
              path: '/LawyerLetter/entrustList',
            })
          } else {
            self.$message.warning(res.msg)
          }
        })
      })
      .catch(() => {
        self.$message({
          type: 'info',
          message: '已取消撤销',
        })
      })
  }
  //删除
  entrustDelet() {
    let self: any = this
    self
      .$confirm('您确定删除吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
      .then(() => {
        Api.entrustDelete(self.data.BasicInfo[0][0].value).then((res: any) => {
          if (res.state) {
            self.$message.success(res.msg)
            self.$router.push({
              path: '/LawyerLetter/entrustList',
            })
          } else {
            self.$message.warning(res.msg)
          }
        })
      })
      .catch(() => {
        self.$message({
          type: 'info',
          message: '已取消删除',
        })
      })
  }
  //返回
  revoke() {
    let self: any = this
    self.$router.go(-1)
  }
  //关闭弹窗
  close() {
    this.data.visible = false
  }
  //打开详情弹窗
  openInfo(data: any) {
    this.data.actName = 'first'
    this.data.infoTitle = data.name
    this.data.visible = true
    this.option = data
    this.infoData2.phone = data.phone_number
    this.infoData2.email = data.email
    this.infoData2['isStop'] = data.executing_status
    // eslint-disable-next-line no-console
    console.log(this.infoData2)

    //首次短信
    this.getinfo2(this.option.sms_01_id, 'AI_Task_Code_1')
  }
  //打开编辑弹窗
  openEdit(data: any) {
    this.data.editShow = true
    this.setObligorOption(data)
    this.editData.list = this.data.obligorEditOption
    this.editData.data = data
    Api.getCollection(data.debtor_number).then((res: any) => {
      this.editData.Collection = res.data.csh_content
      this.editData.lawyerLetter = res.data.lsh_content
    })
  }
  //任务终止
  taskStop(data: any) {
    let self: any = this
    self
      .$confirm('您确定终止任务吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
      .then(() => {
        Api.taskStop(data.debtor_number).then((res: any) => {
          if (res.state) {
            self.$message.success(res.msg)
            self.init()
          } else {
            self.$message.warning(res.msg)
          }
        })
      })
      .catch(() => {
        self.$message({
          type: 'info',
          message: '已取消终止',
        })
      })
  }
  //编辑提交
  editSubmit(data: any) {
    let self: any = this
    let parmas1: any = data.data
    let parmas2: any = {
      debtor_number: data.data.debtor_number,
      content: data.Collection,
    }
    let parmas3: any = {
      debtor_number: data.data.debtor_number,
      content: data.lawyerLetter,
    }
    Api.UpdateDebtor(data.data).then((res1: any) => {
      Api.UpdateCollectionLetterContent(parmas2).then((res2: any) => {
        Api.UpdateLawyersLetterContent(parmas3).then((res3: any) => {
          if (res3.state) {
            this.data.editShow = false
            this.$message.success(res3.msg)
            self.init()
          } else {
            this.$message.warning(res3.msg)
          }
        })
      })
    })
  }
  //编辑弹窗关闭
  editClose() {
    this.data.editShow = false
  }
  //修改债务人地区
  addressEdit(data: any) {
    let parmas: any = {
      debtor_number: data['id'],
      country: data['country'],
      province: data['province'],
      city: data['city'],
      county: data['county'],
    }
    Api.debtorAddressEdit(parmas).then((res: any) => {
      if (res.state) {
        this.$message.success(res.msg)
        this.init()
      } else {
        this.$message.warning(res.msg)
      }
    })
  }
  //获取执行状态字典
  GetType() {
    Api.GetType('Executing_states_send').then((res: any) => {
      this.data.sendstates = res.data
    })
  }
  //打开债务明细
  debtDetailsEdit(data: any) {
    this.data.detailedShow = true
    let val: string = ''
    Object.keys(data).forEach((key: string, index: number) => {
      if (data[key] != '') {
        if (index == 0) {
          this.detailedId = data[key]
        } else {
          val += data[key] + '╫'
        }
      }
    })
    this.detailed = val.substring(0, val.length - 1)
  }
  //债务明细编辑保存
  detailedSave() {
    let self: any = this
    let parmas: any = {
      id: self.detailedId,
      batch_no: self.$route.params.id,
      debt_content: self.detailed,
      is_headers: 0,
    }
    Api.debtDetailsEdit(parmas).then((res: any) => {
      if (res.state) {
        this.$message.success(res.msg)
        this.data.detailedShow = false
        this.init()
      } else {
        this.$message.warning(res.msg)
      }
    })
  }
  //快递信息下载
  DownLoadEMS() {
    let self: any = this
    var elemIF = document.createElement('iframe')
    elemIF.src =
      'http://api1.debteehelper.com/api/AILawyerLetter/DownLoadEMS?batch_no=' +
      self.$route.params.id
    elemIF.style.display = 'none'
    document.body.appendChild(elemIF)
  }
  //通知
  tongzhi(data: any) {
    this.tongzhiTost = true
    Object.keys(this.tzData).forEach((key: string) => {
      if (key == 'phone_number') {
        this.tzData[key] = data['creditor_telphone_2']
      } else {
        this.tzData[key] = data[key]
      }
    })
  }
  //通知quxiao
  tzqx() {
    this.tzData = {
      debtor_name: '',
      phone_number: '',
      debtor_number: '',
    }
    this.tongzhiTost = false
  }
  //通知确定
  tzRelease() {
    this.$confirm('确定发送短信通知吗?', '提示', {
      confirmButtonText: '确定',
      cancelButtonText: '取消',
      type: 'warning',
    })
      .then(() => {
        Api.smsTongzhi(this.tzData).then((res: any) => {
          if (res.state) {
            this.tongzhiTost = false
            this.$message({
              type: 'success',
              message: res.msg,
            })
          } else {
            this.$message({
              type: 'error',
              message: res.msg,
            })
          }
        })
      })
      .catch(() => {
        this.$message({
          type: 'info',
          message: '已取消发送',
        })
      })
  }
}
</script>

<style lang="scss">
@import '@/assets/scss/variables';

.entrustAdmin-wrap {
  width: 100%;
  min-height: 100%;
  background-color: $main-body-bgColor;
  position: relative;
  .entrustAdmin-box {
    display: flex;
    & .el-table th,
    .el-table td {
      text-align: center;
    }
    & .left {
      width: 10%;
      display: flex;
      & > .text {
        div {
          color: $Main-characters;
          font-size: $Text-font;
          height: 40px;
          line-height: 40px;
          padding: 0 25px 0 0;
          text-align: center;
          cursor: pointer;
        }
        .act {
          color: #ec193a;
        }
      }
      & > .shuxian-box {
        height: 100%;
        width: 2px;
        background-color: #e4e7ed;
        position: relative;
        & > .shuxian {
          width: 100%;
          height: 40px;
          background-color: #ec193a;
          transition: transform 0.5s ease;
          transform: translateY(0);
        }
      }
    }
    & .right {
      width: 90%;
      overflow-y: auto;
      padding-right: 20px;
      .act {
        color: #ec193a !important;
      }
      & .section {
        margin-bottom: 20px;
        & > span:first-child {
          margin-top: 10px;
          display: block;
          height: 20px;
        }
        .box {
          display: flex;
          .text {
            width: 33.33%;
            p {
              color: $General-colors;
              font-size: 14px;
              margin: 0;
              margin-bottom: 10px;
              line-height: 32px;
              & > span:first-child {
                margin-right: 20px;
                font-size: 12px;
                color: $Secondary-text;
              }
            }
          }
        }
      }
    }
  }
  .el-form {
    width: 600px;
  }
  .el-divider--horizontal {
    margin: 5px 0 20px 0;
  }
  .info {
    color: #62d493;
  }
  .btn-box {
    position: absolute;
    bottom: 0;
    left: 10%;
  }
  .obligor {
    width: 600px;
    padding: 20px 40px;
  }
  .title {
    font-size: 14px;
    color: #606266;
    font-weight: bold;
    display: inline-block;
    border-left: 3px solid #e01f3c;
    height: 15px;
    line-height: 15px;
    padding-left: 10px;
  }
  .info-box {
    border-radius: 20px;
  }
}
</style>
