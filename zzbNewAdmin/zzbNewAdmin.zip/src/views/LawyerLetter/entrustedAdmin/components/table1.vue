<template>
  <div class="table1-wrap">
    <div class="table1-box">
      <el-table :data="data.list" border style="width: 100%">
        <el-table-column v-for="(item, index) in tableOption" :key="index" :prop="item.prop" :label="item.label" :width="item.width">
          <template slot-scope="scope">
            <el-popover placement="bottom" trigger="click" :content="tostr(scope.row[item.prop])" popper-class="table-click" :visible-arrow="false">
              <div slot="reference" class="cell">
                {{ scope.row[item.prop] }}
              </div>
            </el-popover>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator'
import { Getter, Action } from 'vuex-class'
@Component({})
export default class About extends Vue {
  // prop
  @Prop() tableData!: any
  @Prop() tableOption!: any
  @Prop({ default: false }) operation?: boolean
  //Watch
  @Watch('tableData', { deep: true })
  tableDataChange(newVal: any, oldVal: any) {
    this.data.list = newVal
  }
  // data
  data: any = {
    list: [],
  }

  created() {
    //
  }

  activated() {
    //
  }

  mounted() {
    //
  }
  //转字符串
  tostr(val: any) {
    if (val != null) {
      return val.toString()
    } else {
      return val
    }
  }
}
</script>

<style lang="scss">
@import '@/assets/scss/variables';

.table1-wrap {
  width: 100%;
  .el-table th > .cell {
    text-align: center;
  }
}
</style>
