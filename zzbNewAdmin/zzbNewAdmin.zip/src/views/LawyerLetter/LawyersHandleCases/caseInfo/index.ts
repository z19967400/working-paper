import { Component, Vue } from "vue-property-decorator";
import * as Api from "@/api/business.ts";
import caseoverview from "./components/caseoverview.vue";
import distributionLawyer from "./components/distributionLawyer.vue";
import contract from "./components/contract.vue";
import settlement from "./components/settlement.vue";
import handCase from "./components/handCase.vue";
import assessment from "./components/assessment.vue";
@Component({
  components: {
    caseoverview,
    distributionLawyer,
    contract,
    settlement,
    handCase,
    assessment
  }
})
export default class About extends Vue {
  // Getter

  // Action

  // data
  data: any = {
    tabPosition: "left", //侧边栏方位
    height: 500, //侧边栏高度
    case_creditorId: 0, //债权人id
    activeName: "first",
    debtor_number: "",
    case_status_code: "", //案件状态
    caseoverview: {
      //案件概览
      information: [
        //委托信息
        [
          {
            name: "委托编号",
            value: "",
            prop: "debtor_number"
          },
          { name: "案件状态", value: "", prop: "case_status" }
        ],
        [
          { name: "创建人", value: "", prop: "member_name" },
          { name: "创建时间", value: "", prop: "entrust_time" }
        ],
        [
          { name: "债务类别", value: "企业应收款", prop: "collection_scene" }
          // { name: "发布时间", value: "2020-01-02 11:11", prop: "" }
        ]
      ],
      matter: [], //办案事项
      customer: [], //专案客服
      creditor: [
        //债权人
        [
          {
            name: "债权人名称",
            value: "",
            width: "100%",
            prop: "creditor_name"
          },
          {
            name: "认证时间",
            value: "",
            width: "100%",
            prop: "certification_time"
          },
          {
            name: "后台备注",
            value: "",
            width: "300%",
            prop: ""
          }
        ],
        [
          {
            name: "债权人类别",
            value: "",
            width: "100%",
            prop: "creditor_type_name"
          },
          {
            name: "审核状态",
            value: "",
            width: "100%",
            prop: "audit_status_name"
          }
        ],
        [
          {
            name: "电话号码",
            value: "",
            width: "100%",
            prop: "phone_number"
          }
        ]
      ],
      caseInformation: [
        //案件信息
      ],
      //案件辖区
      Jurisdiction: {
        jurisdiction_01_txt: "",
        jurisdiction_02_txt: "",
        jurisdiction_03_txt: "",
        jurisdiction_01_select: "",
        jurisdiction_02_select: "",
        jurisdiction_03_select: ""
      },
      caseData: [
        //案件数据
        [
          { name: "案件评级", value: "C", prop: "" },
          { name: "服务费模式", value: "风险代理", prop: "" },
          { name: "浮动服务费率", value: "20%", prop: "" }
        ],
        [
          { name: "预计胜诉率", value: "80 %", prop: "" },
          { name: "固定服务费报价（人民币元）", value: "998", prop: "" },
          { name: "浮动佣金平台管理费率", value: "20%", prop: "" }
        ],
        [
          { name: "预计回款率", value: "50 %", prop: "" },
          { name: "固定佣金平台管理费", value: "20%", prop: "" },
          { name: "展示律师费（人民币元）", value: "1000", prop: "" }
        ]
      ],
      tabData: [
        //回款记录
        {
          id: "0",
          matter: "一审",
          lawyer: "王律师",
          Collection_currency: "人民币（元）",
          Collection_Amount: "998",
          Collection_method: "转账",
          Collection_time: "2020-02-02 08:54:62",
          ConfirmStatus: "已确认",
          notes: "111"
        }
      ],
      tabOption: [
        //回款记录表格参数
        { label: "回款ID", prop: "id" },
        { label: "办案事项", prop: "matter" },
        { label: "办案事项", prop: "lawyer" },
        { label: "回款币种", prop: "Collection_currency" },
        { label: "回款金额", prop: "Collection_Amount" },
        { label: "回款方式", prop: "Collection_method" },
        { label: "回款日期", prop: "Collection_time" },
        { label: "确认状态", prop: "ConfirmStatus" },
        { label: "后台备注", prop: "notes" }
      ],
      //后台备注
      textarea: ""
    },
    //分配律师
    distributionLawyer: {
      tabData: [],
      tabOption: [
        //回款记录表格参数
        { label: "ID", prop: "id" },
        { label: "律师名称", prop: "lawyer_name" },
        { label: "律师年龄", prop: "lawyer_age" },
        { label: "律师性别", prop: "lawyer_sex" },
        { label: "联系电话", prop: "lawyer_phone_number" },
        { label: "审核状态", prop: "audit_status" },
        { label: "抢单理由", prop: "order_grabbing_reasons" },
        { label: "抢单时间", prop: "order_grabbing_time" },
        { label: "是否分配", prop: "is_allocated" }
      ]
    },
    //案件评估
    assessmentData: {
      businessStatus: "存续", //经营状态
      agreedDate: "", //约定付款日期
      dispute: "", //欠款是否有争议
      availableEvidence: "", //现有证据
      otherEvidence: "", //其他证据
      //基础信息
      informationId: 0,
      information: [
        [
          {
            name: "资产信息数量",
            value: "",
            prop: "asset_information_quantity"
          },
          {
            name: "限制高消费数量",
            value: "",
            prop: "limit_high_consumption_quantity"
          },
          { name: "股权冻结数量", value: "", prop: "equity_freeze_quantity" }
        ],
        [
          {
            name: "失信被执行人数量",
            value: "",
            prop: "dishonesty_executed_person_quantity"
          },
          { name: "被执行人数量", value: "", prop: "executed_person_quantity" },
          { name: "动产抵押数量", value: "", prop: "chattel_mortgage_quantity" }
        ],
        [
          { name: "司法案件数量", value: "", prop: "justizsache_quantity" },
          { name: "终本案件数量", value: "", prop: "final_case_quantity" }
        ]
      ],
      // 胜诉率预估
      case_winrateId: 0,
      case_winrate: [
        {
          factor: "合同/协议/订单",
          weight: "4",
          score: "0",
          prop: "contract_agreement_order"
        },
        { factor: "发票", weight: "1", score: "0", prop: "invoice" },
        {
          factor: "发货及物流凭证（运单等）、收货凭证",
          weight: "4",
          score: "0",
          prop: "receipt_delivery_voucher"
        },
        {
          factor: "对账凭证、付款计划书、付款承诺书",
          weight: "8",
          score: "0",
          prop: "evidence_payment"
        },
        {
          factor: "付款记录、催款通知记录",
          weight: "2",
          score: "0",
          prop: "payment_notice_record"
        },
        {
          factor: "电子证据（邮件、微信、录音录像等）",
          weight: "3",
          score: "0",
          prop: "electronic_evidence"
        },
        {
          factor: "判决、仲裁、公证等司法文书",
          weight: "2",
          score: "0",
          prop: "judicial_document"
        },
        {
          factor: "欠款是否有争议",
          weight: "是-2/否0",
          score: "0",
          prop: "is_debt_dispute"
        },
        {
          factor: "是否过诉讼时效",
          weight: "是-5/否0",
          score: "0",
          prop: "is_limitation_action"
        },
        {
          factor: "其他证据",
          weight: "人工评估调整",
          score: "0",
          prop: "other_evidence"
        }
      ],
      case_winrateData: {
        evaluation_score: 0, //评估得分
        win_rate: 0, //胜诉率
        //评估说明
        assessment_notes:
          "现有的证据仅能够证明小部分欠款事实，案件的胜诉率较低，非常需要补充额外的证据，否则无法确保案"
      },
      //回款率预估
      case_collectionrate: [
        {
          factor: "公司经营状态",
          weight: "4",
          score: 0,
          prop: "business_status"
        },
        {
          factor: "失信被执行人",
          weight: "1",
          score: 0,
          prop: "dishonesty_executed_person"
        },
        { factor: "限制高消费", weight: "1", score: 0, prop: "height_limit" },
        { factor: "终本案件", weight: "1", score: 0, prop: "final_case" },
        {
          factor: "司法案件（被告）≥3起",
          weight: 2,
          score: "0",
          prop: "judicial_cases"
        },
        { factor: "被执行人", weight: "1", score: 0, prop: "executed_person" },
        { factor: "股权冻结", weight: "1", score: 0, prop: "equity_freeze" },
        {
          factor: "动产抵押",
          weight: "1",
          score: 0,
          prop: "​chattel_mortgage"
        },
        {
          factor: "账龄",
          weight: "账龄＜180天 0账龄180-365天 1 账龄366-730天 2 账龄＞730天 3",
          score: 0,
          prop: "account_age"
        },
        {
          factor: "可供保全/执行的车辆/机器/设备/货物",
          weight: "人工评估调整",
          score: 0,
          prop: "bq_fixed_assets"
        },
        {
          factor: "可供保全/执行的应收账款",
          weight: "人工评估调整",
          score: 0,
          prop: "bq_accounts_receivable"
        },
        {
          factor: "可供保全/执行的其他财产",
          weight: "人工评估调整",
          score: 0,
          prop: "bq_other_property"
        }
      ],
      // 回款率信息
      case_collectData: {
        id: 0,
        case_rating: "c", //案件评级
        evaluation_score: 0, //评估得分
        collection_rate: 0, //回款率
        assessment_notes:
          "现有的证据仅能够证明小部分欠款事实，案件的胜诉率较低，非常需要补充额外的证据，否则无法确保案"
      },
      //费用
      estimate: [
        { factor: "诉讼/仲裁费", weight: "" },
        { factor: "财产保全费", weight: "" },
        { factor: "财产保全保险费", weight: "" }
      ],
      //报价
      offerId: 0,
      service_fee_mode: "",
      offer: [
        {
          id: 1,
          serviceFeeMode: "纯固定",
          consultFloatServiceFee: "-",
          FloatServiceFee: "-",
          consultFixedServiceFee: "",
          FixedServiceFee: "",
          lawyerFee: "",
          platformServiceFee: ""
        },
        {
          id: 0,
          serviceFeeMode: "纯浮动",
          consultFloatServiceFee: "",
          FloatServiceFee: "",
          consultFixedServiceFee: "-",
          FixedServiceFee: "-",
          lawyerFee: "",
          platformServiceFee: ""
        },
        {
          id: 2,
          serviceFeeMode: "固定+浮动",
          consultFloatServiceFee: "",
          FloatServiceFee: "",
          consultFixedServiceFee: "",
          FixedServiceFee: "",
          lawyerFee: "",
          platformServiceFee: ""
        }
      ]
    },
    // 签署合约
    contracts: [],
    //案件进展
    caseProgress: {
      court: [], //法院信息
      matters: {} //事项信息
    }
  };
  endTypeOpen: boolean = false;
  endType: string = "Case_state_6";
  created() {
    this.data.height = document.body.offsetHeight - 200;
  }
  activated() {
    //
  }
  mounted() {
    this.init();
  }
  // 初始化函数
  init() {
    let self = this;
    self.data.debtor_number = self.$route.params.number;
    Api.getOfflineCaseInfo(self.data.debtor_number).then((res: any) => {
      self.data.case_status_code = res.data.case_daetails.case_status_code;
      self.data.caseoverview.Jurisdiction = res.data.case_jurisdiction;
      let addressInfo = res.data.case_debtor;
      self.data.caseoverview.Jurisdiction.jurisdiction_01_txt = [
        addressInfo.jurisdiction_01_country,
        addressInfo.jurisdiction_01_province,
        addressInfo.jurisdiction_01_city,
        addressInfo.jurisdiction_01_area
      ];
      self.data.caseoverview.Jurisdiction.jurisdiction_02_txt = [
        addressInfo.jurisdiction_02_country,
        addressInfo.jurisdiction_02_province,
        addressInfo.jurisdiction_02_city,
        addressInfo.jurisdiction_02_area
      ];
      self.data.caseoverview.Jurisdiction.jurisdiction_03_txt = [
        addressInfo.jurisdiction_03_country,
        addressInfo.jurisdiction_03_province,
        addressInfo.jurisdiction_03_city,
        addressInfo.jurisdiction_03_area
      ];
      self.data.assessmentData.availableEvidence =
        res.data.case_debtor.available_evidence;
      self.data.assessmentData.otherEvidence =
        res.data.case_debtor.other_evidence;
      self.data.assessmentData.dispute = res.data.case_debtor.is_dispute;
      self.data.assessmentData.agreedDate =
        res.data.case_debtor.agreed_payment_date;
      let caseType: any = {
        creditor_type_name: res.data.case_creditor.creditor_type_name,
        collection_scene: res.data.case_daetails.collection_scene
      };
      self.caseTypeEdit(caseType);
      //委托信息
      if (res.data.case_daetails != null) {
        self.data.caseoverview.textarea = res.data.case_daetails.back_remarks;
        self.data.caseoverview.information.forEach((item: any) => {
          item.forEach((item2: any) => {
            item2.value = res.data.case_daetails[item2.prop];
          });
        });
      }
      //办案事项
      if (res.data.case_matters_name.length > 0) {
        self.data.caseoverview.matter = res.data.case_matters_name;
      }
      //专属客服
      if (res.data.case_customer_service.length > 0) {
        self.data.caseoverview.customer = res.data.case_customer_service;
      }
      //债权人
      if (res.data.case_creditor != null) {
        self.data.case_creditorId = res.data.case_creditor.id;
        self.data.caseoverview.creditor.forEach((item: any) => {
          item.forEach((item2: any) => {
            item2.value = res.data.case_creditor[item2.prop];
          });
        });
      }
      //案件信息
      if (res.data.case_debtor != null) {
        self.data.caseoverview.caseInformation = self.caseDataMatching(
          res.data.case_debtor
        );
      }
    });
  }
  //标签页切换
  tableSwitch(tab: any, event: any) {
    let self: any = this;
    if (tab.name == "second") {
      self.getCaseAssment();
    }
    if (tab.name == "Three") {
      self.getContracts();
    }
    if (tab.name == "Four") {
      self.getCaseLawyer();
    }
    if (tab.name == "five") {
      this.getCaseProcess();
    }
  }
  //获取案件可分配律师
  getCaseLawyer() {
    let parmas: any = {
      page: 1,
      limit: 20,
      debtor_number: this.$route.params.number
    };
    Api.getCaseLawyer(parmas).then((res: any) => {
      res.list.forEach((item: any) => {
        item.is_allocated =
          item.is_allocated == 0
            ? "待分配"
            : item.is_allocated == 1
            ? "已分配"
            : "未分配";
      });
      this.data.distributionLawyer.tabData = res.list;
    });
  }
  //案件信息赋值匹配
  caseDataMatching(res: any) {
    let arr: any = [];
    const matching: any = {
      debtor_number: "债务人编号",
      debtor_name: "债务人",
      id_card_no: "债务人身份证号码",
      phone_number: "债务人联系方式",
      address_txt: "债务人有效联系地址",
      contact_person: "负责人姓名",
      arrears_principal: "欠款本金",
      currency_id: "欠款币种",
      arrears_interest: "违约金/利息/滞纳金（元）",
      insurer_name: "被保险人",
      agreed_payment_date: "约定付款日期",
      guarantee_type: "担保类型",
      lending_rate: "贷款利率（年息%）",
      property_clues: "债务人财产线索",
      property_clues_bc: "债务人财产线索补充说明",
      confirmation_method: "债务人对欠款的确认方式",
      confirmation_date: "确认日期",
      available_evidence: "现有证据",
      other_evidence: "其他证据",
      is_dispute: "欠款是否存在争议",
      entrusted_matters: "委托事项",
      other_entrustment: "其他委托",
      creditor_name: "债权人联系人姓名",
      creditor_telphone: "债权人联系人电话",
      creditor_email: "债权人联系人邮箱",
      d_remarks: "备注"
    };
    Object.keys(res).forEach((key: string) => {
      if (
        res[key] != null &&
        matching[key] != undefined &&
        key != "d_remarks"
      ) {
        let item: any = {
          name: matching[key],
          value: res[key] || "/"
        };
        arr.push(item);
      }
    });
    let item2: any = {
      name: "备注",
      value: res["d_remarks"] || "/"
    };
    arr.push(item2);
    return arr;
  }
  //获取案件评估
  getCaseAssment() {
    let number: string = this.$route.params.number;
    Api.getCaseAssment(number).then((res: any) => {
      if (res.data.case_collectionrate != null) {
        this.data.assessmentData.businessStatus =
          res.data.case_collectionrate.business_status;
      }
      //评估基本信用信息
      if (res.data.case_credit != null) {
        this.data.assessmentData.informationId = res.data.case_credit.id;
        this.data.assessmentData.third_assessment_report =
          res.data.case_credit.third_assessment_report;
        this.data.assessmentData.estimate[0].weight =
          res.data.case_credit.litigation_arbitration_fee;
        this.data.assessmentData.estimate[1].weight =
          res.data.case_credit.property_preservation_fee;
        this.data.assessmentData.estimate[2].weight =
          res.data.case_credit.property_preservation_insurance;
        this.data.assessmentData.information.forEach((item: any) => {
          item.forEach((item2: any) => {
            item2.value = res.data.case_credit[item2.prop];
          });
        });
      }
      //胜诉率预估
      if (res.data.case_winrate != null) {
        this.data.assessmentData.case_winrateId = res.data.case_winrate.id;
        this.data.assessmentData.case_winrateData.win_rate =
          res.data.case_winrate.win_rate;
        this.data.assessmentData.case_winrateData.assessment_notes =
          res.data.case_winrate.assessment_notes;
        this.data.assessmentData.case_winrateData.evaluation_score =
          res.data.case_winrate.evaluation_score;
        this.data.assessmentData.case_winrate.forEach((item: any) => {
          item.score = res.data.case_winrate[item.prop];
        });
      }
      //回款率预估
      if (res.data.case_collectionrate != null) {
        this.data.assessmentData.case_collectData.id =
          res.data.case_collectionrate.id;
        this.data.assessmentData.case_collectData.case_rating =
          res.data.case_collectionrate.case_rating;
        this.data.assessmentData.case_collectData.evaluation_score =
          res.data.case_collectionrate.evaluation_score;
        this.data.assessmentData.case_collectData.collection_rate =
          res.data.case_collectionrate.collection_rate;
        this.data.assessmentData.case_collectData.assessment_notes =
          res.data.case_collectionrate.assessment_notes;
        this.data.assessmentData.case_collectionrate.forEach((item: any) => {
          item.score = res.data.case_collectionrate[item.prop];
        });
      }
      //报价 offer
      if (res.data.case_detail != null) {
        this.data.assessmentData.service_fee_mode =
          res.data.case_detail.service_fee_mode;
        this.data.assessmentData.offerId = res.data.case_detail.id;
        this.data.assessmentData.offer[1].consultFloatServiceFee =
          res.data.case_detail.float_service_rate_ck;
        this.data.assessmentData.offer[1].FloatServiceFee =
          res.data.case_detail.float_service_rate;
        this.data.assessmentData.offer[1].lawyerFee =
          res.data.case_detail.exhibition_lawyer_fee_f;
        this.data.assessmentData.offer[1].platformServiceFee =
          res.data.case_detail.commission_manage_rate_cf;
        this.data.assessmentData.offer[0].consultFixedServiceFee =
          res.data.case_detail.fixed_service_fee_ck;
        this.data.assessmentData.offer[0].FixedServiceFee =
          res.data.case_detail.fixed_service_fee;
        this.data.assessmentData.offer[0].lawyerFee =
          res.data.case_detail.exhibition_lawyer_fee_g;
        this.data.assessmentData.offer[0].platformServiceFee =
          res.data.case_detail.commission_manage_rate_cg;
        this.data.assessmentData.offer[2].consultFloatServiceFee =
          res.data.case_detail.gf_float_service_rate_ck;
        this.data.assessmentData.offer[2].FloatServiceFee =
          res.data.case_detail.gf_float_service_rate;
        this.data.assessmentData.offer[2].consultFixedServiceFee =
          res.data.case_detail.gf_fixed_service_fee_ck;
        this.data.assessmentData.offer[2].FixedServiceFee =
          res.data.case_detail.gf_fixed_service_fee;
        this.data.assessmentData.offer[2].lawyerFee =
          res.data.case_detail.exhibition_lawyer_fee_gf;
        this.data.assessmentData.offer[2].platformServiceFee =
          res.data.case_detail.commission_manage_rate_gf_f +
          "|" +
          res.data.case_detail.commission_manage_rate_gf_g;
      }
    });
  }
  //案件发布
  caseRelease() {
    let self: any = this;
    self
      .$confirm("您确定发布案件吗?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
      .then(() => {
        Api.caseRelease(self.data.debtor_number).then((res: any) => {
          if (res.state) {
            self.$message.success(res.msg);
            self.init();
          } else {
            self.$message.warning(res.msg);
          }
        });
      })
      .catch(() => {
        self.$message({
          type: "info",
          message: "已取消发布"
        });
      });
  }
  //案件撤销
  caseRevoke() {
    let parmas: any = {
      debtor_number: this.data.debtor_number,
      case_status: 3
    };
    let self: any = this;
    self
      .$confirm("您确定撤销案件吗?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
      .then(() => {
        Api.updataCaseStatus(parmas).then((res: any) => {
          if (res.state) {
            this.$message.success(res.msg);
            this.init();
          } else {
            this.$message.warning(res.msg);
          }
        });
      })
      .catch(() => {
        self.$message({
          type: "info",
          message: "已取消撤销"
        });
      });
  }
  //无律师接案
  noLawyerRelease() {
    let parmas: any = {
      debtor_number: this.data.debtor_number,
      case_status: 7
    };
    let self: any = this;
    self
      .$confirm("您确定无律师接案吗?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
      .then(() => {
        Api.updataCaseStatus(parmas).then((res: any) => {
          if (res.state) {
            this.$message.success(res.msg);
            this.init();
          } else {
            this.$message.warning(res.msg);
          }
        });
      })
      .catch(() => {
        self.$message({
          type: "info",
          message: "已取消无律师接案"
        });
      });
  }
  //结案
  Release() {
    let parmas: any = {
      debtor_number: this.data.debtor_number,
      case_status: this.endType
    };
    Api.updataCaseStatus(parmas).then((res: any) => {
      if (res.state) {
        this.$message.success(res.msg);
        this.init();
      } else {
        this.$message.warning(res.msg);
      }
    });
  }
  //获取合同列表
  getContracts() {
    Api.getContracts(this.data.debtor_number).then((res: any) => {
      this.data.contracts = res.data;
      this.data.contracts["matter"] = this.data.caseoverview.matter;
      this.data.contracts["customer"] = this.data.caseoverview.customer;
      this.data.contracts.forEach((item: any) => {
        item.contract_type =
          item.contract_type == 0
            ? "委托合同"
            : item.contract_type == 1
            ? "律师代理合同"
            : "律师解约合同";
        item.contract_sign_method =
          item.contract_sign_method == 0 ? "线上签署" : "线下签署";
        item.sign_status =
          item.sign_status == 0
            ? "待签署"
            : item.sign_status == -1
            ? "合同准备中"
            : "已签署";
      });
    });
  }
  //获取案件进程
  getCaseProcess() {
    this.getCaseCourt();
    this.getCaseMatter();
  }
  //获取案件法院信息
  getCaseCourt() {
    let self: any = this;
    Api.getCaseCourtInfo(self.data.debtor_number).then((res: any) => {
      self.data.caseProgress.court = res.data;
    });
  }
  //获取案件进展
  getCaseMatter() {
    let self: any = this;
    Api.getCaseMatter(self.data.debtor_number).then((res: any) => {
      self.data.caseProgress.matters = res.data;
    });
  }
  //根据案件类型和债权人类别来区分评估表单
  caseTypeEdit(data: any) {
    if (data.collection_scene != "企业应收款") {
      this.data.assessmentData.case_winrate = [
        {
          factor: "借款合同、借条、借据、欠条、还款承诺书",
          weight: "5",
          score: "0",
          prop: "evidence_borrowing"
        },
        { factor: "发票", weight: "1", score: "0", prop: "invoice" },
        {
          factor: "转账记录",
          weight: "5",
          score: "0",
          prop: "transfer_records"
        },
        {
          factor: "还款记录、催款通知记录",
          weight: "2",
          score: "0",
          prop: "repayment_notice_record"
        },
        {
          factor: "电子证据（邮件、微信、录音录像等）",
          weight: "3",
          score: "0",
          prop: "electronic_evidence"
        },
        {
          factor: "欠款是否有争议",
          weight: "是-2/否0",
          score: "0",
          prop: "is_debt_dispute"
        },
        {
          factor: "是否过诉讼时效",
          weight: "是-5/否0",
          score: "0",
          prop: "is_limitation_action"
        },
        {
          factor: "其他证据",
          weight: "人工评估调整",
          score: "0",
          prop: "other_evidence"
        }
      ];
    }
    if (data.creditor_type_name == "个人") {
      this.data.assessmentData.case_collectionrate = [
        {
          factor: "失踪、死亡",
          weight: "10",
          score: 0,
          prop: "missing_dead"
        },
        {
          factor: "失信被执行人",
          weight: "10",
          score: 0,
          prop: "dishonesty_executed_person"
        },
        { factor: "限制高消费", weight: "10", score: 0, prop: "height_limit" },
        { factor: "终本案件", weight: "10", score: 0, prop: "final_case" },
        {
          factor: "司法案件（被告）",
          weight: 2,
          score: "0",
          prop: "judicial_cases"
        },
        { factor: "被执行人", weight: "3", score: 0, prop: "executed_person" },
        {
          factor: "账龄",
          weight: "账龄＜180天 0账龄180-365天 1 账龄366-730天 2 账龄＞730天 3",
          score: 0,
          prop: "account_age"
        },
        {
          factor: "可供保全/执行的车辆/机器/设备/货物",
          weight: "人工评估调整",
          score: 0,
          prop: "bq_fixed_assets"
        },
        {
          factor: "可供保全/执行的应收账款",
          weight: "人工评估调整",
          score: 0,
          prop: "bq_accounts_receivable"
        },
        {
          factor: "可供保全/执行的其他财产",
          weight: "人工评估调整",
          score: 0,
          prop: "bq_other_property"
        }
      ];
    }
  }
  //发送评估用户确认
  sendAssessment() {
    let parmas: any = {
      debtor_number: this.data.debtor_number,
      case_status: 2
    };
    let self: any = this;
    self
      .$confirm("是否确认发送报价至用户?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning"
      })
      .then(() => {
        Api.updataCaseStatus(parmas).then((res: any) => {
          if (res.state) {
            this.$message.success(res.msg);
            this.init();
          } else {
            this.$message.warning(res.msg);
          }
        });
      })
      .catch(() => {
        self.$message({
          type: "info",
          message: "已取消发送"
        });
      });
  }
}
