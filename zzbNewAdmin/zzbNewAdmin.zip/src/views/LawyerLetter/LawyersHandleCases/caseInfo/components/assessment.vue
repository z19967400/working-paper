<template>
  <div :style="{ height: data.height + 'px' }" class="assessment-wrap">
    <div class="section">
      <span style="margin-top:0">
        <span class="title">债务人基本信用信息</span>
        <span @click="informationEdit()" class="edit">{{ data.informationType?"保存":"编辑"}}</span></span>
      <el-divider></el-divider>
      <div class="box">
        <div v-for="(item, index) in data.assessment.information" :key="index" class="text">
          <p v-for="(item2, index2) in item" :key="index2">
            <span>{{ item2.name }}</span>
            <span v-if="!data.informationType">{{ item2.value }}</span>
            <el-col v-else :span="8">
              <el-input size="small" v-model="item2.value" placeholder="请输入内容"></el-input>
            </el-col>
          </p>
        </div>
      </div>
    </div>
    <!-- 胜诉率预估 -->
    <div class="section">
      <span style="margin-top:0;">
        <span class="title">胜诉率预估</span>
        <span @click="data.winratType = !data.winratType" class="edit">{{
          data.winratType ? "取消" : "编辑"
        }}</span></span>
      <el-divider></el-divider>
      <div class="content">
        <el-row>
          <span class="laber">约定付款日期</span>
          <span class="value"> {{data.assessment.agreedDate}}</span>
        </el-row>
        <el-row>
          <span class="laber">欠款是否有争议</span>
          <span class="value"> {{data.assessment.businessStatus == 0?'否':'是'}}</span>
        </el-row>
        <el-row>
          <span class="laber">现有证据</span>
          <span class="value">
            {{data.assessment.availableEvidence}}
          </span>
        </el-row>
        <el-row>
          <span class="laber">其他证据</span>
          <span class="value"> {{data.assessment.otherEvidence}} </span>
        </el-row>
        <el-table :data="data.assessment.case_winrate" border :cell-style="{ 'text-align': ' center' }" :header-cell-style="{ 'text-align': 'center' }">
          <el-table-column prop="factor" label="评分因素" width="480px">
          </el-table-column>
          <el-table-column prop="weight" label="权重" width="120px">
          </el-table-column>
          <el-table-column prop="score" label="得分" width="80px">
            <template slot-scope="scope">
              <span v-if="!data.winratType">{{ scope.row.score }}</span>
              <el-input v-else size="small" v-model="scope.row.score" placeholder="请输入内容"></el-input>
            </template>
          </el-table-column>
        </el-table>
        <el-button v-if="!data.winratType" style="margin:20px 0;" size="small" type="primary" @click="winrateCalct">重新计算</el-button>
        <el-row style="line-height: 32px;margin-top:20px;">
          <el-col :span="8">
            <el-row>
              <el-col :span="6">
                <span class="laber">评估得分</span>
              </el-col>
              <el-col v-if="!data.winratType" :span="4">
                <span class="value">{{data.assessment.case_winrateData.evaluation_score}}</span>
              </el-col>
              <el-col v-else :span="6">
                <el-input size="small" v-model="data.assessment.case_winrateData.evaluation_score" placeholder="请输入"></el-input>
              </el-col>
            </el-row>
          </el-col>
          <el-col :span="8">
            <el-row>
              <el-col :span="6">
                <span class="laber">胜诉率</span>
              </el-col>
              <el-col :span="6" v-if="!data.winratType">
                <span class="value red bold">{{ data.assessment.case_winrateData.win_rate }}</span>
              </el-col>
              <el-col :span="6" v-else>
                <el-input size="small" v-model="data.assessment.case_winrateData.win_rate" placeholder="请输入"></el-input>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="2">
            <span class="laber">评估说明</span>
          </el-col>
          <el-col :span="11">
            <span v-if="!data.winratType" class="value">
              {{ data.assessment.case_winrateData.assessment_notes }}
            </span>
            <el-input v-else size="small" type="textarea" v-model="data.assessment.case_winrateData.assessment_notes" placeholder="请输入内容"></el-input>
          </el-col>
        </el-row>
        <el-button v-if="data.winratType" style="margin:20px 0;" size="small" type="primary" @click="winratEdit">保存</el-button>
      </div>
    </div>
    <!-- 回款率预估 -->
    <div class="section">
      <span style="margin-top:0;">
        <span class="title">回款率预估</span>
        <span @click="data.collectionrateType = !data.collectionrateType" class="edit">
          {{data.collectionrateType ? "取消" : "编辑"}}
        </span>
      </span>
      <el-divider></el-divider>
      <div class="content">
        <el-row>
          <span class="laber">约定付款日期</span>
          <span class="value"> {{data.assessment.agreedDate}}</span>
        </el-row>
        <el-row>
          <span class="laber">欠款是否有争议</span>
          <span class="value"> {{data.assessment.businessStatus == 0?'否':'是'}}</span>
        </el-row>
        <el-row>
          <span class="laber">现有证据</span>
          <span class="value">
            {{data.assessment.availableEvidence}}
          </span>
        </el-row>
        <el-row>
          <span class="laber">其他证据</span>
          <span class="value"> {{data.assessment.otherEvidence}} </span>
        </el-row>
        <el-table :data="data.assessment.case_collectionrate" border :cell-style="{ 'text-align': ' center' }" :header-cell-style="{ 'text-align': 'center' }">
          <el-table-column prop="factor" label="评分因素" width="480px">
          </el-table-column>
          <el-table-column prop="weight" label="权重" width="220px">
          </el-table-column>
          <el-table-column label="得分" width="80px">
            <template slot-scope="scope">
              <span v-if="!data.collectionrateType">{{ scope.row.score }}</span>
              <el-input v-else size="small" v-model="scope.row.score"></el-input>
            </template>
          </el-table-column>
        </el-table>
        <el-button v-if="!data.collectionrateType" @click="calculationCollection" style="margin:20px 0;" size="small" type="primary">重新计算</el-button>
        <el-row style="line-height: 32px;margin-top:20px;">
          <el-col :span="2">
            <span class="laber">案件评级</span>
          </el-col>
          <el-col v-if="!data.collectionrateType" :span="4">
            <span class="value red bold">{{ data.assessment.case_collectData.case_rating }}</span>
          </el-col>
          <el-col v-else :span="1">
            <el-input size="small" v-model="data.assessment.case_collectData.case_rating"></el-input>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-row style="line-height: 32px;">
              <el-col :span="6">
                <span class="laber">评估得分</span>
              </el-col>
              <el-col v-if="!data.collectionrateType" :span="4">
                <span class="value red bold">{{data.assessment.case_collectData.evaluation_score}}</span>
              </el-col>
              <el-col v-else :span="4">
                <el-input size="small" v-model="data.assessment.case_collectData.evaluation_score"></el-input>
              </el-col>
            </el-row>
          </el-col>
          <el-col :span="8">
            <el-row style="line-height: 32px;">
              <el-col :span="6">
                <span class="laber">回款率</span>
              </el-col>
              <el-col v-if="!data.collectionrateType" :span="4">
                <span class="value red bold">{{data.assessment.case_collectData.collection_rate}}</span>
              </el-col>
              <el-col v-else :span="4">
                <el-input size="small" v-model="data.assessment.case_collectData.collection_rate"></el-input>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="2">
            <span class="laber">评估说明</span>
          </el-col>
          <el-col :span="11">
            <span v-if="!data.collectionrateType" class="value">{{data.assessment.case_collectData.assessment_notes}}</span>
            <el-input v-else size="small" type="textarea" v-model="data.assessment.case_collectData.assessment_notes" placeholder="请输入内容"></el-input>
          </el-col>
        </el-row>
        <el-button v-if="data.collectionrateType" @click="collectionrateEdit" style="margin:20px 0;" size="small" type="primary">保存</el-button>
      </div>
    </div>
    <!-- 诉讼、仲裁、保全费用预估 -->
    <div class="section">
      <span style="margin-top:0;">
        <span class="title">诉讼、仲裁、保全费用预估</span>
        查询途径：<a href="https://www.cnado.com" target="_blank">https://www.cnado.com</a>
        <span @click="data.costType = !data.costType" class="edit">{{data.costType?"取消":"编辑"}}</span>
      </span>
      <el-divider></el-divider>
      <div class="content">
        <el-table :data="data.assessment.estimate" border style="width: 300px" :cell-style="{ 'text-align': ' center' }" :header-cell-style="{ 'text-align': 'center' }">
          <el-table-column prop="factor" label="费用类别" width="150px">
          </el-table-column>
          <el-table-column label="金额" width="150px">
            <template slot-scope="scope">
              <span v-if="!data.costType">{{ scope.row.weight }}</span>
              <el-input v-else size="small" v-model="scope.row.weight"></el-input>
            </template>
          </el-table-column>
        </el-table>
        <el-button v-if="data.costType" @click="costEdit" style="margin:20px 0;" size="small" type="primary">保存</el-button>
      </div>
    </div>
    <div class="section">
      <span style="margin-top:0;">
        <span class="title">平台报价方案</span>
        <span @click="data.offerType = !data.offerType" class="edit">{{data.offerType?"取消":"编辑"}}</span>
      </span>
      <el-divider></el-divider>
      <div class="content">
        <el-button style="margin:20px 0;" v-show="!data.offerType" size="small" @click="calculation" type="primary">重新计算</el-button>
        <el-table :data="data.assessment.offer" border :cell-style="{ 'text-align': ' center' }" :header-cell-style="{ 'text-align': 'center' }">
          <el-table-column prop="serviceFeeMode" label="服务费模式"> </el-table-column>
          <el-table-column prop="consultFixedServiceFee" label="参考固定服务费(元)">
            <!-- v-if="!data.offerType || scope.row.id == 0" -->
            <template slot-scope="scope">
              <span>{{ scope.row.consultFixedServiceFee }}</span>
              <!-- <el-input v-if="data.offerType && scope.row.id != 0" size="small" v-model="scope.row.consultFixedServiceFee"></el-input> -->
            </template>
          </el-table-column>
          <el-table-column prop="FixedServiceFee" label="最终固定服务费(元)">
            <template slot-scope="scope">
              <span v-if="!data.offerType || scope.row.id == 0">{{ scope.row.FixedServiceFee }}</span>
              <el-input v-if="data.offerType && scope.row.id != 0" size="small" v-model="scope.row.FixedServiceFee"></el-input>
            </template>
          </el-table-column>
          <el-table-column prop="consultFloatServiceFee" label="参考浮动服务费(%)">
            <template slot-scope="scope">
              <span>{{ scope.row.consultFloatServiceFee }}</span>
              <!-- <el-input v-if="data.offerType && scope.row.id != 1" size="small" v-model="scope.row.consultFloatServiceFee"></el-input> -->
            </template>
          </el-table-column>
          <el-table-column prop="FloatServiceFee" label="最终浮动服务费(%)">
            <template slot-scope="scope">
              <span v-if="!data.offerType || scope.row.id == 1">{{ scope.row.FloatServiceFee }}</span>
              <el-input v-if="data.offerType && scope.row.id != 1" size="small" v-model="scope.row.FloatServiceFee"></el-input>
            </template>
          </el-table-column>

          <el-table-column prop="lawyerFee" label="预计律师费(元)">
            <template slot-scope="scope">
              <span v-if="!data.offerType">{{ scope.row.lawyerFee }}</span>
              <el-input v-else size="small" v-model="scope.row.lawyerFee"></el-input>
            </template>
          </el-table-column>
          <el-table-column prop="platformServiceFee" label="平台管理费比例(%)">
            <template slot-scope="scope">
              <span v-if="!data.offerType">{{ scope.row.platformServiceFee }}</span>
              <el-input v-if="data.offerType && scope.row.id != 2" size="small" v-model="scope.row.platformServiceFee"></el-input>
              <el-row v-if="data.offerType && scope.row.id == 2">
                <el-col :span="10">
                  <el-input size="small" v-model="data.commission_manage_rate_gf_f"></el-input>
                </el-col>
                <el-col :span="4">
                  +
                </el-col>
                <el-col :span="10">
                  <el-input size="small" v-model="data.commission_manage_rate_gf_g"></el-input>
                </el-col>
              </el-row>
            </template>
          </el-table-column>
          <el-table-column label="选择">
            <template slot-scope="scope">
              <el-radio v-model="data.active" @change="choice" :label="scope.row.id">选中</el-radio>
            </template>
          </el-table-column>
        </el-table>
        <el-button style="margin:20px 0;" v-show="data.offerType" size="small" @click="upDataOffer" type="primary">保存</el-button>
      </div>
    </div>
    <div class="section">
      <span style="margin-top:0;">
        <span class="title">发送报告</span>
      </span>
      <el-divider></el-divider>
      <div class="content">
        <el-row>
          <el-col :span="3"><span class="laber">第三方评估报告</span></el-col>
          <el-col :span="6">
            <span v-if="data.third_assessment_report == null" class="value"><a style="cursor: pointer;color:#67C23A;" @click="preview">当前案件编号_{{data.debtor_number}}_评估报告.pdf</a></span>
            <span v-else class="value"><a style="cursor: pointer;color:#67C23A;" @click="preview">第三方评估报告</a></span>
          </el-col>
          <el-col :span="4">
            <el-upload class="upload-demo" :action="burl + '/Upload/UploadImage?type=6'" :on-success="handleSuccess">
              <el-button size="small" type="primary">重新上传</el-button>
              <!-- <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div> -->
            </el-upload>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="3"> <span class="laber">邮件发送报告</span> </el-col>
          <el-col :span="6">
            <el-select size="small" v-model="data.value" placeholder="请选择">
              <el-option v-for="item in data.options" :key="item.value" :label="item.name+item.email" :value="item.id+','+item.email">
              </el-option>
            </el-select>
          </el-col>
          <el-col :span="4">
            <el-button size="small" @click="sand" type="primary">发送报价至客服</el-button>
          </el-col>
        </el-row>
        <!-- <el-row>
          <el-col :span="3">
            <span class="laber">短信通知</span>
          </el-col>
          <el-col :span="6">
            <el-input size="small" style="width:72%;" v-model="data.input" placeholder="请输入用户手机号"></el-input>
          </el-col>
          <el-col :span="4">
            <el-button size="small" type="primary">发送</el-button>
          </el-col>
        </el-row> -->
        <el-row>
          <el-button size="small" @click="preview" type="primary">预览报告</el-button>
          <el-button size="small" v-show="Case_state == 'Case_state_0'" @click="generate" type="primary">生成报告</el-button>
        </el-row>
      </div>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator'
import { Getter, Action } from 'vuex-class'
import comTab1 from './table1.vue'
import * as Api from '../../../../../api/business'
import { api } from '../../../../../../../zzbPc/src/assets/js/api'
// import { api } from "../../../../../../../zzbPc/src/assets/js/api";
import { baseURL } from '../../../../../utils/request'
@Component({
  components: {
    comTab1,
  },
})
export default class About extends Vue {
  // prop
  @Prop({ required: false, default: '' }) assessment!: any
  @Prop() height!: number
  @Prop() debtor_number!: string
  @Prop() Case_state!: string
  //Watch
  @Watch('assessment', { deep: true, immediate: true })
  assessmentChangeVal(newVal: any, oldVal: any) {
    this.data.assessment = newVal
    let arr = newVal.offer[2].platformServiceFee.split('|')
    this.data.commission_manage_rate_gf_f = arr[0]
    this.data.commission_manage_rate_gf_g = arr[1]
    this.data.third_assessment_report = newVal.third_assessment_report
    if (newVal.service_fee_mode == 'Case_Service_Fee_Mode_3') {
      this.data.active = 2
    }
    if (newVal.service_fee_mode == 'Case_Service_Fee_Mode_2') {
      this.data.active = 1
    }
    if (newVal.service_fee_mode == 'Case_Service_Fee_Mode_1') {
      this.data.active = 0
    }
  }
  @Watch('height', { deep: true, immediate: true })
  heightChangeVal(newVal: number, oldVal: number) {
    this.data.height = newVal
  }
  @Watch('debtor_number', { deep: true, immediate: true })
  debtor_numberChangeVal(newVal: string, oldVal: string) {
    this.data.debtor_number = newVal
  }
  // data
  data: any = {
    assessment: {}, //父组件传过来的数据
    height: 0, //侧边栏高度
    active: '', //多选选中
    debtor_number: '',
    options: [
      {
        //发送邮箱
        value: '选项1',
        label: '黄金糕',
      },
      {
        value: '选项2',
        label: '双皮奶',
      },
      {
        value: '选项3',
        label: '蚵仔煎',
      },
      {
        value: '选项4',
        label: '龙须面',
      },
      {
        value: '选项5',
        label: '北京烤鸭',
      },
    ],
    value: '', //发送邮件的id和地址
    input: '',
    commission_manage_rate_gf_f: 0, //平台管理费比例 固定+浮动 浮动
    commission_manage_rate_gf_g: 0, //平台管理费比例 固定+浮动 固定
    informationType: false, //基本信息编辑
    winratType: false, //胜诉率内容编辑
    collectionrateType: false, //回款率预估
    costType: false, //费用预估
    offerType: false, //报价
    third_assessment_report: '', //第三方评估报告
  }
  burl: string = ''
  created() {
    //
  }

  activated() {
    //
  }

  mounted() {
    this.getAllAdmin()
    this.burl = baseURL
  }

  //回款记录删除
  collectionDel(data: any) {
    // eslint-disable-next-line no-console
    console.log(data)
  }
  //进本信用信息编辑修改
  informationEdit() {
    if (this.data.informationType) {
      let parmas: any = {
        id: this.data.assessment.informationId,
        debtor_number: this.data.debtor_number,
      }
      this.data.assessment.information.forEach((item: any) => {
        item.forEach((item2: any) => {
          parmas[item2.prop] = item2.value
        })
      })
      let self: any = this
      self
        .$confirm('您确定保存吗?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
        })
        .then(() => {
          Api.upDataDebtorCredit(parmas).then((res: any) => {
            if (res.state) {
              self.$message.success(res.msg)
              self.data.informationType = !self.data.informationType
            } else {
              self.$message.warning(res.msg)
            }
          })
        })
        .catch(() => {
          self.$message({
            type: 'info',
            message: '已取消保存',
          })
        })
    } else {
      // eslint-disable-next-line no-console
      console.log('编辑')
      this.data.informationType = !this.data.informationType
    }
  }
  //胜诉率编辑
  winratEdit() {
    let parmas: any = this.data.assessment.case_winrateData
    parmas['id'] = this.data.assessment.case_winrateId
    parmas['debtor_number'] = this.data.debtor_number
    this.data.assessment.case_winrate.forEach((item: any) => {
      parmas[item.prop] = item.score
    })
    let self: any = this
    self
      .$confirm('您确定保存吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
      .then(() => {
        Api.upDataWinrate(parmas).then((res: any) => {
          if (res.state) {
            self.$message.success(res.msg)
          } else {
            self.$message.warning(res.msg)
          }
        })
        self.data.winratType = !self.data.winratType
      })
      .catch(() => {
        self.$message({
          type: 'info',
          message: '已取消保存',
        })
      })
  }
  //胜诉率重新计算 calculationWinrates
  winrateCalct() {
    let self: any = this
    self
      .$confirm('您确定重新计算吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
      .then(() => {
        Api.calculationWinrates(self.data.debtor_number).then((res: any) => {
          if (res.state) {
            self.$message.success(res.msg)
            setTimeout(() => {
              self.data.assessment.case_winrateData.assessment_notes = res.data.assessment_notes
              self.data.assessment.case_winrateData.evaluation_score = res.data.evaluation_score
              self.data.assessment.case_winrateData.win_rate = res.data.win_rate
            }, 1000)
          } else {
            self.$message.warning(res.msg)
          }
        })
      })
      .catch(() => {
        self.$message({
          type: 'info',
          message: '已取消重新计算',
        })
      })
  }
  //回款率信息更新
  collectionrateEdit() {
    let parmas: any = {
      id: this.data.assessment.case_collectData.id,
      debtor_number: this.data.debtor_number,
      case_rating: this.data.assessment.case_collectData.case_rating,
      evaluation_score: this.data.assessment.case_collectData.evaluation_score,
      collection_rate: this.data.assessment.case_collectData.collection_rate,
      assessment_notes: this.data.assessment.case_collectData.assessment_notes,
    }
    this.data.assessment.case_collectionrate.forEach((item: any) => {
      parmas[item.prop] = item.score
    })
    let self: any = this
    self
      .$confirm('您确定保存吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
      .then(() => {
        Api.upDataCollectionRate(parmas).then((res: any) => {
          if (res.state) {
            self.$message.success(res.msg)
          } else {
            self.$message.warning(res.msg)
          }
        })
        self.data.collectionrateType = !self.data.collectionrateType
      })
      .catch(() => {
        self.$message({
          type: 'info',
          message: '已取消保存',
        })
      })
  }
  //计算回款率
  calculationCollection() {
    let self: any = this
    self
      .$confirm('您确定重新计算吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
      .then(() => {
        Api.calculationCollectionRate(self.data.debtor_number).then((res: any) => {
          if (res.state) {
            self.$message.success(res.msg)
            setTimeout(() => {
              Object.keys(self.data.assessment.case_collectData).forEach((key: string) => {
                if (res.data[key] != undefined) {
                  self.data.assessment.case_collectData[key] = res.data[key]
                }
              })
            }, 1000)
          } else {
            self.$message.warning(res.msg)
          }
        })
      })
      .catch(() => {
        self.$message({
          type: 'info',
          message: '已取消重新计算',
        })
      })
  }
  //计算报价
  calculation() {
    Api.calcilationOffer(this.data.debtor_number).then((res: any) => {
      this.data.assessment.offer[0].consultFloatServiceFee = res.data.float_service_rate_ck
      this.data.assessment.offer[0].FloatServiceFee = res.data.float_service_rate
      this.data.assessment.offer[0].lawyerFee = res.data.exhibition_lawyer_fee_f
      this.data.assessment.offer[0].platformServiceFee = res.data.commission_manage_rate_cf
      this.data.assessment.offer[1].consultFixedServiceFee = res.data.fixed_service_fee_ck
      this.data.assessment.offer[1].FixedServiceFee = res.data.fixed_service_fee
      this.data.assessment.offer[1].lawyerFee = res.data.exhibition_lawyer_fee_g
      this.data.assessment.offer[1].platformServiceFee = res.data.commission_manage_rate_cg
      this.data.assessment.offer[2].consultFloatServiceFee = res.data.gf_float_service_rate_ck
      this.data.assessment.offer[2].FloatServiceFee = res.data.gf_float_service_rate
      this.data.assessment.offer[2].consultFixedServiceFee = res.data.gf_fixed_service_fee_ck
      this.data.assessment.offer[2].FixedServiceFee = res.data.gf_fixed_service_fee
      this.data.assessment.offer[2].lawyerFee = res.data.exhibition_lawyer_fee_gf
      this.data.assessment.offer[2].platformServiceFee =
        res.data.commission_manage_rate_gf_f + '|' + res.data.commission_manage_rate_gf_g
    })
  }
  //费用预估
  costEdit() {
    let parmas: any = {
      debtor_number: this.data.debtor_number,
      litigation_arbitration_fee: this.data.assessment.estimate[0].weight,
      property_preservation_fee: this.data.assessment.estimate[1].weight,
      property_preservation_insurance: this.data.assessment.estimate[2].weight,
    }
    Api.costEdit(parmas).then((res: any) => {
      if (res.state) {
        this.$message.success(res.msg)
        this.data.costType = !this.data.costType
      } else {
        this.$message.warning(res.msg)
      }
    })
  }
  //报价信息修改
  upDataOffer() {
    let parmas: any = {
      debtor_number: this.data.debtor_number,
      float_service_rate_ck: this.data.assessment.offer[0].consultFloatServiceFee, //纯浮动服务费率(%)_参考
      float_service_rate: this.data.assessment.offer[0].FloatServiceFee, // 纯浮动服务费率(%)
      exhibition_lawyer_fee_f: this.data.assessment.offer[0].lawyerFee,
      commission_manage_rate_cf: this.data.assessment.offer[0].platformServiceFee,
      fixed_service_fee_ck: this.data.assessment.offer[1].consultFixedServiceFee,
      fixed_service_fee: this.data.assessment.offer[1].FixedServiceFee,
      exhibition_lawyer_fee_g: this.data.assessment.offer[1].lawyerFee,
      commission_manage_rate_cg: this.data.assessment.offer[1].platformServiceFee,
      gf_float_service_rate_ck: this.data.assessment.offer[2].consultFloatServiceFee,
      gf_float_service_rate: this.data.assessment.offer[2].FloatServiceFee,
      gf_fixed_service_fee_ck: this.data.assessment.offer[2].consultFixedServiceFee,
      gf_fixed_service_fee: this.data.assessment.offer[2].FixedServiceFee,
      exhibition_lawyer_fee_gf: this.data.assessment.offer[2].lawyerFee,
      commission_manage_rate_gf_f: this.data.commission_manage_rate_gf_f,
      commission_manage_rate_gf_g: this.data.commission_manage_rate_gf_g,
    }
    let self: any = this
    self
      .$confirm('您确定保存吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
      .then(() => {
        Api.upDataOffer(parmas).then((res: any) => {
          if (res.state) {
            self.$message.success(res.msg)
            self.data.offerType = !self.data.offerType
            self.$emit('init', self.data.debtor_number)
          } else {
            self.$message.warning(res.msg)
          }
        })
      })
      .catch(() => {
        self.$message({
          type: 'info',
          message: '已取消保存',
        })
      })
  }
  //报价
  selectOffer(parmas: any) {
    Api.selectOffer(parmas).then((res: any) => {
      if (res.state) {
        // this.$message.success(res.msg)
        this.$emit('release')
      } else {
        this.$message.warning(res.msg)
      }
    })
  }
  //预览
  preview() {
    let url: string =
      'http://api1.debteehelper.com/Case/AnalysisReport?debtor_number=' + this.data.debtor_number
    let url2: string = this.data.third_assessment_report
    if (url2 == null || url2 == '') {
      window.open(url)
    } else {
      window.open(url2)
    }
  }
  //获取管理员下拉
  getAllAdmin() {
    Api.getAllAdmin().then((res: any) => {
      this.data.options = res.data
    })
  }
  //发送评估报告
  sand() {
    if (this.data.value == '') {
      this.$message.warning('请选择邮件发送人')
      return false
    }
    let arr: any = this.data.value.split(',')
    let parmas: any = {
      admin_id: arr[0], //管理员id
      toAddress: arr[1], //发送邮箱
      debtor_number: this.data.debtor_number, //委托编号
    }
    let self: any = this
    self
      .$confirm('您确定发送吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
      .then(() => {
        Api.sandReport(parmas).then((res: any) => {
          if (res.state) {
            self.$message.success(res.msg)
          } else {
            self.$message.warning(res.msg)
          }
        })
      })
      .catch(() => {
        self.$message({
          type: 'info',
          message: '已取消发送',
        })
      })
  }
  //生成报告
  generate() {
    let parmas: any = {
      debtor_number: this.data.debtor_number,
      case_status: 2,
    }
    Api.updataCaseStatus(parmas).then((res: any) => {
      if (res.state) {
        this.$message.success(res.msg)
      } else {
        this.$message.warning(res.msg)
      }
    })
  }
  //更新债务人第三方评估报告
  handleSuccess(file: any) {
    let parmas: any = {
      debtor_number: this.data.debtor_number,
      third_assessment_report:
        'http://file.debteehelper.com/' + file.data.FileUrl + file.data.FileExtension,
    }
    Api.UpdataReport(parmas).then((res: any) => {
      if (res.state) {
        this.$message.success(res.msg)
        this.$emit('init', this.data.debtor_number)
      } else {
        this.$message.warning(res.msg)
      }
    })
  }
  //选择
  choice(val: any) {
    let parmas: any = {
      debtor_number: this.data.debtor_number,
      service_fee_mode:
        val == 0
          ? 'Case_Service_Fee_Mode_1'
          : val == 1
          ? 'Case_Service_Fee_Mode_2'
          : 'Case_Service_Fee_Mode_3',
    }
    let self: any = this
    self
      .$confirm('您确定选择该服务费模式吗?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning',
      })
      .then(() => {
        self.selectOffer(parmas)
      })
      .catch(() => {
        self.$message({
          type: 'info',
          message: '已取消选择',
        })
      })
  }
}
</script>

<style lang="scss">
@import '@/assets/scss/variables';

.assessment-wrap {
  width: 100%;
  overflow-y: auto;
  & > .section {
    margin-bottom: 20px;
    padding-right: 20px;
    & > span:first-child {
      font-size: 12px;
      margin-top: 10px;
      display: block;
      height: 20px;
      .edit {
        color: #e6a23c;
        float: right;
        cursor: pointer;
      }
      .add {
        color: #67c23a;
        float: right;
        cursor: pointer;
      }
    }
    .box {
      display: flex;
      flex-wrap: wrap;
      & > .text {
        width: 33.33%;
        p {
          color: $General-colors;
          font-size: 14px;
          margin: 0;
          margin-bottom: 10px;
          line-height: 32px;
          display: flex;
          & > span:first-child {
            margin-right: 20px;
            font-size: 12px;
            color: $Secondary-text;
            min-width: 60px;
          }
        }
      }
      & > .el-row {
        width: 100%;
        height: 32px;
        line-height: 32px;
        margin-bottom: 10px;
        span {
          color: #909199;
          font-size: 12px;
        }
        p {
          margin: 0;
          font-size: 14px;
          color: #313133;
        }
      }
    }
  }
  .el-tag + .el-tag {
    margin-left: 10px;
  }
  .button-new-tag {
    margin-left: 10px;
    height: 32px;
    line-height: 30px;
    padding-top: 0;
    padding-bottom: 0;
  }
  .input-new-tag {
    width: 90px;
    margin-left: 10px;
    vertical-align: bottom;
  }
  .laber {
    font-size: 12px;
    color: #909199;
    padding-right: 20px;
  }
  .value {
    font-size: 14px;
    color: #303133;
  }
  .red {
    color: #ec193a;
  }
  .bold {
    font: bold;
    font-size: 16px;
  }
  .content > .el-row {
    margin-bottom: 20px;
  }
  .title {
    font-size: 14px;
    color: #606266;
    font-weight: bold;
    display: inline-block;
    border-left: 3px solid #e01f3c;
    height: 15px;
    line-height: 15px;
    padding-left: 10px;
  }
}
</style>
