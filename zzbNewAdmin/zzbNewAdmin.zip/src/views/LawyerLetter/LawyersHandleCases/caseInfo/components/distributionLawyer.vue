<template>
  <div :style="{ height: data.height + 'px' }" class="distributionLawyer-wrap">
    <div class="section">
      <span style="margin-top:0;">
        <span class="title">一审</span>
        <!-- <span class="generate">案件派单</span> -->
      </span>
      <el-divider></el-divider>
      <comTab2 :tableData="data.distributionLawyer.tabData" :tableType="data.distributionLawyer.tabOption" @revoke="revoke" @distribution="distribution"></comTab2>
    </div>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator'
import { Getter, Action } from 'vuex-class'
import comTab2 from './table2.vue'
import * as Api from '../../../../../api/business'
@Component({
  components: {
    comTab2,
  },
})
export default class About extends Vue {
  // prop
  @Prop({ required: false, default: '' }) distributionLawyer!: any
  @Prop() height!: number
  @Prop() debtor_number!: number
  //Watch
  @Watch('distributionLawyer', { deep: true, immediate: true })
  distributionLawyerChangeVal(newVal: any, oldVal: any) {
    this.data.distributionLawyer = newVal
  }
  @Watch('height', { deep: true, immediate: true })
  heightChangeVal(newVal: number, oldVal: number) {
    this.data.height = newVal
  }
  @Watch('debtor_number', { deep: true, immediate: true })
  debtor_numberChangeVal(newVal: string, oldVal: string) {
    this.data.debtor_number = newVal
  }
  // data
  data: any = {
    distributionLawyer: {}, //父组件传过来的数据
    height: 0, //侧边栏高度
    debtor_number: '',
  }
  created() {
    //
  }

  activated() {
    //
  }

  mounted() {
    //
  }
  //分配
  distribution(data: any) {
    let parmas: any = {
      id: data.row.id,
      debtor_number: this.data.debtor_number,
    }
    Api.distributionCase(parmas).then((res: any) => {
      if (res.state) {
        this.$message.success(res.msg)
        this.$emit('init')
      } else {
        this.$message.warning(res.msg)
      }
    })
  }
  //撤销
  revoke(data: any) {
    let id: any = data.row.id
    Api.revokeDistribution(id).then((res: any) => {
      if (res.state) {
        this.$message.success(res.msg)
        this.$emit('init')
      } else {
        this.$message.warning(res.msg)
      }
    })
  }
}
</script>

<style lang="scss">
@import '@/assets/scss/variables';

.distributionLawyer-wrap {
  width: 100%;
  overflow-y: auto;
  & > .section {
    margin-bottom: 20px;
    padding-right: 20px;
    & > span:first-child {
      margin-top: 10px;
      display: block;
      height: 20px;
      .edit {
        color: #e6a23c;
        float: right;
        cursor: pointer;
      }
      .add {
        color: #67c23a;
        float: right;
        cursor: pointer;
      }
    }
    .box {
      display: flex;
      flex-wrap: wrap;
      & > .text {
        width: 33.33%;
        p {
          color: $General-colors;
          font-size: 14px;
          margin: 0;
          margin-bottom: 10px;
          line-height: 32px;
          display: flex;
          & > span:first-child {
            margin-right: 20px;
            font-size: 12px;
            color: $Secondary-text;
            min-width: 60px;
          }
        }
      }
      & > .el-row {
        width: 100%;
        & > .select01 {
          width: 100px;
          margin-left: 10px;
        }
        & > .select02 {
          width: 100px;
          margin-left: 30px;
        }
      }
    }
  }
  .el-tag + .el-tag {
    margin-left: 10px;
  }
  .button-new-tag {
    margin-left: 10px;
    height: 32px;
    line-height: 30px;
    padding-top: 0;
    padding-bottom: 0;
  }
  .input-new-tag {
    width: 90px;
    margin-left: 10px;
    vertical-align: bottom;
  }
  .generate {
    color: white;
    float: right;
    cursor: pointer;
    background: #ec193a;
    padding: 4px 8px;
    border-radius: 2px;
  }
  .title {
    font-size: 14px;
    color: #606266;
    font-weight: bold;
    display: inline-block;
    border-left: 3px solid #e01f3c;
    height: 15px;
    line-height: 15px;
    padding-left: 10px;
  }
}
</style>
