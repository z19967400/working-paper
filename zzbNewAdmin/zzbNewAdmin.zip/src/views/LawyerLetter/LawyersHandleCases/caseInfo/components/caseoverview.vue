<template>
  <div :style="{ height: data.height + 'px' }" class="caseoverview-wrap">
    <div class="section">
      <span style="margin-top:0;">
        <span class="title">基础信息</span>
      </span>
      <el-divider></el-divider>
      <div class="box">
        <div v-for="(item, index) in data.caseoverview.information" :key="index" class="text">
          <p v-for="(item2, index2) in item" :key="index2">
            <span>{{ item2.name }}</span>
            <span>{{ item2.value }}</span>
          </p>
        </div>
      </div>
    </div>
    <div class="section">
      <span style="margin-top:0;">
        <span class="title">办案事项</span>
      </span>
      <el-divider></el-divider>
      <div class="box">
        <el-row>
          <el-tag :key="tag.id" v-for="tag in data.caseoverview.matter" closable :disable-transitions="false" @close="handleClose(tag.id)">
            {{ tag.matters_name }}
          </el-tag>
          <el-select class="select01" size="small" ref="saveTagInput" v-if="data.inputVisible" v-model="data.inputValue" placeholder="请选择" @change="handleInputConfirm">
            <el-option v-for="item in options" :key="item.id" :label="item.matters_name" :value="item.id+','+item.matters_name">
            </el-option>
          </el-select>
          <el-button v-else class="button-new-tag" size="small" @click="showInput">+ 新增</el-button>
        </el-row>
      </div>
    </div>
    <div class="section">
      <span style="margin-top:0;">
        <span class="title">专案客服</span>
      </span>
      <el-divider></el-divider>
      <div class="box">
        <el-row>
          <el-radio-group @change="customeRadio" v-model="data.radio">
            <el-radio v-for="(item, index) in data.caseoverview.customer" :key="index" :label="index">{{ item.name }}</el-radio>
          </el-radio-group>
          <el-select class="select02" size="small" ref="saveTagInput" v-if="data.customerVisible" v-model="data.addCustomer" placeholder="请选择" @change="handleInputConfirm2">
            <el-option v-for="item in options2" :key="item.id" :label="item.name" :value="item.id+','+item.name">
            </el-option>
          </el-select>
          <el-button v-else class="button-new-tag" size="small" @click="showInput2">+ 新增</el-button>
        </el-row>
      </div>
    </div>
    <div class="section">
      <span style="margin-top:0;">
        <span class="title">债权人</span>
      </span>
      <el-divider></el-divider>
      <div class="box">
        <div v-for="(item, index) in data.caseoverview.creditor" :key="index" class="text">
          <p v-for="(item2, index2) in item" :style="{ width: item2.width }" :key="index2">
            <span>{{ item2.name }}</span>
            <span>{{ item2.value }}</span>
          </p>
        </div>
      </div>
    </div>
    <div class="section">
      <span style="margin-top:0;">
        <span class="title">案件信息</span>
        <span @click="data.caseInformation = !data.caseInformation" class="edit">{{ data.caseInformation ? "编辑" : "返回" }}</span></span>
      <el-divider></el-divider>
      <div v-if="data.caseInformation" class="box">
        <p v-for="(item, index) in data.caseoverview.caseInformation" :key="index" style="display:flex;margin:0 0 10px 0;height:32px;" :style="{ width: item.value.length > 20 ? '100%' : '33.33%' }">
          <span style="color:#909399;font-size:12px;margin-right:10px;min-width:60px;">{{ item.name }}</span>
          <span v-if="item.name != '欠款币种'" style="font-size:14px;color:#303133;">{{ item.value }}</span>
          <span v-else style="font-size:14px;color:#303133;">{{getcurrency(item.value) }}</span>
        </p>
      </div>
      <div v-else class="box">
        <el-row v-for="(item, index) in data.caseoverview.caseInformation" :key="index" style="display:flex;margin:0 0 10px 0;height:32px;line-height:32px;" :style="{ width: item.value.length > 20 ? '100%' : '33.33%' }">
          <span style="color:#909399;font-size:12px;margin-right:10px;min-width:60px;">{{ item.name }}</span>
          <el-col :span="12">
            <el-input v-if="item.name != '欠款币种'" size="small" style="font-size:14;" v-model="item.value" placeholder="请输入内容"></el-input>
            <el-select v-else v-model="item.value" placeholder="请选择欠款币种">
              <el-option v-for="item in currencys" :key="item.id" :label="item.currency_name" :value="item.id">
              </el-option>
            </el-select>
          </el-col>
        </el-row>
        <div style="width:100%;">
          <el-button class="button-new-tag" size="small" @click="saveCaseInfor">保存</el-button>
        </div>
      </div>
    </div>
    <div class="section">
      <span style="margin-top:0;">
        <span class="title">案件辖区</span>
        <span @click="data.JurisdictionType = !data.JurisdictionType" class="edit">{{ data.JurisdictionType ? "编辑" : "返回" }}</span></span>
      <el-divider></el-divider>
      <div style="margin-bottom:20px;" class="box">
        <el-row>
          <el-col :span="24">
            <el-row style="line-height:50px;">
              <el-col :span="2">
                <span class="laber">案件管辖地区</span>
              </el-col>
              <el-col :span="16">
                <!-- <span v-if="data.JurisdictionType" class="value">{{data.caseoverview.Jurisdiction.jurisdiction_01_txt}}</span> -->
                <span v-if="data.JurisdictionType && data.caseoverview.Jurisdiction.jurisdiction_01_select != ''" class="addressBtn">{{data.caseoverview.Jurisdiction.jurisdiction_01_select}}</span>
                <span v-if="!data.JurisdictionType" class="value">
                  <comAddress @emitAddress="getJurisdiction1" :address="data.caseoverview.Jurisdiction.jurisdiction_01_txt"></comAddress>
                </span>
              </el-col>
            </el-row>
          </el-col>
          <el-col :span="24">
            <el-row style="line-height:50px;">
              <el-col :span="2">
                <span class="laber">案件管辖地区一</span>
              </el-col>
              <el-col :span="16">
                <!-- <span v-if="data.JurisdictionType" class="value">{{data.caseoverview.Jurisdiction.jurisdiction_02_txt}}</span> -->
                <span v-if="data.JurisdictionType && data.caseoverview.Jurisdiction.jurisdiction_02_select != ''" class="addressBtn">{{data.caseoverview.Jurisdiction.jurisdiction_02_select}}</span>
                <span v-if="!data.JurisdictionType" class="value">
                  <comAddress @emitAddress="getJurisdiction2" :address="data.caseoverview.Jurisdiction.jurisdiction_02_txt"></comAddress>
                </span>
              </el-col>
            </el-row>
          </el-col>
          <el-col :span="24">
            <el-row style="line-height:50px;">
              <el-col :span="2">
                <span class="laber">其他管辖地区二</span>
              </el-col>
              <el-col :span="16">
                <!-- <span v-if="data.JurisdictionType" class="value">{{data.caseoverview.Jurisdiction.jurisdiction_03_txt}}</span> -->
                <span v-if="data.JurisdictionType && data.caseoverview.Jurisdiction.jurisdiction_03_select != ''" class="addressBtn">{{data.caseoverview.Jurisdiction.jurisdiction_03_select}}</span>
                <span v-if="!data.JurisdictionType" class="value">
                  <comAddress @emitAddress="getJurisdiction3" :address="data.caseoverview.Jurisdiction.jurisdiction_03_txt"></comAddress>
                </span>
              </el-col>
            </el-row>
          </el-col>
        </el-row>
        <el-button v-show="!data.JurisdictionType" @click="saveJurisdiction" size="small" type="primary">保存</el-button>
      </div>
    </div>
    <!-- <div class="section">
      <span style="margin-top:0;">案件数据<span @click="data.caseData = !data.caseData" class="edit">{{
          data.caseData ? "编辑" : "返回"
        }}</span></span>
      <el-divider></el-divider>
      <div class="box">
        <div v-for="(item, index) in data.caseoverview.caseData" :key="index" class="text">
          <p v-for="(item2, index2) in item" :style="{ width: item2.width }" :key="index2">
            <span>{{ item2.name }}</span>
            <span v-if="data.caseData">{{ item2.value }} </span>
            <span v-else>
              <el-input size="small" style="font-size:14;" v-model="item2.value" placeholder="请输入内容"></el-input>
            </span>
          </p>
        </div>
      </div>
      <el-row v-if="data.caseData">
        <el-col :span="2">
          <span style="font-size:14px;color:#909399;line-height:32px;">发送报价</span>
        </el-col>
        <el-col :span="5">
          <el-select class="select02" size="small" ref="saveTagInput" v-model="data.sendQuote" placeholder="请选择" @change="handleInputConfirm3">
            <el-option v-for="item in options2" :key="item.value" :label="item.name" :value="item.id+','+item.name">
            </el-option>
          </el-select>
        </el-col>
        <el-col :span="2">
          <el-button type="primary" size="small" plain>发送</el-button>
        </el-col>
      </el-row>
    </div> -->
    <!-- <div class="section">
      <span style="margin-top:0;">回款记录<span @click="data.addCollection = true" class="add">新增回款</span></span>
      <el-divider></el-divider>
      <comTab1 :tableData="data.caseoverview.tabData" :tableType="data.caseoverview.tabOption" @Delete="collectionDel"></comTab1>
    </div> -->
    <div class="section">
      <span style="margin-top:0;">
        <span class="title">后台备注</span>
        <span @click="data.textarea = !data.textarea" class="edit">{{
          data.textarea ? "编辑" : "返回"
        }}</span></span>
      <el-divider></el-divider>
      <div class="box">
        <el-row style="width:100%;">
          <el-col :span="1">
            <span style="color:#909199;font-size:12px;">备注</span>
          </el-col>
          <el-col v-if="data.textarea" :span="12">
            <p style="font-size:14px;color:#303133;margin:0;">
              {{ data.caseoverview.textarea }}
            </p>
          </el-col>
          <el-col v-else :span="12">
            <el-input type="textarea" :rows="2" placeholder="请输入备注" v-model="data.caseoverview.textarea">
            </el-input>
          </el-col>
        </el-row>
        <el-row v-if="!data.textarea" style="width:100%;margin-top:20px;">
          <el-col :span="1"><span style="opacity:0;">111</span></el-col>
          <el-col :span="4">
            <el-button size="small" @click="upRemarks" type="primary" plain>保存</el-button>
          </el-col>
        </el-row>
      </div>
    </div>
    <!-- 新增回款记录 -->
    <el-dialog title="新增回款记录" :visible.sync="data.addCollection">
      <addFrom></addFrom>
    </el-dialog>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator'
import { Getter, Action } from 'vuex-class'
import comTab1 from './table1.vue'
import addFrom from './from1.vue'
import { comAddress } from '../../../../../components/index'
import * as Api from '../../../../../api/business'
import { api } from '../../../../../../../zzbPc/src/assets/js/api'
@Component({
  components: {
    comTab1,
    addFrom,
    comAddress,
  },
})
export default class About extends Vue {
  // prop
  @Prop({ required: false, default: '' }) caseoverview!: any
  @Prop() height!: number
  @Prop() debtor_number!: number
  //Watch
  @Watch('caseoverview', { deep: true, immediate: true })
  caseoverviewChangeVal(newVal: any, oldVal: any) {
    this.data.caseoverview = newVal
    let customerIndex: number = 0
    newVal.customer.forEach((item: any, index: number) => {
      if (item.is_main == 1) {
        customerIndex = index
      }
    })
    this.data.radio = customerIndex
  }
  @Watch('height', { deep: true, immediate: true })
  heightChangeVal(newVal: number, oldVal: number) {
    this.data.height = newVal
  }
  @Watch('debtor_number', { deep: true, immediate: true })
  debtor_numberChangeVal(newVal: string, oldVal: string) {
    this.data.debtor_number = newVal
  }
  // data
  data: any = {
    debtor_number: '', //债务编号
    caseoverview: {}, //父组件传过来的数据
    inputVisible: false, //办案事项新增按钮控制显隐
    inputValue: '', //办案事项新增内容
    radio: 0, //专案客服主客服选择值
    addCustomer: '', //专案客服新增内容
    sendQuote: '', //发送报价的内容
    customerVisible: false, //新增客服按钮控制显隐
    height: 0, //侧边栏高度
    caseInformation: true, //案件信息编辑状态
    caseData: true, //案件数据编辑状态
    addCollection: false, //新增回款记录弹窗是否显示
    textarea: true, //后台备注编辑状态
    JurisdictionType: true, //辖区编辑状态
    JurisdictionData: {}, //辖区地址数据
  }
  options: any = [] //办案事项下拉
  options2: any = [] //管理员(客服)下拉
  options3: any = [] //发送报价
  currencys: any = [] //欠款币种
  created() {
    //
  }

  activated() {
    //
  }

  mounted() {
    this.getAllMatters()
    this.getAllAdmin()
    this.getCurrencys()
  }
  //删除办案事项
  handleClose(tag: any) {
    let parmas: any = {
      id: tag,
      debtor_number: this.data.debtor_number,
      flow_id: 0,
    }
    Api.editMatters(parmas).then((res: any) => {
      if (res.state) {
        this.data.caseoverview.matter.splice(this.data.caseoverview.matter.indexOf(tag), 1)
        this.$message.success(res.msg)
      } else {
        this.$message.warning(res.msg)
      }
    })
  }
  //显示办案事项新增输入框
  showInput() {
    let self: any = this
    self.data.inputVisible = true
    // self.$nextTick(() => {
    //   self.$refs.saveTagInput.$refs.input.focus();
    // });
  }
  //显示专属客服新增输入框
  showInput2() {
    this.data.customerVisible = true
  }
  //新增办案事项
  handleInputConfirm() {
    let self: any = this
    let arr: any = self.data.inputValue.split(',')
    let inputValue: any = {
      id: arr[0],
      matters_name: arr[1],
    }
    let addStatus: boolean = true
    self.data.caseoverview.matter.forEach((item: any) => {
      if (item.matters_name == inputValue.matters_name) {
        addStatus = false
      }
    })
    if (inputValue) {
      if (addStatus) {
        self.data.caseoverview.matter.push(inputValue)
        self.editMatters(inputValue.id)
      } else {
        self.$message.warning('办案事项不能重复添加')
      }
    }
    self.data.inputVisible = false
    self.data.inputValue = ''
  }
  //新增专属客服
  handleInputConfirm2() {
    let self: any = this
    let arr: any = self.data.addCustomer.split(',')
    let inputValue: any = {
      id: arr[0],
      name: arr[1],
    }
    let addStatus: boolean = true
    self.data.caseoverview.customer.forEach((item: any) => {
      if (item.name == inputValue.name) {
        addStatus = false
      }
    })
    if (inputValue) {
      if (addStatus) {
        self.addCustome(inputValue)
      } else {
        self.$message.warning('专属客服不能重复添加')
      }
    }
    self.data.customerVisible = false
    self.data.addCustomer = ''
  }
  //回款记录删除
  collectionDel(data: any) {
    // eslint-disable-next-line no-console
    console.log(data)
  }
  //保存辖区地址
  saveJurisdiction() {
    this.data.JurisdictionData.debtor_number = this.data.debtor_number
    Api.editJurisdiction(this.data.JurisdictionData).then((res: any) => {
      if (res.state) {
        this.$message.success(res.msg)
        this.data.JurisdictionType = !this.data.JurisdictionType
        this.$emit('init')
      } else {
        this.$message.warning(res.msg)
      }
    })
  }
  //辖区子组件返值
  getJurisdiction1(data: any) {
    // this.data.JurisdictionData.jurisdiction_01_txt = this.data.caseoverview.Jurisdiction.jurisdiction_01_txt
    Object.keys(data).forEach((key: string) => {
      if (data[key] != undefined) {
        this.data.JurisdictionData['jurisdiction_01_' + (key == 'county' ? 'area' : key)] =
          data[key]
      }
    })
  }
  getJurisdiction2(data: any) {
    // this.data.JurisdictionData.jurisdiction_02_txt = this.data.caseoverview.Jurisdiction.jurisdiction_02_txt
    Object.keys(data).forEach((key: string) => {
      if (data[key] != undefined) {
        this.data.JurisdictionData['jurisdiction_02_' + (key == 'county' ? 'area' : key)] =
          data[key]
      }
    })
  }
  getJurisdiction3(data: any) {
    // this.data.JurisdictionData.jurisdiction_03_txt = this.data.caseoverview.Jurisdiction.jurisdiction_03_txt
    Object.keys(data).forEach((key: string) => {
      if (data[key] != undefined) {
        this.data.JurisdictionData['jurisdiction_03_' + (key == 'county' ? 'area' : key)] =
          data[key]
      }
    })
  }
  //获取所有办案事项
  getAllMatters() {
    Api.getAllMatters().then((res: any) => {
      this.options = res.data
    })
  }
  //获取管理员下拉
  getAllAdmin() {
    Api.getAllAdmin().then((res: any) => {
      this.options2 = res.data
    })
  }
  //获取币种下拉
  getCurrencys() {
    Api.getCurrency().then((res: any) => {
      this.currencys = res.data
    })
  }

  //修改办案事项
  editMatters(id: any) {
    let parmas: any = {
      id: '',
      debtor_number: this.data.debtor_number,
      flow_id: id || 0,
    }
    Api.editMatters(parmas).then((res: any) => {
      if (res.state) {
        this.$message.success(res.msg)
      } else {
        this.$message.warning(res.msg)
      }
    })
  }
  //添加专案客服
  addCustome(value: any) {
    let self: any = this
    let parmas: any = {
      admin_id: value.id,
      debtor_number: self.data.debtor_number,
    }
    Api.settingCustomer(parmas).then((res: any) => {
      if (res.state) {
        self.$message.success(res.msg)
        value.id = res.data
        self.data.caseoverview.customer.push(value)
        if (self.data.caseoverview.customer.length == 1) {
          self.settingZhuCustomer(res.data)
        }
      } else {
        self.$message.warning(res.msg)
      }
    })
  }
  //设置主客服
  settingZhuCustomer(id: any) {
    let parmas: any = {
      id: id,
      debtor_number: this.data.debtor_number,
    }
    Api.settingZhuCustomer(parmas).then((res: any) => {
      if (res.state) {
        this.$message.success('主客服设置成功')
      } else {
        this.$message.warning(res.msg)
      }
    })
  }
  //客服选择
  customeRadio(e: any) {
    let id: any = this.data.caseoverview.customer[e].id
    this.settingZhuCustomer(id)
  }
  //选择送报价目标
  handleInputConfirm3(e: any) {
    // eslint-disable-next-line no-console
    console.log(e)
  }
  //更新后台备注
  upRemarks() {
    let prams: any = {
      debtor_number: this.data.debtor_number,
      back_remarks: this.data.caseoverview.textarea,
    }
    Api.updataCaseRemarks(prams).then((res: any) => {
      if (res.state) {
        this.$message.success(res.msg)
        this.data.textarea = !this.data.textarea
      } else {
        this.$message.warning(res.msg)
      }
    })
  }
  //保存案件基础信息
  saveCaseInfor() {
    let self: any = this
    const matching: any = {
      debtor_number: '债务人编号',
      debtor_name: '债务人',
      id_card_no: '债务人身份证号码',
      phone_number: '债务人联系方式',
      address_txt: '债务人有效联系地址',
      contact_person: '负责人姓名',
      arrears_principal: '欠款本金',
      currency_id: '欠款币种',
      arrears_interest: '违约金/利息/滞纳金（元）',
      insurer_name: '被保险人',
      agreed_payment_date: '约定付款日期',
      guarantee_type: '担保类型',
      lending_rate: '贷款利率（年息%）',
      property_clues: '债务人财产线索',
      property_clues_bc: '债务人财产线索补充说明',
      confirmation_method: '债务人对欠款的确认方式',
      confirmation_date: '确认日期',
      available_evidence: '现有证据',
      other_evidence: '其他证据',
      is_dispute: '欠款是否存在争议',
      entrusted_matters: '委托事项',
      other_entrustment: '其他委托',
      creditor_name: '债权人联系人姓名',
      creditor_telphone: '债权人联系人电话',
      creditor_email: '债权人联系人邮箱',
      d_remarks: '备注',
    }
    let caseInformation: any = self.data.caseoverview.caseInformation
    Object.keys(matching).forEach((key: string) => {
      caseInformation.forEach((item: any) => {
        if (matching[key] == item.name) {
          matching[key] = item.value
        }
      })
    })
    Api.CasesUpdateDebtor(matching).then((res: any) => {
      if (res.state) {
        this.data.caseInformation = !this.data.caseInformation
        this.$message.success(res.msg)
      } else {
        this.$message.warning(res.msg)
      }
    })
  }
  //获取币种id对应显示值
  getcurrency(id: any) {
    let list: any = this.currencys
    let value: string = ''
    let newList: any = list.filter((item: any) => {
      return item.id == id
    })
    if (newList.length == 0) {
      value = '暂无'
    } else {
      value = newList[0].currency_name
    }
    return value
  }
}
</script>

<style lang="scss">
@import '@/assets/scss/variables';

.caseoverview-wrap {
  width: 100%;
  overflow-y: auto;
  & > .section {
    margin-bottom: 20px;
    padding-right: 20px;
    & > span:first-child {
      margin-top: 10px;
      display: block;
      height: 20px;
      .edit {
        color: #e6a23c;
        float: right;
        cursor: pointer;
      }
      .add {
        color: #67c23a;
        float: right;
        cursor: pointer;
      }
    }
    .box {
      display: flex;
      flex-wrap: wrap;
      & > .text {
        width: 33.33%;
        p {
          color: $General-colors;
          font-size: 14px;
          margin: 0;
          margin-bottom: 10px;
          line-height: 32px;
          display: flex;
          & > span:first-child {
            margin-right: 20px;
            font-size: 12px;
            color: $Secondary-text;
            min-width: 60px;
          }
        }
      }
      & > .el-row {
        width: 100%;
      }
    }
  }
  .el-tag + .el-tag {
    margin-left: 10px;
  }
  .button-new-tag {
    margin-left: 10px;
    height: 32px;
    line-height: 30px;
    padding-top: 0;
    padding-bottom: 0;
  }
  .input-new-tag {
    width: 90px;
    margin-left: 10px;
    vertical-align: bottom;
  }
  .laber {
    font-size: 14px;
    color: #909199;
    // margin-right: 20px;
  }
  .value {
    font-size: 14px;
    color: #303133;
  }
  .select01 {
    margin-left: 20px;
  }
  .select02 {
    margin-left: 20px;
  }
  .addressBtn {
    margin-left: 20px;
    background: #ec193a;
    color: white;
    font-size: 12px;
    padding: 4px 8px;
  }
  .title {
    font-size: 14px;
    color: #606266;
    font-weight: bold;
    display: inline-block;
    border-left: 3px solid #e01f3c;
    height: 15px;
    line-height: 15px;
    padding-left: 10px;
  }
  & .el-cascader {
    width: 250px;
  }
}
</style>
