import { Component, Vue } from "vue-property-decorator";
import { businessOptions } from "@/types/index.ts";
import * as Api from "@/api/business.ts";
import { baseURL } from "@/utils/request";
@Component({})
export default class About extends Vue {
  // Getter

  // Action

  // data
  data: any = {
    express: [],
    info: {
      batch_no: "",
      name: "",
      creditor_name: "",
      debtor_name: "",
      admin_name: ""
    },
    lawyerLette: {
      execution_status_name: "",
      receiving_name: "",
      receiving_phone: "",
      receiving_address: "",
      courier_receipt_img: "",
      dic_content: ""
    },
    addExpressData: {
      id: 0,
      log_logistics_id: "",
      update_time: "",
      update_context: ""
    }
  };
  input: string = "";
  desc: string = "";
  baseURl: string = "";
  filelist: any = [];
  pdfsrc: string =
    "http://www.zzbang.vip/Uploads/lsh/lsh/104622732007103043_%E5%BC%A0%E5%87%8C%E8%B6%85.pdf";
  created() {
    //
  }

  activated() {
    this.init();
  }

  mounted() {
    //
  }
  // 初始化函数
  init() {
    let self: any = this;
    self.baseURl = baseURL;
    self.addExpress.update_context = "";
    self.addExpress.update_time = "";
    self.getInfo(self.$route.query.id);
  }
  //获取数据
  getInfo(id: number) {
    Api.getLawyerAdminInfo(id).then((res: any) => {
      Object.keys(this.data.info).forEach((key: string) => {
        this.data.info[key] = res.head[key];
      });
      Object.keys(this.data.lawyerLette).forEach((key: string) => {
        this.data.lawyerLette[key] = res.data[key];
      });
      this.data.express = res.list;
      this.desc = res.data.back_remarks;
      this.input = res.data.courier_number;
      this.pdfsrc = res.head.pdf_url;
    });
  }
  //保存快递单号
  baocun() {
    this.joinInfo(0, this.input);
  }
  //新增快递进度
  addExpress() {
    this.data.addExpressData.log_logistics_id = this.$route.query.id;
    let parmas: any = this.data.addExpressData;
    Api.addExpress(parmas).then((res: any) => {
      if (res.data != 0) {
        this.$message.success(res.msg);
        this.init();
      } else {
        this.$message.warning(res.msg);
      }
    });
  }
  //保存后台备注
  baocunDesc() {
    this.joinInfo(2, this.desc);
  }
  //信息保存
  joinInfo(type: number | string, content: string) {
    let parmas: any = {
      id: this.$route.query.id,
      type: type,
      content: content
    };
    Api.joinExpress(parmas).then((res: any) => {
      if (res.data != 0) {
        this.$message.success(res.msg);
        // this.init();
      } else {
        this.$message.warning(res.msg);
      }
    });
  }
  handleAvatarSuccess(res: any, file: any) {
    this.data.lawyerLette.courier_receipt_img =
      "http://file.zhaizhubang.net" + res.data.FileUrl + res.data.FileExtension;
    this.joinInfo(1, this.data.lawyerLette.courier_receipt_img);
  }
  beforeAvatarUpload(file: any) {
    const isLt2M = file.size / 1024 / 1024 < 2;
    if (!isLt2M) {
      this.$message.error("上传头像图片大小不能超过 2MB!");
    }
    return isLt2M;
  }
}
