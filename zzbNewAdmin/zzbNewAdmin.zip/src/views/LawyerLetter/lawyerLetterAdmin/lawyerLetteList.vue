<template>
  <div class="lawyerLetteList-wrap">
    <div class="lawyerLetteList-box">
      <comselect
        :options="data.options"
        @select="search"
        @clear="clearSelection"
      ></comselect>
      <comOperation :totalize="data.totalize" @add="add"></comOperation>
      <comtable
        :tableData="data.list"
        :load="data.loading"
        :xq="true"
        @Info="goInfo"
        :tableType="data.dataType"
        @Delete="handleDelete"
      ></comtable>
      <comPaging
        :page="getData.page"
        :totalize="data.totalize"
        @watchChange="watchChange"
      ></comPaging>
    </div>
  </div>
</template>

<script lang="ts" src="./lawyerLetteList.ts"></script>

<style lang="scss">
@import "./lawyerLetteList.scss";
</style>
