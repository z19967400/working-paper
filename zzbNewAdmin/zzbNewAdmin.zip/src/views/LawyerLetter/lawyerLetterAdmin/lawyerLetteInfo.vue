<template>
  <div class="lawyerLetteInfo-wrap">
    <div class="lawyerLetteInfo-box">
      <div class="left">
        <span class="title">委托信息</span>
        <el-divider></el-divider>
        <el-row>
          <el-col>
            <span>委托编号</span>
            <span>{{ data.info.batch_no }}</span>
          </el-col>
        </el-row>
        <el-row>
          <el-col>
            <span>会员名称</span>
            <span>{{ data.info.name }} \ {{ data.info.admin_name }}</span>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <span>债权人名称</span>
            <span>{{ data.info.creditor_name }}</span>
          </el-col>
          <el-col :span="12">
            <span>债务人名称</span>
            <span>{{ data.info.debtor_name }}</span>
          </el-col>
        </el-row>
        <span style=" margin-top: 20px;" class="title">快递信息</span>
        <el-divider></el-divider>
        <el-row>
          <el-col>
            <span>物流状态</span>
            <span>{{ data.lawyerLette.dic_content }}</span>
          </el-col>
        </el-row>
        <el-row>
          <el-col>
            <span>律师函ID</span>
            <span>{{ $route.query.id }}</span>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="12">
            <span>收件人名称</span>
            <span>{{ data.lawyerLette.receiving_name }}</span>
          </el-col>
          <el-col :span="12">
            <span>收件人电话</span>
            <span>{{ data.lawyerLette.receiving_phone }}</span>
          </el-col>
        </el-row>
        <el-row>
          <el-col>
            <span>收件人地址</span>
            <span>{{ data.lawyerLette.receiving_address }}</span>
          </el-col>
        </el-row>
        <div class="left-bottom">
          <el-row>
            <el-col>
              <span>录入快递单号</span>
              <span>
                <el-input
                  size="small"
                  placeholder="请输入快递单号"
                  v-model="input"
                  clearable
                >
                </el-input>
              </span>
              <el-button
                type="primary"
                style="margin-left:20px;"
                size="small"
                @click="baocun"
                plain
                >保存</el-button
              >
            </el-col>
          </el-row>
          <el-row>
            <el-col>
              <span>上传快递底单</span>
              <span>
                <el-upload
                  class="avatar-uploader"
                  :action="baseURl + '/Upload/UploadImage?type=0'"
                  :show-file-list="false"
                  :on-success="handleAvatarSuccess"
                  :before-upload="beforeAvatarUpload"
                >
                  <img
                    v-if="data.lawyerLette.courier_receipt_img != ''"
                    :src="data.lawyerLette.courier_receipt_img"
                    class="avatar"
                  />
                  <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>
              </span>
            </el-col>
          </el-row>
          <el-row>
            <el-col>
              <span>快递进度</span>
              <span class="kuaidi">
                <p v-for="(item, index) in data.express" :key="index">
                  {{ item.update_time }} {{ item.update_context }}
                </p>
                <el-row>
                  <el-col :span="9">
                    <el-date-picker
                      style="width:90%"
                      size="small"
                      v-model="data.addExpressData.update_time"
                      value-format="yyyy-MM-dd"
                      type="date"
                      placeholder="选择日期时间"
                    >
                    </el-date-picker>
                  </el-col>
                  <el-col :span="11">
                    <el-input
                      size="small"
                      placeholder="请输入进度"
                      v-model="data.addExpressData.update_context"
                      clearable
                    >
                    </el-input>
                  </el-col>
                  <el-col :span="4">
                    <el-button
                      type="primary"
                      size="small"
                      icon="el-icon-circle-plus-outline"
                      plain
                      @click="addExpress"
                      >新增</el-button
                    >
                  </el-col>
                </el-row>
              </span>
            </el-col>
          </el-row>
          <el-row>
            <el-col>
              <span>后台备注</span>
              <span>
                <el-input type="textarea" v-model="desc"></el-input>
                <el-row style="margin-top:10px;">
                  <el-button
                    @click="baocunDesc"
                    type="primary"
                    size="small"
                    plain
                    >保存备注</el-button
                  >
                </el-row>
              </span>
            </el-col>
          </el-row>
        </div>
      </div>
      <div class="right">
        <!-- <div>
          <el-button type="primary" size="small" plain
            >点击下载律师函</el-button
          >
        </div> -->
        <div style="height:100%;">
          <iframe class="iframe" :src="pdfsrc" frameborder="0"></iframe>
        </div>
      </div>
    </div>
  </div>
</template>

<script lang="ts" src="./lawyerLetteInfo.ts"></script>

<style lang="scss">
@import "./lawyerLetteInfo.scss";
</style>
