import { Component, Vue } from "vue-property-decorator";
import {
  comselect,
  comOperation,
  comPaging,
  comtable
} from "@/components/index";
import { businessOptions } from "@/types/index.ts";
import * as Api from "@/api/business.ts";
@Component({
  components: {
    comtable,
    comselect,
    comOperation,
    comPaging
  }
})
export default class About extends Vue {
  // Getter

  // Action

  // data
  data: any = {
    loading: false,
    list: [],
    select: {},
    totalize: 0,
    options: [
      {
        value: "debtor_number",
        label: "委托编号"
      },
      {
        value: "creditor_name",
        label: "债权人"
      },
      {
        value: "debtor_name",
        label: "债务人"
      },
      {
        value: "phone_number",
        label: "债务人手机号码"
      },
      {
        value: "courier_number",
        label: "快递单号"
      },
      {
        value: "receiving_name",
        label: "收件人"
      }
    ],
    dataType: [
      {
        label: "ID",
        prop: "id"
      },
      {
        label: "委托批次号",
        prop: "batch_no"
      },
      {
        label: "委托编号",
        prop: "debtor_number"
      },
      {
        label: "债权人",
        prop: "creditor_name"
      },
      {
        label: "债务人",
        prop: "debtor_name"
      },
      {
        label: "债务人地址",
        prop: "address_txt"
      },
      {
        label: "收件人",
        prop: "receiving_name"
      },
      {
        label: "快递单号",
        prop: "courier_number"
      },
      {
        label: "收货地",
        prop: "receiving_address"
      },
      {
        label: "执行状态",
        prop: "execution_status_name"
      },
      {
        label: "创建时间",
        prop: "time"
      }
    ]
  };
  getData: any = {
    page: 1,
    limit: this.$store.getters.limit,
    debtor_number: "",
    creditor_name: "",
    debtor_name: "",
    phone_number: "",
    address_txt: "",
    receiving_name: "",
    courier_number: "",
    receiving_address: "",
    execution_status: "",
    start_time: "",
    end_time: ""
  };
  list: any = [];
  visible: boolean = false;
  created() {
    //
  }

  activated() {
    this.init();
  }

  mounted() {
    //
  }
  // 初始化函数
  init() {
    let self: any = this;
    let params: any =
      JSON.stringify(self.data.select) == "{}"
        ? self.getData
        : self.data.select;
    this.getList(params);
  }
  //获取数据
  getList(params: any) {
    let data: any = this.data;
    data.loading = true;
    data.list = this.list;
    Api.getlawyerAdminList(params).then((res: any) => {
      data.loading = false;
      res.list.forEach((item: any) => {
        item.audit_status =
          item.audit_status == 0
            ? "待审核"
            : item.audit_status == 1
            ? "未通过"
            : "已通过";
      });
      data.list = res.list;
      data.totalize = res.count;
    });
  }
  //跳转详情页面
  goInfo(data: any) {
    this.$router.push({
      path: "/LawyerLetter/lawyerLetteInfo",
      query: {
        id: data.row.id
      }
    });
  }
  //删除
  handleDelete(data: any) {
    Api.entrustDelete(data.row.id).then((res: any) => {
      if (res.data != 0) {
        this.$message.success(res.msg);
        this.init();
      } else {
        this.$message.warning(res.msg);
      }
    });
  }
  //搜索
  search(data: any) {
    let self: any = this;
    self.data.loading = true;
    self.getData.page = 1;
    let params: any = Object.assign({}, self.getData);
    data.forEach((item: any) => {
      let name: string = item.label;
      params[name] = item.value;
    });
    self.data.select = params;
    this.getList(params);
  }
  //清除搜索项
  clearSelection(data: any) {
    let self: any = this;
    self.data.select = {};
    this.init();
  }
  //添加
  add() {
    // this.$router.push({
    //   path: "/VIP/addVip"
    // });
    this.visible = true;
  }
  //分页
  watchChange(index: number, limit: number | null) {
    let self: any = this;
    let params: any =
      JSON.stringify(self.data.select) == "{}"
        ? self.getData
        : self.data.select;
    params.page = index;
    params.limit = limit == null ? params.limit : limit;
    self.init();
  }
  //弹窗确定
  determine() {
    this.init();
  }
  //取消
  cancel() {
    this.visible = false;
  }
}
