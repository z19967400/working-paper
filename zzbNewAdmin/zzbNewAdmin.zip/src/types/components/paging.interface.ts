// paging.Data 参数类型
export interface PagingData {
  componentName: string;
  Tpage: number;
}
