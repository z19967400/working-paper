// table.Data 参数类型
export interface TableData {
  componentName: string;
  loading: boolean;
  Data: any;
  width: string;
  tabInfo: boolean;
}
