// menu.Data 参数类型
export interface MenuData {
  componentName: string;
  isCollapse: boolean;
  menuActive: string;
}
