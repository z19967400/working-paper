// select.Data 参数类型
export interface SelectData {
  componentName: string;
  input: string;
  value: string;
  select: Array<any>;
}
