import Api from "@/utils/request";
import { finance } from "@/types/index.ts";

// 收支列表页
export const getinandout = (params: finance["getinandout"]) => {
  return Api.getinandout(params, "GET");
};

//收支详情
export const getdetails = (id: any) => {
  return Api.getdetails({ id }, "GET");
};

//账单列表页
export const getpagingbill = (params: finance["getpagingbill"]) => {
  return Api.getpagingbill(params, "GET");
};

//账单详情列表页
export const getpagingbilldetails = (id: number) => {
  return Api.getpagingbilldetails({ id }, "GET");
};

//发票列表页
export const getpaginginvoice = (params: finance["getpaginginvoice"]) => {
  return Api.getpaginginvoice(params, "GET");
};

//收票地址列表页
export const getpaginggitinvoice = (params: finance["getpaginggitinvoice"]) => {
  return Api.getpaginggitinvoice(params, "GET");
};

//会员收票地址删除
export const getpagingdeleteinvoice = (id: number) => {
  return Api.getpagingdeleteinvoice({ id }, "GET");
};

// getpagingbilltable
// 生成ai律师函账单
export const getpagingbilltable = (params: finance["getpagingbilltable"]) => {
  return Api.getpagingbilltable(params, "GET");
};

// getbilladmin
// 账单详情
export const getbilladmin = (id: any) => {
  return Api.getbilladmin({ id }, "GET");
};

//生成账单
// getbillinsertlist
export const getbillinsertlist = (params: finance["getbillinsertlist"]) => {
  return Api.getbillinsertlist(params, "POST");
};

//收票地址获取编辑
export const gitinvaedit = (id: any) => {
  return Api.gitinvaedit({ id }, "GET");
};

// 收票地址新增||修改
// editinvaeditaddress
export const posteditinvoice = (params: any) => {
  return Api.posteditinvoice(params, "POST");
};

// 收票地址删除
// deleteinvaeditaddress
export const deleteinvaeditaddress = (id: any) => {
  return Api.deleteinvaeditaddress({ id }, "GET");
};

// 发票删除
// deleteinvaice
export const deleteinvaice = (id: any) => {
  return Api.deleteinvaice({ id }, "GET");
};

//获取债权人的管理员列表
export const getCreditorAdmin = (id: number) => {
  return Api.getCreditorAdmin({ id }, "GET");
};

//获取债权人的会员列表
export const getCreditorUser = (params: any) => {
  return Api.getCreditorUser(params, "GET");
};

// 发票获取编辑
// geteditinvaicebyid
export const geteditinvaicebyid = (id: any) => {
  return Api.geteditinvaicebyid({ id }, "GET");
};

//收票地址修改提交
// editinvaeditaddresss
export const editinvaeditaddress = (params: any) => {
  return Api.editinvaeditaddress(params, "POST");
};

//收支修改
export const editOrder = (params: any) => {
  return Api.editOrder(params, "POST");
};

//收支修改
export const deletBill = (id: number, bill_number: string) => {
  return Api.deletBill({ id, bill_number }, "GET");
};

//获取子账号下拉
export const getSubAccountSelect = (id: number) => {
  return Api.getSubAccountSelect({ parent_account_id: id }, "GET");
};

//分配管理员
export const allocation = (id: number, account_executive: number) => {
  return Api.allocation({ id, account_executive }, "GET");
};

//获取发票下拉
export const getInvoice = (id: number) => {
  return Api.getInvoice({ member_id: id }, "GET");
};

//获取收票地址下拉
export const getInvoiceAddress = (id: number) => {
  return Api.getInvoiceAddress({ member_id: id }, "GET");
};

//获取字典类别
export const GetType = (dic_category_code: string) => {
  return Api.GetType({ dic_category_code }, "GET");
};

//新增结算记录
export const addSettingRecord = (parmas: any) => {
  return Api.addSettingRecord(parmas, "POST");
};

//删除结算记录
export const deleteSettingRecord = (id: number) => {
  return Api.deleteSettingRecord({ id }, "GET");
};

//账单修改
export const billEdit = (parmas: any) => {
  return Api.billEdit(parmas, "POST");
};

//账单备注
export const billRemarks = (id: number, back_remarks: string) => {
  return Api.billRemarks({ id, back_remarks }, "POST");
};

//开票编辑
export const openInvoice = (parmas: finance["openInvoice"]) => {
  return Api.openInvoice(parmas, "POST");
};
