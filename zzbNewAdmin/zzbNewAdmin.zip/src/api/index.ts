import Api from "@/utils/request";

export const getData = () => {
  return Api.getData();
};
