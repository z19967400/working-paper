declare module "af-table-column" {
  const AFTableColumn: any;
  export default AFTableColumn;
}
