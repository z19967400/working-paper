import { Component, Vue, Watch } from "vue-property-decorator";
import { LayoutData } from "@/types/views/layout.interface";
import { Action } from "vuex-class";
import { Menu } from "@/components"; // 组件

@Component({
  components: {
    Menu
  }
})
export default class About extends Vue {
  //
  @Action
  LOGIN_OUT: any;
  //路由监听
  @Watch("$route")
  onChangeValue(newVule: any, oldVule: any) {
    //isTag是路由里定义的是否显示标签的函数，是个布尔值
    if (newVule.meta.isTag == false) {
      //为否就不添加到标签
      return false;
    }
    //标签的对象格式
    let tag: any = {
      name: newVule.meta.title, //名称
      path: newVule.path, //路径
      type: "info", //样式，此时为无色白底，请看样式表
      active: true, //是否当前页
      closable: true //是否可关闭，只有首页是无法关闭的
    };
    //判断此路由是否已经存在于标签
    let includes: any = this.data.tags.filter((item: any) => {
      return tag.name.includes(item.name);
    });
    //未存在则添加
    if (includes.length == 0) {
      if (this.data.tags.length != 0) {
        this.data.tags.forEach((item: any) => {
          item.active = false;
        });
      }
      this.data.tags.push(tag);
      //已存在则选中
    } else {
      this.data.tags.forEach((item: any) => {
        if (item.name == newVule.meta.title) {
          item.active = true;
        } else {
          item.active = false;
        }
      });
    }
    //本地会话备份，防止刷新丢失
    sessionStorage.setItem("tags", JSON.stringify(this.data.tags));
  }
  //头部标签页数据监听
  @Watch("data.tags")
  onChangeTags(newValue: any, oldValue: any) {
    let width: number = newValue.length * 120 + 1;
    let tagsBox: any = this.$refs.tagsBox;
    let headerTag: any = this.$refs.headerTag;
    let headerTagWidth: number = headerTag.getBoundingClientRect().width;
    tagsBox.style.width = width + "px";
    if (width > headerTagWidth) {
      this.left = (width - headerTagWidth) * -1;
    } else {
      this.left = 0;
    }
  }
  // data
  data: LayoutData = {
    customerVisible: false,
    pageName: "layout",
    fullscreenLoading: false,
    tags: [
      {
        name: "首页",
        path: "/",
        type: "info",
        active: true,
        closable: false
      }
    ]
  };
  left: number = 0;
  right: boolean = false;
  openType: boolean = false;
  created() {
    //
  }

  activated() {
    //
  }

  mounted() {
    let tags: string | null = sessionStorage.getItem("tags");
    if (tags != null) {
      this.data.tags = JSON.parse(tags);
    }
  }

  // 初始化函数
  init() {
    //
  }
  handleCommand(command: string | number | object) {
    if (command == "logout") {
      this.$confirm("您确认退出吗?", "提示", {
        confirmButtonText: "确认",
        cancelButtonText: "取消",
        type: "warning"
      })
        .then(() => {
          this.logout();
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消退出"
          });
        });
    }
    if (command == "modify") {
      this.modify();
    }
  }
  //登出
  logout() {
    let data = {
      Routers: [],
      rouls: []
    };
    this.LOGIN_OUT();
    this.$store.dispatch("UPDATE_LAYOUY_STATE", data);
    // this.$router.push({ name: "login" });
    window.location.href = "http://www.debteehelper.com/views/login.html";
  }
  //修改密码
  modify() {
    window.open("http://www.debteehelper.com/views/login.html?edit=true");
  }
  //刷新页面
  Refresh() {
    location.reload();
  }
  //导航栏标签删除
  handleClose(tag: any) {
    //获取当前删除的标签在数组中的下标
    let index: number = this.data.tags
      .map((item: any) => item.name)
      .indexOf(tag.name);
    //从数组中删除该标签
    this.data.tags.splice(this.data.tags.indexOf(tag), 1);
    //更新本地会话存储
    sessionStorage.setItem("tags", JSON.stringify(this.data.tags));
    //定义要回跳的页面路由，此时为该标签的上一个标签
    let history: any = this.data.tags[index - 1];
    //点击的是当前页的标签才会跳转，不是则不跳转
    if (tag.active == true) {
      this.$router.push({
        path: history.path
      });
    }
  }
  //导航栏标签点击
  handleClick(tag: any) {
    this.$router.push({
      path: tag.path
    });
  }
  openWacth(val: boolean) {
    this.openType = val;
  }
  //
  tagRight() {
    let tagsBox: any = this.$refs.tagsBox;
    let headerTag: any = this.$refs.headerTag;
    let headerTagWidth: number = headerTag.getBoundingClientRect().width;
    let tagsWidth: number = tagsBox.getBoundingClientRect().width;
    this.left = (tagsWidth - headerTagWidth) * -1;
    this.right = false;
  }
}
