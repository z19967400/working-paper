<template>
  <div class="entrustAdmin-wrap">
    <div class="entrustAdmin-box">
      <div :style="{
          height:
            (data.labers.length + data.labers[data.actIndex].children.length) *
              40 +
            'px'
        }" class="left">
        <div class="text">
          <div v-for="(item, index) in data.labers" :key="index" :class="{ act: index == data.actIndex }" @click="laberClick(index)">
            <!-- <span>{{ item.label }}</span> -->
            <div v-if="item.children.length != 0" class="children">
              <span :class="{
                  act2: index == data.actIndex && data.actIndex2 == index2
                }" v-for="(item2, index2) in item.children" :key="index2" @click.stop="laberClick2(index, index2)">{{ item2.name }}</span>
            </div>
          </div>
        </div>
        <div class="shuxian-box">
          <div :style="{ transform: ' translateY(' + data.actIndex * 40 + 'px)' }" class="shuxian"></div>
        </div>
      </div>
      <div ref="right" :style="{ height: height + 'px' }" class="right">
        <!-- 案件概览 -->
        <div ref="section0" class="section">
          <span style="margin-top:0;" :class="{ act: data.rightIndex == 0 }">案件概览</span>
          <el-divider></el-divider>
          <div class="box">
            <div v-for="(item, index) in data.BasicInfo" :key="index" class="text">
              <p v-for="(item2, index2) in item" :key="index2">
                <span>{{ item2.name }}</span>
                <span>{{ item2.value }}</span>
              </p>
            </div>
          </div>
        </div>
        <!-- 办案事项 -->
        <div ref="section1" class="section">
          <span :class="{ act: data.rightIndex == 1 }">办案事项</span>
          <el-divider></el-divider>
          <div class="box">
            <el-row style="width:100%">
              <el-tag style="margin-right:10px;" v-for="(item, index) in data.case_matters_name" :key="index">{{ item.matters_name }}</el-tag>
            </el-row>
          </div>
        </div>
        <!-- 案件信息 -->
        <div ref="section2" class="section">
          <span :class="{ act: data.rightIndex == 2 }">案件信息</span>
          <el-divider></el-divider>
          <div class="box">
            <p v-for="(item, index) in data.caseInformation" :key="index" style="display:flex;margin:0 0 10px 0;height:32px;" :style="{ width: item.value.length > 30 ? '100%' : '33.33%' }">
              <span style="color:#909399;font-size:12px;margin-right:10px;min-width:60px;">{{ item.name }}</span><span style="font-size:14px;color:#303133;">{{
                item.value
              }}</span>
            </p>
          </div>
        </div>
        <!-- 债权人 -->
        <div ref="section3" class="section">
          <span :class="{ act: data.rightIndex == 3 }">债权人</span>
          <el-divider></el-divider>
          <div class="box">
            <!-- <div v-for="(item, index) in data.case_creditor" :key="index" class="text">
              <p v-for="(item2, index2) in item" :key="index2">
                <span>{{ item2.name }}</span>
                <span>{{ item2.value }}</span>
              </p>
            </div> -->
            <el-row style="width:100%;">
              <table1 :tableData="data.case_creditorData" :tableOption="data.case_creditorOption"></table1>
            </el-row>
          </div>
        </div>
        <div ref="section4" class="section">
          <span :class="{ act: data.rightIndex == 4 }">查看报价</span>
          <el-divider></el-divider>
          <div class="box">
            <el-row v-if="service_fee_mode != ''" style="width:100%;">
              <el-table :data="patterns" style="width: 100%" max-height="350">
                <el-table-column fixed="left" label="选择" width="80">
                  <template slot-scope="scope">
                    <el-radio v-model="service_fee_mode" :disabled="service_fee_mode !=scope.row.id" :label="scope.row.id">{{
              ""
            }}</el-radio>
                  </template>
                </el-table-column>
                <el-table-column prop="patternName" label="服务费模式" width="220">
                </el-table-column>
                <el-table-column prop="quotedFrice" label="报价" width="220">
                </el-table-column>
                <el-table-column prop="range" label="服务范围">
                </el-table-column>
              </el-table>
              <div>
                <span>案件评估分析报告查看</span>
                <el-button style="color:#67C23A;margin-left:10px;" @click="openReport" type="text">点击查看</el-button>
              </div>
            </el-row>
            <el-row v-else-if="case_status == 'Case_state_1'">
              <el-button style="color:#ec193a;margin-left:10px;text-" @click="confirm = true
              ">选择服务费模式</el-button>
            </el-row>
            <el-row v-else>
              <p style="font-size:14px;color:#909399;margin-left:10px;">案件正在评估中</p>
            </el-row>
          </div>
        </div>
        <!-- 签署合同 -->
        <div ref="section5" class="section">
          <span :class="{ act: data.rightIndex == 5 }">签署合同</span>
          <el-divider></el-divider>
          <el-table align="left" :header-cell-style="{'text-align':'left'}" :cell-style="{'text-align':'left'}" :data="caseProssData.contract" style="width: 100%">
            <el-table-column v-for="(item, index) in data.contractType" :key="index" :prop="item.prop" :label="item.label" :width="item.width">
              <template slot-scope="scope">
                <span>
                  {{ scope.row[item.prop] }}
                </span>
              </template>
            </el-table-column>
            <el-table-column label="操作">
              <template slot-scope="scope">
                <el-button v-if="scope.row.sign_status == '已签署'" type="text" @click="handleSee(scope.row)" style="color:#409EFF;">查看</el-button>
                <el-button v-if="scope.row.sign_status == '待签署'" type="text" @click="handleSign(scope.row)" style="color:#67C23A;">签署</el-button>
                <span v-if="scope.row.sign_status == '合同准备中'" style="font-size:14;">准备中</span>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <el-dialog class="contractDialog" title="合同详情" :visible.sync="data.contractVisible">
          <el-row style="margin-bottom:10px;" v-for="(item,index) in data.contractData" :key="index">
            <el-col :span="4">
              <span>合同内容</span>
            </el-col>
            <el-col :span="12">
              <span @click="toinfo(item)" style="color:#67c23a;cursor: pointer;">{{ item.substring(item.lastIndexOf("/")+1)}}</span>
            </el-col>
          </el-row>
        </el-dialog>
        <!-- 分配律师 -->
        <div ref="section6" class="section">
          <span :class="{ act: data.rightIndex == 6 }">分配律师</span>
          <el-divider></el-divider>
          <table1 :tableData="caseProssData.lawyer" :tableOption="data.lawyerType"></table1>
        </div>
        <!-- 法院信息 -->
        <div ref="section7" class="section">
          <span :class="{ act: data.rightIndex == 7 }">法院信息</span>
          <el-divider></el-divider>
          <table1 :tableData="caseProssData.court" :tableOption="data.courtType"></table1>
        </div>
        <!-- 专属客服 -->
        <div ref="section8" class="section">
          <span :class="{ act: data.rightIndex == 8 }">专案客服</span>
          <el-divider></el-divider>
          <div class="box">
            <el-row style="width:100%">
              <el-tag style="margin-right:10px;" v-for="(item, index) in data.case_customer_service" :key="index">
                <p>姓名:{{item.name}}</p>
                <p>电话:{{item.phone_number}}</p>
                <p>邮箱:{{item.email}}</p>
              </el-tag>
              <p style="font-size:14px;color:#909399;margin-left:10px;" v-show="data.case_customer_service.length == 0">待分配</p>
            </el-row>
          </div>
        </div>
        <div ref="section9" class="section">
          <span :class="{ act: data.rightIndex == 9 }">办案进度</span>
          <el-divider></el-divider>
          <handCasePross :caseProssData="caseProssData"></handCasePross>
        </div>
      </div>
    </div>
    <div class="zhezhao" v-show="data.visible"></div>
    <el-popover :title="data.infoTitle" popper-class="editData" v-model="data.visible">
      <span @click="close" class="el-icon-close close"></span>
      <smsPhone :name="data.infoTitle" :info="infoData"></smsPhone>
    </el-popover>
    <el-dialog title="确认案件服务费模式" :visible.sync="confirm">
      <el-table :data="patterns" style="width: 100%" max-height="350">
        <el-table-column fixed="left" label="选择" width="60">
          <template slot-scope="scope">
            <el-radio v-model="service_fee_mode" :label="scope.row.id">{{
              ""
            }}</el-radio>
          </template>
        </el-table-column>
        <el-table-column prop="patternName" label="服务费模式" width="120">
        </el-table-column>
        <el-table-column prop="quotedFrice" label="报价" width="120">
        </el-table-column>
        <el-table-column prop="range" label="服务范围">
        </el-table-column>
      </el-table>
      <div>
        <span>案件评估分析报告查看</span>
        <el-button style="color:#67C23A;margin-left:10px;" @click="openReport" type="text">点击查看</el-button>
      </div>
      <div style="text-align: center;position: relative;top:20px;">
        <el-button @click="patternsConfirm" type="primary">确认</el-button>
        <el-button @click="confirm = false">取消</el-button>
      </div>
    </el-dialog>
    <div class="btn-box">
      <!-- <el-button size="small" type="success">下载催收报告</el-button>
      <el-button size="small" type="success">下载快递信息</el-button> -->
      <!-- <el-button size="small" @click="entrustDelet" type="primary"
        >删除</el-button
      > -->
      <el-button size="small" plain @click="revoke" type="primary">返回
      </el-button>
    </div>
  </div>
</template>

<script lang="ts" src="./caseInfo.ts"></script>

<style lang="scss">
@import './caseInfo.scss';
</style>
