import { Component, Vue } from "vue-property-decorator";
import * as Api from "@/api/AIlvshihan";
import {
  comselect,
  comtable,
  comOperation,
  comPaging
} from "@/components/index";
@Component({
  components: {
    comtable,
    comselect,
    comOperation,
    comPaging
  }
})
export default class About extends Vue {
  data: any = {
    loading: false,
    visible: false,
    // 表格数据
    list: [],
    select: {},
    totalize: 0,
    options: [
      {
        value: "debtor_number",
        label: "委托编号"
      },
      {
        value: "creditor_name",
        label: "债权人名称"
      },
      {
        value: "debtor_name",
        label: "债务人名称"
      },
      {
        value: "create_name",
        label: "创建人"
      },
      {
        value: "create_time",
        label: "创建时间"
      },
      {
        value: "case_status",
        label: "办案进度"
      }
    ],
    dataType: [
      {
        label: "委托编号",
        prop: "debtor_number"
      },

      {
        label: "债权人名称",
        prop: "creditor_name"
      },
      {
        label: "债务人名称",
        prop: "debtor_name"
      },
      {
        label: "欠款币种",
        prop: "currency_name"
      },
      {
        label: "欠款本金",
        prop: "arrears_principal"
      },
      {
        label: "违约金/利息/滞纳金",
        prop: "arrears_interest"
      },
      {
        label: "办案地区",
        prop: "case_handling_area"
      },
      {
        label: "办案进度",
        prop: "case_progress"
      },
      {
        label: "债务类别",
        prop: "collection_scene"
      },
      // {
      //   label: "案件状态",
      //   prop: "case_status"
      // },
      {
        label: "创建人",
        prop: "member_name"
      },
      {
        label: "创建时间",
        prop: "entrust_time"
      }
    ]
  };
  options: any = {
    page: 1,
    limit: this.$store.getters.limit,
    case_status: "",
    debtor_number: "",
    creditor_name: "",
    debtor_name: "",
    create_time: "",
    create_name: ""
  };
  navIndex: number = 0;
  created() {
    //
  }

  activated() {
    this.init();
  }

  mounted() {
    //
  }
  // 初始化函数
  init() {
    let self: any = this;
    let params: any =
      JSON.stringify(self.data.select) == "{}"
        ? self.options
        : self.data.select;
    this.getList(params);
  }
  //获取数据
  getList(params: any) {
    let data: any = this.data;
    data.loading = true;
    Api.getCaseList(params)
      .then((res: any) => {
        data.loading = false;
        data.list = res.data;
        data.list.forEach((item: any) => {
          item.entrust_time = item.entrust_time.substring(
            0,
            item.entrust_time.lastIndexOf(":")
          );
        });
        // 数据条数
        data.totalize = res.total;
      })
      .catch(() => {
        data.loading = false;
        this.$message.error("网络异常");
      });
  }
  //详情
  handleInfo(data: any) {
    let self: any = this;
    let id: any = data.debtor_number;
    self.$router.push({
      path: `/LawyerLawUrging/caseInfo/${id}`
    });
  }
  //删除
  handleDelete(data: any) {
    //
  }
  //搜索
  search(data: any) {
    let self: any = this;
    self.data.loading = true;
    self.options.page = 1;
    let params: any = Object.assign({}, self.options);
    data.forEach((item: any) => {
      let name: string = item.label;
      params[name] = item.value;
    });
    self.data.select = Object.assign({}, params);
    this.getList(params);
  }
  //清除搜索项
  clearSelection(data: any) {
    let self: any = this;
    self.data.select = {};
    this.init();
  }
  //添加编辑
  add() {
    //
  }
  //分页
  watchChange(index: number) {
    let self: any = this;
    let params: any =
      JSON.stringify(self.data.select) == "{}"
        ? self.options
        : self.data.select;
    params.page = index;
    self.init();
  }
}
