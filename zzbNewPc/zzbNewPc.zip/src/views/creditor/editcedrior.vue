<template>
  <div class="editcedrior" v-loading="loading" element-loading-text="识别中">
    <el-form ref="editcedriorFrom" :rules="data.rules" :model="data.edit" label-width="140px">
      <div class="form-box">
        <el-form-item label="上传营业执照" prop="license_img_url" class="zhengzhao">
          <el-col class="upBox" :span="22">
            <el-upload drag class="avatar-uploader" :action="burl + '/Upload/UploadImage?type=7'" :show-file-list="false" :on-success="(res,file)=>{handleAvatarSuccess('license_img_url',res,file)}" :before-upload="beforeAvatarUpload">
              <img v-if="data.edit.license_img_url" :src="data.edit.license_img_url" class="avatar" />
              <i v-else class="el-icon-plus avatar-uploader-icon"></i>
              <div slot="tip" class="el-upload__tip">营业执照为最新版原文件拍照照片，要求文件四角都在图片内，清晰无遮挡，图片水印"仅限办理债主帮法催业务”。支持jpg、jpeg、png等格式文件,文件须小于50M。</div>
            </el-upload>
            <i v-show="data.edit.license_img_url" @click="preview(data.edit.license_img_url)" class="el-icon-search preview"><span class="preview-text">+</span></i>
            <span class="upBox-tip">可将文件拖曳至框内上传</span>
          </el-col>
        </el-form-item>
        <el-form-item label="债权人名称" prop="creditor_name">
          <el-col :span="22">
            <el-input placeholder="可自动填充或手动修改" v-model="data.edit.creditor_name"></el-input>
          </el-col>
        </el-form-item>
        <el-form-item label="统一社会信用代码" prop="license_no">
          <el-col :span="22">
            <el-input placeholder="可自动填充或手动修改" v-model="data.edit.license_no"></el-input>
          </el-col>
        </el-form-item>
        <!-- <el-form-item label="代理人姓名" prop="agent_name">
          <el-col :span="22">
            <el-input v-model="data.edit.agent_name"></el-input>
          </el-col>
        </el-form-item>
        <el-form-item label="代理人身份证" prop="agent_id_number">
          <el-col :span="22">
            <el-input v-model="data.edit.agent_id_number"></el-input>
          </el-col>
        </el-form-item>
        <el-form-item label="授权书" prop="agent_authorization" class="zhengzhao">
          <el-col :span="22">
            <el-upload class="avatar-uploader" :action="burl + '/Upload/UploadImage?type=0'" :show-file-list="false" :on-success="(res,file)=>{handleAvatarSuccess('agent_authorization',res,file)}" :before-upload="beforeAvatarUpload">
              <img v-if="data.edit.agent_authorization" :src="data.edit.agent_authorization" class="avatar" />
              <i v-else class="el-icon-plus avatar-uploader-icon"></i>
            </el-upload>
          </el-col>
        </el-form-item> -->
        <el-form-item label="公司电话" prop="phone_number">
          <el-col :span="22">
            <el-input v-model="data.edit.phone_number"></el-input>
          </el-col>
        </el-form-item>
        <el-form-item label="电子邮箱" prop="email">
          <el-col :span="22">
            <el-input v-model="data.edit.email"></el-input>
          </el-col>
        </el-form-item>
        <el-form-item label="所在地区" prop="county">
          <el-col :span="22">
            <comAddress :address="address" @emitAddress="getAddress"></comAddress>
          </el-col>
        </el-form-item>
        <el-form-item label="详细地址" prop="detailed_address">
          <el-col :span="22">
            <el-input type="textarea" v-model="data.edit.detailed_address"></el-input>
          </el-col>
        </el-form-item>
      </div>
      <el-form-item style="margin-bottom:0;margin-top:50px;" class="edit-bottom-bin">
        <el-button :loading="data.submitType" type="primary" @click="submitForm('editcedriorFrom')">确定</el-button>
        <el-button @click="close">取消</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script lang="ts">
import { Component, Vue, Prop, Watch } from 'vue-property-decorator'
import { Getter, Action } from 'vuex-class'
import * as Api from '../../api/creditor'
import { baseURL, pp } from '../../utils/request'
import { comAddress } from '../../components/index'
import { verifyPhone, verifyEmall } from '../../utils/common'
import { api } from '../../../../zzbPc/src/assets/js/api'
@Component({
  components: {
    comAddress,
  },
})
export default class About extends Vue {
  name: any = 'addForms'
  //prop
  @Prop() parentId?: number
  //Watch
  @Watch('parentId', { immediate: true })
  parentIdChange(newVal: number, oldVal: number) {
    let self: any = this
    if (newVal == 0 || newVal == null) {
      self.data.edit.id = 0
      self.resetForm('editcedriorFrom')
    } else if (newVal == -1) {
      return false
    } else {
      let id: number = newVal
      self.init(id)
      // Api.getcreditor(id).then((res: any) => {
      //   res.data.sex = res.data.sex == 1 ? '男' : '女'
      //   self.data.edit = res.data
      // })
    }
  }
  //手机号码验证
  validatePhone = (rule: any, value: any, callback: any) => {
    let vtf: any = verifyPhone(value)
    if (!vtf.done) {
      callback(new Error(vtf.errMsg))
    } else {
      callback()
    }
  }
  //邮箱验证
  validateEmall = (rule: any, value: any, callback: any) => {
    let vtf: any = verifyEmall(value)
    if (!vtf.done) {
      callback(new Error(vtf.errMsg))
    } else {
      callback()
    }
  }
  // data
  data: any = {
    edit: {
      id: 0,
      // 债权人名称
      creditor_name: '',
      // 债权人类别
      creditor_type: 'Creditor_states_0',
      //证照编号
      license_no: '',
      // 手机号
      phone_number: '',
      //证照图片地址
      license_img_url: '',
      // 邮箱
      email: '',
      country: '', //国家
      province: '', //省份
      city: '', //城市
      county: '', //区县
      detailed_address: '', //详细地址
      agent_name: '', //代理人姓名
      agent_id_number: '', //代理人身份证号码
      agent_authorization: '', //代理人授权书
    },
    submitType: false,
    rules: {
      creditor_name: [{ required: true, message: '请输入债权人名称', trigger: 'blur' }],
      license_img_url: [{ required: true, message: '请上传证照图片', trigger: 'blur' }],
      license_no: [{ required: true, message: '请输入证照号码', trigger: 'blur' }],
      email: [
        { required: true, message: '请输入电子邮箱', trigger: 'blur' },
        { validator: this.validateEmall, trigger: 'blur' },
      ],
      county: [{ required: true, message: '请选择地区', trigger: 'change' }],
      phone_number: [
        { required: true, message: '电话号码不得为空', trigger: 'blur' },
        {
          min: 4,
          max: 12,
          message: '电话号码的长度在4~12个字符之间',
          trigger: 'blur',
        },
      ],
      detailed_address: [{ required: true, message: '请输入地址详情', trigger: 'blur' }],
      // agent_name: [{ required: true, message: '请输入代理人姓名', trigger: 'blur' }],
      // agent_id_number: [{ required: true, message: '请输入代理人身份证号', trigger: 'blur' }],
      // agent_authorization: [{ required: true, message: '请上传代理人授权书', trigger: 'blur' }],
    },
  }
  loading: boolean = false
  height: number = 0
  burl: string = ''
  address: string = '' //地区
  created() {
    //
  }

  activated() {
    //
  }

  mounted() {
    let qz: string = pp === 'production' ? '/api/' : '/api/pt'
    this.height = document.body.offsetHeight - 180
    this.burl = baseURL + qz
  }

  beforeDestroy() {
    //
  }
  init(id: any) {
    let self: any = this
    Api.getcreditor(id).then((res: any) => {
      if (res.data != null) {
        self.address = [res.data.country, res.data.province, res.data.city, res.data.county]
        Object.keys(self.data.edit).forEach((key: string) => {
          self.data.edit[key] = res.data[key]
        })
      }
    })
  }
  initsetout() {}
  //获取地址栏子组件选择值
  getAddress(data: any) {
    this.data.edit.country = data.country
    this.data.edit.city = data.city
    this.data.edit.county = data.county
    this.data.edit.province = data.province
  }
  //表单提交
  submitForm(formName: string) {
    let from: any = this.$refs[formName]
    let self: any = this
    from.validate((valid: Boolean) => {
      if (valid) {
        self.data.submitType = true
        // self.data.edit.sex = self.data.edit.sex == '男' ? 1 : 0
        Api.creditorInsert(self.data.edit).then((res: any) => {
          if (res.state == true) {
            self.$message.success(res.msg)
            setTimeout(() => {
              self.close()
              self.$emit('csh')
            }, 1000)
          } else {
            self.$message.warning(res.msg)
          }
        })
      } else {
        return false
      }
    })
  }
  //图片上传成功
  handleAvatarSuccess(prop: string, res: any, file: any) {
    let self: any = this
    self.loading = true
    if (res.data.State == true) {
      // this.$message.success(res.data.Msg)
      self.data.edit[prop] =
        'http://file.debteehelper.com' + res.data.FileUrl + res.data.FileExtension
      let parmas: any = {
        img_path: 'http://file.debteehelper.com' + res.data.FileUrl + res.data.FileExtension,
        img_type: 2,
      }
      Api.PostRecognition(parmas).then((res2: any) => {
        if (res2.state) {
          self.data.edit.creditor_name = res2.data.name
          self.data.edit.license_no = res2.data.reg_num
          self.$message.success('上传成功，请确认债权人名称和统一社会信用代码识别正确。')
        } else {
          self.$message.warning('图片识别失败')
        }
        self.loading = false
      })
    } else {
      self.$message.warning(res.data.Msg)
    }
  }
  beforeAvatarUpload(file: any) {
    const isLt2M = file.size / 1024 / 1024 < 50
    // const isJPG =
    //   file.type === 'image/jpeg' || file.type === 'image/jpg' || file.type === 'image/png'
    if (!isLt2M) {
      this.$message.error('上传图片大小不能超过 50MB!')
    }
    // if (!isJPG) {
    //   this.$message.error('图片只能是 JPG/JPEG/PNG 格式!')
    // }
    return isLt2M
  }
  //重置表
  resetForm(formName: string) {
    let self: any = this
    self.data.edit.license_img_url = ''
    self.$refs[formName].resetFields()
  }

  //关闭弹出
  close() {
    let self: any = this
    self.data.submitType = false
    self.resetForm('editcedriorFrom')
    self.$emit('cancel', self.data.submitType)
  }
  //图片预览
  preview(url: string) {
    window.open(url)
  }
}
</script>

<style lang="scss">
@import '@/assets/scss/variables';
.editcedrior {
  .zhengzhao {
    height: 100px !important;
    margin-bottom: 30px;
  }
  .form-box {
    max-height: 520px;
    overflow-y: auto;
  }
  .el-upload__tip {
    font-size: 12px;
    color: #606266;
    margin-top: 7px;
    line-height: 1.5;
    position: absolute;
    top: 0;
    width: 60%;
    right: 0;
    padding-right: 40px;
  }
  .el-upload-dragger {
    width: 100px !important;
    height: 100px !important;
  }
  .upBox {
    position: relative;
    .preview {
      position: absolute;
      // right: 20px;
      left: 83px;
      top: 0;
      cursor: pointer;
      font-size: 18px;
      .preview-text {
        position: absolute;
        top: 2px;
        right: 5px;
        font-size: 12px;
      }
    }
    .upBox-tip {
      position: absolute;
      bottom: -20px;
      font-size: 12px;
      color: #409eff;
    }
  }
}
</style>
