<template>
  <div class="creditor">
    <comselect :options="data.options" @select="search" @clear="clearSelection"></comselect>
    <comOperation :totalize="data.totalize" :addText="'新增债权人'" @add="add"></comOperation>
    <comtable :tableData="data.list" :load="data.loading" :tableType="data.dataType" @Edit="handleEdit" @Delete="handleDelete"></comtable>
    <!-- <comPaging
      :page="options.page"
      :totalize="data.totalize"
      @watchChange="watchChange"
    ></comPaging> -->
    <!-- 新增债权人 弹框 -->
    <el-dialog title="债权人新增/编辑" :visible.sync="data.addDialogVisible">
      <addForms ref="changdialog" :parentId="data.id" @determine="adddialog" @initdata="adddialog" @cancel="adddialog" @csh="init"></addForms>
    </el-dialog>
  </div>
</template>
<script lang="ts" src="./index.ts"></script>
<style lang="scss">
@import './index.scss';
</style>
