<template>
  <div class="err-wrap">
    <img class="img" src="../../../public/404-error-animate.svg" alt="" />
    <el-button class="btn" plain @click="goback" type="primary">返回</el-button>
  </div>
</template>

<script lang="ts" src="./404.ts"></script>

<style lang="scss">
@import "./404.scss";
</style>
