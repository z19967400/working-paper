<template>
  <div class="Account">
    <comselect :options="data.options" @select="search" @clear="clearSelection"></comselect>
    <comOperation :totalize="data.totalize" :addText="'添加账户'" @add="addAccount"></comOperation>
    <comtable :tableData="data.list" :load="data.loading" :tableType="data.dataType" @admin="setingAdmin" @Edit="handleInfo" @Delete="handleDelete" :top="20"></comtable>
    <!-- <comPaging :page="options.page" :totalize="data.totalize" @watchChange="watchChange"></comPaging> -->
    <!-- 新增账户 弹框 -->
    <el-dialog title="编辑/添加子账户" :visible.sync="data.addDialogVisible">
      <el-row style="height:40px;line-height: 40px;">
        <el-col :span="4">
          <span>子账户名称</span>
        </el-col>
        <el-col :span="16">
          <el-input v-model="data.addData.account_name"></el-input>
        </el-col>
      </el-row>
      <div class="footer">
        <el-button type="primary" @click="submitForm()">确定</el-button>
        <el-button @click="data.addDialogVisible = false">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script lang="ts" src="./index.ts"></script>
<style lang="scss">
@import './index.scss';
</style>
