import * as Api from "@/api/Accounts";
/* eslint-disable prettier/prettier */
import { Component, Vue } from "vue-property-decorator";
import { comselect, comOperation, comPaging } from "@/components/index";
import comtable from "./tab.vue";
@Component({
  components: {
    comtable,
    comselect,
    comOperation,
    comPaging
  }
})
export default class About extends Vue {
  // Getter

  // Action

  // data
  data: any = {
    addDialogVisible: false,
    loading: false,
    // 表格数据
    list: [],
    select: {},
    totalize: 0,
    options: [
      {
        value: "account_name",
        label: "账户名称"
      }
      // {
      //   value: "account_name",
      //   label: "vip账户名称"
      // },
      // {
      //   value: "admin_name",
      //   label: "vip管理员名称"
      // }
    ],
    dataType: [
      // {
      //   label: "ID",
      //   prop: "id"
      // },
      {
        label: "序号",
        prop: "id",
        width: "80px"
      },
      {
        label: "账户名称",
        prop: "account_name"
      },
      {
        label: "是否为总账户",
        prop: "is_super"
      },
      {
        label: "管理员数量",
        prop: "admin_total"
      },
      {
        label: "创建时间",
        prop: "create_time"
      }
    ],
    addData: {
      account_name: "",
      id: 0,
      member_vip_id: 0,
      parent_account_id: 0
    }
  };
  options: any = {
    // page: 1,
    // limit: this.$store.getters.limit,
    account_name: ""
  };

  // created() {

  // }

  activated() {
    this.data.loading = true;
    // eslint-disable-next-line no-console
    // console.log(111);
    setTimeout(() => {
      this.init();
    }, 1000);
  }

  // mounted() {

  // }

  // 初始化函数
  init() {
    let self: any = this;
    let params: any =
      JSON.stringify(self.data.select) == "{}"
        ? self.options
        : self.data.select;
    this.getAccountList(params);
  }
  //获取数据
  getAccountList(params: any) {
    let data: any = this.data;
    Api.getAccountList(params.account_name)
      .then((res: any) => {
        data.loading = false;
        data.list = res.data;
        // 数据条数
        data.totalize = data.list.length;
        data.list.forEach((item: any) => {
          item.is_super = item.is_super == 1 ? "是" : "否";
        });
      })
      .catch(() => {
        data.loading = false;
        this.$message.error("网络异常");
      });
  }
  //编辑
  handleInfo(data: any) {
    this.data.addDialogVisible = true;
    Object.keys(this.data.addData).forEach((key: string) => {
      this.data.addData[key] = data.row[key];
    });
  }
  //删除
  handleDelete(data: any) {
    Api.getAccountAdmins(data.row.id, "").then((res: any) => {
      if (res.data.length == 0) {
        Api.deleteAccoundt(data.row.id).then((res: any) => {
          if (res.state) {
            this.$message.success(res.msg);
            this.init();
          } else {
            this.$message.warning(res.msg);
          }
        });
      } else {
        this.$message.warning("该账户下有管理员，不可删除");
      }
    });
  }
  //搜索
  search(data: any) {
    let self: any = this;
    self.data.loading = true;
    self.options.page = 1;
    let params: any = Object.assign({}, self.options);
    data.forEach((item: any) => {
      let name: string = item.label;
      params[name] = item.value;
    });
    self.data.select = params;
    this.getAccountList(params);
  }
  //清除搜索项
  clearSelection(data: any) {
    let self: any = this;
    self.data.select = {};
    this.init();
  }
  //添加编辑
  add() {
    //
  }
  //分页
  watchChange(index: number) {
    let self: any = this;
    let params: any =
      JSON.stringify(self.data.select) == "{}"
        ? self.options
        : self.data.select;
    params.page = index;
    self.init();
  }
  //新增账户
  addAccount() {
    this.data.addDialogVisible = true;
    this.data.addData = {
      account_name: "",
      id: 0,
      member_vip_id: 0,
      parent_account_id: 0
    };
  }
  //确认添加
  submitForm() {
    Api.addAccount(this.data.addData).then((res: any) => {
      if (res.state) {
        this.$message.success(res.msg);
        this.data.addDialogVisible = false;
        this.init();
      } else {
        this.$message.warning(res.msg);
      }
    });
  }
  //设置管路员
  setingAdmin(data: any) {
    let id: number = data.id;
    // let name: string = data.account_name;
    this.$router.push({
      path: `/account/info/${id}`
    });
  }
}
