import { creditorData, AIlvshihanOptions } from "./../types/index";
import Api from "@/utils/request";
// 获取管理页数据
export const creditorGetPaging = (params: creditorData["getData"]) => {
  return Api.creditorGetPaging(params, "GET");
};
//获取债权人编辑
// getcreditor
export const getcreditor = (id: any) => {
  return Api.getcreditor({ creditor_id: id }, "GET");
};
//债权人提交
export const getcreditordata = (params: creditorData["getcreditordata"]) => {
  return Api.getcreditordata(params, "GET");
};
//债权人删除
export const deletecreditor = (id: any) => {
  return Api.deletecreditor({ creditor_id: id }, "GET");
};
//债权人新增||修改
export const creditorInsert = (params: AIlvshihanOptions["addParams"]) => {
  return Api.creditorInsert(params, "POST");
};
//债权人添加证照识别
export const PostRecognition = (params: any) => {
  return Api.PostRecognition(params, "POST");
};
