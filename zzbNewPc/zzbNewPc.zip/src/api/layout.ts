import Api from "@/utils/request";

export const getData = () => {
  return Api.getData();
};
//获取债务人反馈详情
export const getDebtFeadback = (id: number) => {
  return Api.getDebtFeadback({ id }, "GET");
};
//新增债务人反馈
export const addFeadBack = (parmas: any) => {
  return Api.addFeadBack(parmas, "POST");
};
