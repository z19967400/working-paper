export default {
  getData: "/mock/5c09ca373601b6783189502a/example/mock", // 随机数据 来自 easy mock
  login: "/api/pt/login/Admin_Login", //登录
  SendLawyersLetter: "/api/pt/Dictionary/Lawyerletter", // 发律师函
  getTableData: "/api/pt/Creditor/GetCreditorList", // 选择债权人弹框列表
  creditorInsert: "/api/pt/Creditor/UpdateCreditor", //债权人修改
  afterTest: "/api/pt/tools/test", // 上传表格校验-返回
  getTemplateType: "/api/pt/tools/GetExcelPath", // 根据债务人类别获取下载模板所需的路径
  AILawyerLetterInsert: "/api/pt/AILawyerLetter/SaveAILawyer", //ai律师函修改
  sendTextVal: "/api/pt/Tools/Verify", // 发送后台验证
  getCreditorStates: "/api/pt/tools/GetType", // 获取债权人列表
  creditorGetPaging: "/api/pt/Creditor/GetCreditorList", //债权人
  getBill: "/api/pt/Bill/GetPaging", //获取账单列表
  getBillInfo: "/api/pt/Bill/GetAdmin", //获取账单详情
  getDetails: "/api/pt/pay/GetPaging", //获取收支列表
  getInformation: "/api/pt/Finance/GetPaging", //获取发票信息列表
  ticketCollection: "/api/pt/Finance/GetPaging_address", //获取收票信息列表
  getCollection: "/api/pt/CollectMoney/GetAllCollectMoney", //收款通道列表
  collectionDelete: "/api/pt/MemberCollectMoney/Delete", //收款通道删除
  addCollection: "/api/pt/CollectMoney/UpdateCollectMoney", //收款通道编辑/新增
  getCollectInfo: "/api/pt/MemberCollectMoney/GetByid", //获取收款通道详情
  getshoukuanTableData: "/api/pt/CollectMoney/GetAllCollectMoney", //选择收款通道
  getpaygetDetails: "/api/pt/pay/GetDetails", //收支详情
  getAddress: "/api/pt/Tools/GetAddress", //地区练级选择器
  getcreditor: "/api/pt/Creditor/GetCreditorInfoById", //获取债权人详情
  addBill: "/api/pt/Bill/ApplyBill", //申请开票
  addTicket: "/api/pt/Finance/Insert_address", //添加收票地址
  invoiceEdit: "/api/pt/Finance/Insert", //发票添加/修改
  debtorGetPaging: "/api/pt/Debtor/GetPaging", //债务人
  getAILawyerPaging: "/api/pt/AILawyerLetter/AILawyerPagingData", //委托管理
  getAdmin: "/api/pt/AILawyerLetter/GetAILawyerDetails", //委托详情
  getInvoiceInfo: "/api/pt/Finance/GetByid", //获取发票详情
  invoiceDelete: "/api/pt/Finance/Delete", //发票删除
  getTicketInfo: "/api/pt/Finance/GetByid_address", //获取收票地址详情
  ticketDelete: "/api/pt/Finance/Delete_address", //收票地址删除
  getCollectionInfo: "/api/pt/CollectMoney/GetCollectMoneyById", //获取收款通道详情
  deletecreditor: "/api/pt/Creditor/DeleteCreditorByid", //债权人删除
  addgetmaney: "/api/pt/CollectMoney/UpdateCollectMoney", //新增收款通道
  getDetailedInfo: "/api/pt/pay/GetDetails", //获取收支明细详情
  getTicketDown: "/api/pt/Finance/InvoiceAddressPullDown", //获取收票地址下拉
  getInvoiceDown: "/api/pt/Finance/InvoicePullDown", //获取发票下拉
  getSmsInfo: "/api/pt/AILawyerLetter/GetAILawyerTaskContent", //查看短信发送详情
  // getPhoneInfo: "/api/pt/LogsSel/GetSel_phone", //查看电话详情
  getEmail: "/api/pt/AILawyerLetter/GetAILawyerLogistics", //获取ems物流信息
  getLawyerInfo: "/api/pt/LogsSel/GetSel_lawyer_letter", //获取律师函详情
  Alipay: "/api/zf/AliNativePay/NativePay", //支付宝支付
  WeChat: "/api/zf/WeChatNativePay/NativePay", //微信支付
  WeChatQuery: "/api/zf/WeChatOrderQuery/OrderQuery", //微信支付查询结果
  AlipayQuery: "/api/zf/AliOrderQuery/OrderQuery", //支付宝支付查询结果
  AfterPay: "/api/zf/AfterPay/FirstRushAfterPay", //先催后付
  UnionPay: "/api/zf/AfterPay/BankTransfer", //对公转账
  getDebtFeadback: "/api/pt/Feedback/Getdetails", //获取债务人反馈详情
  addFeadBack: "/api/pt/Feedback/Insert", //新增债务人反馈
  establishCase: "/api/pt/Cases/CreateCases", //线下律师催创建案件
  getCaseList: "/api/pt/Cases/GetCasePagingData", //获取线下案件列表
  getCaseInfo: "/api/pt/Cases/GetCaseDetails", //获取线下律师办案案件详情
  getCasePross: "/api/pt/CaseProcess/GetCaseProcess", //获取案件办案进度
  getPaySet: "/api/pt/VipMember/GetPaySet", //获取支付价格设置
  getPaysList: "/api/pt/AILawyerLetter/GetUnpaidAILawyer", //获取待支付列表
  GetHomeData: "/api/pt/Home/GetHomeData", //获取首页数据
  SignNotice: "/api/pt/CaseProcess/ContractNotice", //获取签署合同通知短信
  getNoticeInfo: "/api/pt/CaseProcess/ContractSee", //获取线上签署合同详情
  getProcessInfo: "/api/pt/CaseProcess/GetCaseMattersFromDetails", //获取进程详情
  PostRecognition: "/api/pt/Tools/Recognition", //债权人证照识别
  getCurrency: "/api/pt/Tools/GetAllCurrency", //获取所有币种
  serviceFeeSelection: "/api/pt/Cases/ServiceFeeSelection", //案件确认服务费模式
  stopAiLetter: "/api/pt/AILawyerLetter/Stop", //ai律师函停止
  SendTransfer: "/api/pt/NoticeSend/SendTransferPaymentInformation", //对公转账支付通知
  AIlawLetterDelete: "/api/pt/AILawyerLetter/DeleteAILawyerLetter", //AI律师函待支付订单删除
  getAccountList: "/api/pt/VipMember/GetAccountList", //获取账户列表
  getAccountAdmins: "/api/pt/VipMember/GetAccountAdmin", //获取账户下所有管理员
  UpdatAdmin: "/api/pt/VipMember/UpdateAdmin", //更新管理员
  getAccountCreditors: "/api/pt/Creditor/GetAllCreditorByVipId", //获取账户下所有债权人
  getAdminCreaditors: "/api/pt/Creditor/GetCreditorByAdminId", // 获取管理员设置的债权人
  setCreditorAdmin: "/api/pt/Creditor/SetCreditorAdmin", //设置管理员的债权人
  deleteCreditorAdmin: "/api/pt/Creditor/DeleteCreditorAdmin", //删除管理员的债权人
  deleteAccountAmind: "/api/pt/VipMember/DeleteAdmin", //删除账户下的管理员
  addAccount: "/api/pt/VipMember/UpdateAccount", //添加大客户账户
  deleteAccoundt: "/api/pt/VipMember/DeleteAccount" //删除账户
};
