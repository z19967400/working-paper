// operation.Data 参数类型
export interface OperationData {
  componentName: string;
}
