// test.Data 参数类型
export interface TestData {
  componentName: string;
}
