export interface getPagingParms {
  page: number;
  limit: number;
  batch_no?: any;
  debtor_no?: any;
  creditor_name?: any;
  debtor_name?: any;
  address_txt?: any;
  time?: any;
  executing_states?: any;
}
